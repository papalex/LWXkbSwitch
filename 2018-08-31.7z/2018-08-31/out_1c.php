<?php
use \app\core\gui\Page;
use app\core\gui\_Icon32;
use \app\models\Mts_number;
use \app\models\Mts_period;
use \app\models\User_param;
/**
 * @var $iForm \app\core\gui\ITable
 * @var $btn \app\core\gui\IEButton
 */
function mb_str_pad ($input, $pad_length, $pad_string=" ", $pad_style=STR_PAD_RIGHT, $encoding="UTF-8")
{
	return str_pad($input, strlen($input)-mb_strlen($input,$encoding)+$pad_length, $pad_string, $pad_style);
}
$view=new Page();

$Txt ='';

$view->addItem('Title', ['label' => 'Статистика МТС выгрузка в 1С', ]);
$view->addItem('IconToolBar', [], $view->iconToolBar);
$view->leftDefaultBtn['Back']=['url' => $this->createURL('/mts/admin'),];
$view->leftDefaultBtn['ChangeOwner']=[];

$view->addItem('ITable', [], 'iForm');
$iForm=$view->items['iForm'];
$iForm->addItem('IESelectPrep', ['name' => 'mts_period_id', 'label' => 'Период','value' => $period, 'sql' => <<< SQL
select mts_period_id as pkey, period as name from mts_period order by period desc
SQL
	,'isRequired' => true, 'isReadonly' => false,
	]);
$iForm->addItem('IEButton', [], 'btn');
$btn=$iForm->items['btn'];
$u=['url' => $this->createURL('mts/out_1c/a/0')];
$btn->addSaveBtn(array_merge($u,['label'=>'Сформировать']));

$iForm->addItem('IEMessage', [], 'bl');

if ($period)
{
	$this->render('out_1c_info', ['view' => $iForm,'period'=>$period]);
	$iForm->items['bl']->breakLine();
	$sql = <<<SQL
select * from mts_out_1c where mts_period_id = :period and user_id = :uid and is_saved=0;
SQL;
	$rows = Yii::$app->db->createCommand($sql)->bindValues([':period'=> $period,':uid'=>$this->uid])
		->queryAll();

	$aHdr = array('- Лиц.счет ', '№ счета', 'Дата счета', 'Файл', 'Ид.сотрудника', 'Ф.И.О.', 'Месяц', 'Факт.Расход', 'Лимит','Скидка  ');
	$aCnt = array(mb_strlen($aHdr[0]), mb_strlen($aHdr[1]), mb_strlen($aHdr[2]), mb_strlen($aHdr[3]), mb_strlen($aHdr[4]), mb_strlen($aHdr[5]), mb_strlen($aHdr[6]), mb_strlen($aHdr[7]), mb_strlen($aHdr[8]),mb_strlen($aHdr[9]));
	foreach ($rows as $r)
	{
		$aCnt[0] = (mb_strlen($r['contract']) > $aCnt[0]) ? mb_strlen($r['contract']) : $aCnt[0];
		$aCnt[1] = (mb_strlen($r['account']) > $aCnt[1]) ? mb_strlen($r['account']) : $aCnt[1];
		$aCnt[2] = (mb_strlen($r['invoice_date']) > $aCnt[2]) ? mb_strlen($r['invoice_date']) : $aCnt[2];
		$aCnt[3] = (mb_strlen($r['filename']) > $aCnt[3]) ? mb_strlen($r['filename']) : $aCnt[3];
		$aCnt[4] = (mb_strlen($r['employee_id']) > $aCnt[4]) ? mb_strlen($r['employee_id']) : $aCnt[4];
		$aCnt[5] = (mb_strlen($r['fms']) > $aCnt[5]) ? mb_strlen($r['fms']) : $aCnt[5];
		$aCnt[6] = (mb_strlen($r['period']) > $aCnt[6]) ? mb_strlen($r['period']) : $aCnt[6];
		$aCnt[7] = (mb_strlen($r['amount']) > $aCnt[7]) ? mb_strlen($r['amount']) : $aCnt[7];
		$aCnt[8] = (mb_strlen($r['limit_amount']) > $aCnt[8]) ? mb_strlen($r['limit_amount']) : $aCnt[8];
		$aCnt[9] = (mb_strlen($r['discount']) > $aCnt[9]) ? mb_strlen($r['discount']) : $aCnt[9];
	};

	$Txt = '- Всего строк данных: ' . count($rows) . '<br>';
	$Txt .= str_repeat('-', $aCnt[0]) . ' + ' . str_repeat('-', $aCnt[1]) . ' + ' . str_repeat('-', $aCnt[2]) . ' + ' . str_repeat('-', $aCnt[3]) . ' + ' . str_repeat('-', $aCnt[4]) . ' + ' . str_repeat('-', $aCnt[5]) . ' + ' . str_repeat('-', $aCnt[6]) . ' + ' . str_repeat('-', $aCnt[7]) . ' + ' . str_repeat('-', $aCnt[8]). ' + ' . str_repeat('-', $aCnt[9]) . '<br>';
	$Txt .= mb_str_pad($aHdr[0], $aCnt[0]) . ' | ' . mb_str_pad($aHdr[1], $aCnt[1]) . ' | ' . mb_str_pad($aHdr[2], $aCnt[2]) . ' | ' . mb_str_pad($aHdr[3], $aCnt[3]) . ' | ' . mb_str_pad($aHdr[4], $aCnt[4]) . ' | ' . mb_str_pad($aHdr[5], $aCnt[5]) . ' | ' . mb_str_pad($aHdr[6], $aCnt[6]) . ' | ' . mb_str_pad($aHdr[7], $aCnt[7]) . ' | ' . mb_str_pad($aHdr[8], $aCnt[8])  . ' | ' . mb_str_pad($aHdr[9], $aCnt[9]). '<br>';
	$Txt .= str_repeat('-', $aCnt[0]) . ' + ' . str_repeat('-', $aCnt[1]) . ' + ' . str_repeat('-', $aCnt[2]) . ' + ' . str_repeat('-', $aCnt[3]) . ' + ' . str_repeat('-', $aCnt[4]) . ' + ' . str_repeat('-', $aCnt[5]) . ' + ' . str_repeat('-', $aCnt[6]) . ' + ' . str_repeat('-', $aCnt[7]) . ' + ' . str_repeat('-', $aCnt[8]). ' + ' . str_repeat('-', $aCnt[9]) . '<br>';
	foreach ($rows as $r)
	{
		$Txt .=
			mb_str_pad($r['contract'], $aCnt[0]) . ' | ' .
			mb_str_pad($r['account'], $aCnt[1]) . ' | ' .
			mb_str_pad($r['invoice_date'], $aCnt[2]) . ' | ' .
			mb_str_pad($r['filename'], $aCnt[3]) . ' | ' .
			mb_str_pad($r['employee_id'], $aCnt[4]) . ' | ' .
			mb_str_pad($r['fms'], $aCnt[5], ' ') . ' | ' .
			mb_str_pad($r['period'], $aCnt[6]) . ' | ' .
			mb_str_pad($r['amount'], $aCnt[7], ' ') . ' | ' .
			mb_str_pad($r['limit_amount'], $aCnt[8], ' ') . ' | ' .
			mb_str_pad($r['discount'], $aCnt[9])
			. '<br>';
	};
	$iForm->addItem('IEMessage', ['label' => 'Сформированные данные', 'message' => '<pre>'.$Txt.'</pre>', 'countLine' => 1,],'view_data');
	$iForm->addItem('IEHidden',['name'=>'save_data','idInput'=>'save_data','value'=>$Txt],'save_data');

	$iForm->addItem('IEButton', [], 'btnsend');
	$btn=$iForm->items['btnsend'];
	$u=['url' => $this->createURL('mts/out_1c/a/1')];
	$btn->addOkBtn(array_merge($u,['label'=>'Сохранить как текст','id'=>'exporttext']));

	$u=['url' => $this->createURL('mts/out_1c/a/2')];
	$btn->addSaveBtn(array_merge($u,['label'=>'Выгрузить','id'=>'exportbase']));
}

$view->out();
?>