<?php
/**
 * @var $iForm app\core\gui\ITable
 * @var $model \app\models\Mts_number_mts_period
 * @var $contract \app\models\Mts_contract
 * @var $period  \app\models\Mts_period
 * @var $mts_number \app\models\Mts_number
 * @var $btn app\core\gui\IEButton
 *
 */
use \app\models\Mts_number_mts_period;
use \app\models\Mts_period;
use \app\core\gui\Page;

$view = new Page();
$view->addItem('Title', ['label' => 'Редактирование - ' . $mts_number->number]);
$view->addItem('IconToolBar', [], $view->iconToolBar);
$view->leftDefaultBtn['Back']=['url' => $this->createURL('/mts/phone_list/id/'.$mts_number->user_id),];
$view->leftDefaultBtn['ChangeOwner']=[];
$view->addItem('ITable', [], 'iForm');


$iForm=$view->items['iForm'];
$iForm->model=$mts_number;

$contract = $mts_number->mts_person_account_->mts_contract_;
$mtp = $mts_number->mts_tariff_plan_;
$accessAdmin = !Yii::$app->user->can('MTS_DETAILS');

$iForm->addItem('IEEdit',
	['name' => 'number',
		'value'=>$mts_number->number,
		'isReadonly' => true
	]);

$iForm->addItem('IEEdit',
	['name'=>'mts_contract_id','label'=>'Контракт',
		'value'=>$contract->number ." ({$contract->krp_company_->name})",
		'isReadonly'=>true
	]);
$iForm->addItem('IESelect',
	['name' => 'mts_tariff_plan',
		'label'=>'Тарифный план',
		'value'=>$mts_number->mts_tariff_plan,
		'sql' => <<< SQL
select mtp.mts_tariff_plan, mtp.name as name from mts_tariff_plan mtp 
	where mtp.is_visible = 1 order by name
SQL
		, 'isRequired'=>true
	]);

$iForm->addItem('IEEdit',
	['name' => 'limit_amount',
		'label' => 'Дополнительный лимит',
		'value' => $mts_number->limit_amount
	]);
$iForm->addItem('IEAjax',
	[	'name' => 'user_id',
		'min' => 1,
		'max' => 10000,
		'isOverflow' => true,
		'isReadonly' => true,
		'autocompleteURL' => $this->createURL('/mts/ac_user'),
	]);

$iForm->addItem('IEMessage', [], 'bl');
$iForm->items['bl']->breakLine();

$iForm->addItem('IEButton', [], 'btn');
$btn=$iForm->items['btn'];
$u=['url' => $this->createURL('mts/'. $redirect.'/id/'.$mts_number->getPkey())];
$btn->addSaveBtn($u);

$view->out();
?>