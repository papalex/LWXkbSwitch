<?php
/**
 * @var $rpt \app\core\gui\ioTablePrep
 */
use \app\models\Mts_number;

$view->addItem('ioTablePrep',
	['isBtn' => false,
		'nameForm' => 'mts_number',
		'db' => Yii::$app->db,
		'alias' => 'mn',
		'pkey' => 'mts_number_id',
        'hideField' => ['r.code', ],
		'templateSQL' => <<< SQL
with rights as (
	select g.code,krpc.krp_company, krpc.name as name from krp_company krpc
		inner join groupe g on g.code='MTS_' || krpc.krp_company
		inner join user_groupe_cache ug on ug.groupe_id=g.groupe_id and ug.user_id=:uid
	)
select %%fld%%

from mts_number mn 
	inner join mts_person_account mpa on mpa.mts_person_account_id = mn.mts_person_account_id and (:fms isnull or mn.user_id notnull)
	inner join mts_contract contr on mpa.mts_contract_id = contr.mts_contract_id and (:contnum is null or mpa.mts_contract_id = :contnum)
	inner join (select company.name , company.krp_company as krp_company from krp_company company where
				(:companyname is null or company.krp_company = :companyname)
				and exists(select 'x' from groupe g
					join user_groupe_cache ugc on ugc.groupe_id=g.groupe_id and ugc.user_id=:uid
				where g.code ='MTS_' || company.krp_company)
								 ) as company
				on contr.krp_company = company.krp_company 
	left join "user" own on mn.user_id = own.user_id and (:fms is null or own.fms ilike :fms)
	left join rights r on r.krp_company = contr.krp_company
	where (1=1) %%whr%% and (:fms is null or own.fms ilike :fms)
%%srt%%
%%ofst%% %%lmt%%
SQL
	,  'defaultSort' => 'mn.number'],
	'report');

$rpt=$view->items['report'];

$rpt->addItem('Title', ['label' => 'Номера', ], 'title');

$rpt->queryParam = [':companyname'=>null,':contnum'=>null,':uid'=>$this->uid,':fms'=>null];

$rpt->addItem('Pager', ['nameForm' => 'numbers',], $rpt->pager);
$rpt->addItem('OTable', ['class' => 'it_data_table','modelName' => Mts_number::class,
								'columns' => [
									'number'=>['label'=>'Номер'],
									'fms'=>['label'=>'Пользователь','alias'=>'own','field'=>'f_ms'],
									'krp_company'=>['label' =>'Юр.лицо','alias'=>'company','field'=>'name','name'=>'name'],
									'mts_person_contract_id'=>['label' =>'Контракт','alias'=>'contr','field'=>'number','name'=>'mts_contract_id'],
									'mts_person_account_id'=>['label'=>'Лицевой счет','alias'=>'mpa','field'=>'number','name'=>'mts_person_account_id'],
									'active_date'=>['label'=>'Дата передачи'],
									],],

			$rpt->dataTable);
$dt=$rpt->items[$rpt->dataTable];
$dt->addTitleFromModel('Title', ['class' => 'it_head'], $dt->titleKey);

$dt->addItem('Order', ['class' => 'it_sort',
			'columns' => ['mts_number_id' => ['field' => 'mts_number_id',],],],
		$dt->orderKey);

$dt->addItem('Filter',
		['class' => 'filter',
		'columns' =>
			[
			'number' => ['type' => 'Edit', 'like' => '%_%',],
			'fms' => ['type' => 'Edit', 'like' => '%_%',],
			'active_date' => ['type' => 'Date', ],
			'mts_person_account_id' => ['alias'=>'mpa','type' => 'Edit', 'like' => '%_%',],
			'mts_person_contract_id' =>
				[
				'type' => 'SelectPrep', 'sql' => <<< SQL
select  distinct mts_contract_id, number || ' - ' || krpc.name || ' ( ' ||region || ')'as name  from mts_contract
	join krp_company krpc on mts_contract.krp_company = krpc.krp_company
	inner join groupe g on g.code ='MTS_' || krpc.krp_company 
	inner join user_groupe_cache ugc on ugc.groupe_id=g.groupe_id and ugc.user_id=:uid
where krpc.inn notnull order by name
SQL
					,'bind' => ':contnum'
					,'varType'=>'char'
					,'queryParams'=>[':uid'=>$this->uid]
					,
				],
			'krp_company' =>
				[
				'type' => 'SelectPrep',
				'sql' => <<< SQL
select  distinct krp_company, krpc.name from krp_company krpc
inner join groupe g on g.code ='MTS_' || krpc.krp_company and krpc.inn notnull 
		inner join user_groupe_cache ug on ug.groupe_id=g.groupe_id and ug.user_id=:uid order by krpc.name
SQL
					,'bind' => ':companyname'
					,'queryParams'=>[':uid'=>$this->uid]
					,'varType'=>'char',
				],
			],
			'modelName' => Mts_number::class,
		],
		$dt->filterKey);

$dt->addItem('Data',
	[
		'class' => 'click_tr',
		'columns' => [	'mts_number_id' => ['align' => 'justify',],
						'mts_person_account_id',
						'number',
						'active_date' => ['nobr' => true, 'align' => 'center'],
					],
		'isCheckbox'=>false
	],
				$dt->dataKey);

$data=$dt->items[$dt->dataKey];

$act= function ($this_)
{
	if (empty($this_->dataDB['code']) || empty($this_->dataDB['fms']))//code заполняется кодом krp_company только при наличии прав на нее
	{
		$this_->template='';
		$this_->templateJS='';
	}
	else
	{
		$uri = $this->createURL('/mts/num_remove/id/'.$this_->dataDB['mts_number_id']);
		$this_->url = $uri;
	}
};

$data->addAct('OCAct', ['icon' => 'cancel.png', 'url' => '', 'title' => 'Освободить', 'alt' => 'Освободить',], 'remove');
$data->actionItems['remove']->bbFunc['OCAct']=$act;

?>