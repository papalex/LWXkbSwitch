<?php

use \app\core\gui\Page;
use app\core\gui\_Icon32;

$view=new Page();
Yii::$app->cnt=$view;

$view->addItem('Title', ['label' => 'Статистика МТС', ]);

$view->addItem('IconToolBar', [], $view->iconToolBar);
$toolbar=$view->items[$view->iconToolBar];

$ro = false;
$view->addItem('Tab', ['id' => 'tab',], 'tab');

$tab=$view->items['tab'];
$tab->addItem('TabItem', ['label' => 'Расходы', 'id' => 'amounts',], 'amounts');
$this->render('_list_amounts', ['view' => $tab->items['amounts']]);
$tab->addItem('TabItem', ['label' => 'Документы', 'id' => 'docs',], 'docs');
$this->render('_list_docs', ['view' => $tab->items['docs'],  'ro' => $ro]);

$tab->addItem('TabItem', ['label' => 'Номера', 'id' => 'pnumbers',], 'pnumbers');
$this->render('_list_numbers', ['view' => $tab->items['pnumbers'], 'ro' => $ro]);

//xdd([$tab->items['amounts']->items['report']],5);
$view->out();
?>