<?php
class ExportMtsTo1S
{
	/**
	 * @param $args
	 */
	public function run($args)
	{
		$period_files_id = $args;
		/*
		document_id
		number
		doc_date
		period
		amount
		inn
		 */
		$mpf = Yii::app()->db->createCommand(<<<SQL
select mpf.mts_period_file_id as document_id, mpf.invoice_number as number, mpf.invoice_date as doc_date, mp.period,mpf.amount, company.inn from mts_period_files mpf 
	join mts_period mp on mpf.mts_period_id = mp.mts_period_id
	join krp_company company on mpf.krp_company = company.krp_company
 where mts_period_file_id = :mpfid
SQL
  )->queryRow(true,[':mpfid'=>$period_files_id]);
		z("Начата выгрузка МТС в 1С " );
		if (!Yii::app()->db_old->createCommand(<<<SQL
insert into  mts_out_1c_document(document_id,number,doc_date,period,amount,inn) values(:document_id,:number,:doc_date,:period,:amount,:inn)
SQL
		)->execute($mpf)) x("Ошибка при вставке заголовка в базу 1С.");

		$ins = Yii::app()->db->createCommand(<<<SQL
select 'insert into mts_out_1c_employee select * from json_to_recordset(''' ||
	to_json( array_agg(row (document_id, uid24,amount, limit_amount, discount  ))
	) || ''') as x(f1 bigint, f2 varchar,f3 decimal(12,2),f4 decimal(12,4),f5 decimal(12,4))' as ins
	   from (select mpf.mts_period_file_id as document_id,
u.uid24, sum(ma.cost) as amount,
case when sum(coalesce(mtp.amount,0) - mnmp.amount) >0 then
sum(coalesce(mtp.amount,0) - mnmp.amount)
else 0
end as limit_amount,
sum(ma.discount) as discount from mts_period_files mpf
	join mts_contract mc on mpf.krp_company = mc.krp_company
	join mts_person_account mpa on mc.mts_contract_id = mpa.mts_contract_id
	join mts_number mn on mpa.mts_person_account_id = mn.mts_person_account_id
	join mts_number_mts_period mnmp on mn.mts_number_id = mnmp.mts_number_id and mnmp.mts_period_id = mpf.mts_period_id and mnmp.user_id notnull
	left join mts_tariff_plan mtp on mnmp.mts_tariff_plan = mtp.mts_tariff_plan
	join "user" u on u.user_id=mnmp.user_id
	join mts_aggregate ma on mnmp.mts_number_mts_period_id = ma.mts_number_mts_period_id
where mpf.mts_period_file_id = :mpfid
group by mpf.mts_period_file_id,u.user_id, u.uid24) as foo
	;
SQL
		)->queryScalar([':mpfid'=>$period_files_id]);
		if (!Yii::app()->db_old->createCommand($ins)->execute())x("Ошибка при вставке строк в базу 1С.");
		z('Выгрузка завершена');
	}
}