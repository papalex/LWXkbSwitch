<?php
/**
 * @var $rpt \app\core\gui\ioTablePrep
 */
use \app\models\Mts_number_mts_period;
use \app\models\Mts_aggregate;

$mts_edit =Yii::$app->user->can('MTS_EDIT');
$viewtrue = Yii::$app->user->can('MTS_VIEW_TRUE_AMOUNT');

$view->addItem('ioTablePrep', [
	'isBtn' => false,
	'nameForm' => 'mts_aggregate',
	'db' => Yii::$app->db,
	'alias' => 'mnp',
	'pkey' => 'mts_number_mts_period_id',
	'templateSQL' => <<< SQL
select
		:edit as edit,
		:blocked as blocked,
		:detail as detail,
		u.user_id as own, u.f_ms as fms, mn.number as mts_number, mn.limit_amount, mp.period,
		mnp.mts_period_id, mnp.mts_number_id, mnp.mts_number_mts_period_id,
		mnp.amount as compensation,
		mpa.number as mpanum, mpc.number as contnum, krpc.name as companyname,
		mtp.amount as tariffamount, mtp.abbreviation as tariff,
		agg.mts_service_agg_type as mts_service_agg_type, agg.cost as mts_amount,
		coalesce(blk.blk, 0) as blk,
		case when coalesce(agg.cost, 0) - coalesce(mtp.amount, 0) - mn.limit_amount - mnp.amount > 0 
			then coalesce(agg.cost, 0) - coalesce(mtp.amount, 0) - mn.limit_amount - mnp.amount 
			else 0
			end
			as currentamount

	from mts_number mn
		inner join mts_number_mts_period mnp on mnp.mts_number_id=mn.mts_number_id
												and (:compens isnull or comparator(mnp.amount, :compens, :compenssign)) 
												and (:fms isnull or mnp.user_id notnull)
		inner join mts_period mp on mp.mts_period_id=mnp.mts_period_id
									and (:period isnull or mp.period= :period)
		inner join mts_person_account mpa on mpa.mts_person_account_id=mn.mts_person_account_id
									and (:mpa isnull or mpa.number ilike :mpa)
		inner join mts_contract mpc on mpc.mts_contract_id=mpa.mts_contract_id
									and ( :contnum is null or mpa.mts_contract_id = :contnum)
		inner join krp_company krpc on mpc.krp_company = krpc.krp_company
									and (:companyname is null or krpc.krp_company = :companyname)
									and exists(select 'x' from groupe g
							join user_groupe_cache ugc on ugc.groupe_id=g.groupe_id and ugc.user_id=:uid
			where g.groupe_type='MTS' and g.code in( 'MTS_' || krpc.krp_company))
		left join "user" u on u.user_id=mnp.user_id and (:fms isnull or (mnp.user_id notnull and u.fms ilike :fms))
		left join mts_tariff_plan mtp on mtp.mts_tariff_plan=mnp.mts_tariff_plan 
		left join (select 1 as blk, user_id from groupe g
			inner join user_groupe_cache ug on ug.groupe_id=g.groupe_id
				where g.groupe_type='MTS' and g.code='MTS_BLOCKED') blk on blk.user_id=mn.user_id
		left join (select sum(ma.cost) as cost, ma.mts_number_mts_period_id, array_to_string(array_agg(msat.name), ', ') as mts_service_agg_type
					from mts_aggregate ma
						inner join mts_service_agg_type msat on msat.mts_service_agg_type = ma.mts_service_agg_type
							group by ma.mts_number_mts_period_id) agg on agg.mts_number_mts_period_id=mnp.mts_number_mts_period_id
	where (:limitamount isnull or comparator(mn.limit_amount, :limitamount, :limitsign))
		and (:num isnull or mn.number ilike :num)
		and (:overdraw isnull or comparator(coalesce(agg.cost, 0) - coalesce(mtp.amount, 0) - mn.limit_amount - mnp.amount, :overdraw, :overdrawsign))
		and (:aggtype is null or agg.mts_service_agg_type = :aggtype)
		and (:cost isnull or comparator(agg.cost, :cost, :sign)) 
		and (:fms isnull or u.fms ilike :fms)
		and (:tariff isnull or (mnp.mts_tariff_plan notnull and mtp.mts_tariff_plan = :tariff))
%%srt%%
%%ofst%% %%lmt%%
SQL
	,'aggAddSelect'=>true ,'defaultSort'=>'mp.period desc, u.f_ms'], 'report');

$rpt=$view->items['report'];
$rpt->queryParam = [':uid'=>$this->uid,':period'=>null,':aggtype'=>null,':tariff'=>null,':companyname'=>null,':contnum'=>null,

	':cost'=>null,':sign'=>'=',
	':limitamount'=>null,':limitsign'=>'=',
	':compens'=>null,':compenssign'=>'=',
	':overdraw'=>null,':overdrawsign'=>'=',
	':fms'=>null,
	':mpa'=>null,
	':num'=>null,
	':edit'=>(int)$mts_edit,
	':blocked'=>(int)Yii::$app->user->can('MTS_BLOCKED'),
	':detail'=>(int)Yii::$app->user->can('MTS_DETAIL'),


];
$rpt->aggAddSelect =true;
$rpt->addItem('Pager', ['nameForm' => 'mts_aggregate',], $rpt->pager);
$rpt->addItem('OTable', ['class' => 'it_data_table',
	'modelName' => Mts_aggregate::class,
		'columns' => array_merge([
			'period'=>['label'=>'Период','alias' => 'mp','name'=>'mts_period_id','field'=>'period','type'=>'Month'],
			'fms'=>['label'=>'Владелец','alias'=>'']],
			($viewtrue ?[
				'tariff'=>['alias'=>'','field'=>'tariff','label'=>'Тариф'],
				'tariffamount'=>['label'=>'Тариф. стоимость','alias'=>'']]:[]),[
				'mts_service_agg_type'=>['alias'=>'','field'=>'mts_service_agg_type','varType'=>'str'],
				'limit_amount'=>['label'=>'Доплимит','alias'=>''],
				'compensation'=>['label'=>'Компенсация','alias'=>'','agg'=>'sum'],
				'mts_amount'=>['label'=>'Сумма','alias'=>'','agg'=>'sum'],
				'currentamount'=>['label'=>'Перерасход','alias'=>'','agg'=>'sum'],
				'mts_number'=>['label'=>'Номер тел.','alias'=>'mn','field'=>'number'],
				'mpanum'=>['label'=>'Лиц. счет','alias'=>'mpa','field'=>'number'],
				'contnum'=>['label'=>'Контракт','alias'=>'','field'=>'contnum'],
				'companyname'=>['label'=>'Юр.лицо','alias'=>'','field'=>'companyname'],])
	],
	$rpt->dataTable);

$dt=$rpt->items[$rpt->dataTable];
$dt->addTitleFromModel('Title', ['class' => 'it_head',], $dt->titleKey);
$dt->addItem('Order', ['class' => 'it_sort',
	'columns' => ['mts_number' => ['field' => 'number', ],'mts_service_agg_type'=>['field' => 'mts_service_agg_type']],],
	$dt->orderKey);

$dt->addItem('Filter', ['class' => 'filter',
	'columns' =>
		[
			'mts_number' => ['alias'=>'mn','type' => 'Edit', 'like' => '%_%','varType' => 'char','bind' => ':num'],
			'fms' => ['type' => 'Edit', 'field' => 'fms', 'like' => '%_%', 'varType' => 'char','bind' => ':fms'],
			'mpanum' => ['alias'=>'mn','type' => 'Edit', 'like' => '%_%','varType' => 'char','bind' => ':mpa'],
			'limit_amount'=>['type'=>'Edit','isUserManualOperation'=>true,'bind' => ':limitamount','bindop'=>':limitsign','varType'=>'int'],
			'compensation'=>['type'=>'Edit','isUserManualOperation'=>true,'bind' => ':compens','bindop'=>':compenssign','varType'=>'int'],
			'mts_amount'=>['type'=>'Edit','isUserManualOperation'=>true,'bind' => ':cost','bindop'=>':sign','varType'=>'int'],
			'currentamount'=>['type'=>'Edit','isUserManualOperation'=>true,'bind' => ':overdraw','bindop'=>':overdrawsign','varType'=>'int'],
			'tariff' => ['type' => 'Select', 'bind' => ':tariff','varType'=>'char','isAutoSubmit'=>false,
				'sql' => <<< SQL
select "mts_tariff_plan", abbreviation || ' - ' || name from mts_tariff_plan order by name
SQL
				,],
			'period' => ['type' => 'Select',
				'sql' => <<< SQL
select mts_period_id as pkey, period as name from mts_period order by name
SQL
				,'bind' => ':period','varType'=>'int',
			],
			'contnum' => ['type' => 'Select',
				'sql' => <<< SQL
select  mts_contract_id, number || ' - ' || krpc.name || ' ( ' ||region || ')'as name from mts_contract
	join krp_company krpc on mts_contract.krp_company = krpc.krp_company
	inner join groupe g on g.code = 'MTS_' || krpc.krp_company 
	inner join user_groupe_cache ugc on ugc.groupe_id=g.groupe_id and ugc.user_id=$this->uid
where krpc.inn notnull order by number
SQL
				,'bind' => ':contnum','varType'=>'char',
			],
			'companyname' => ['type' => 'Select',
				'sql' => <<< SQL
select  distinct krpc.krp_company, krpc.name from krp_company krpc 
	inner join groupe g on g.code ='MTS_' || krpc.krp_company 
	inner join user_groupe_cache ugc on ugc.groupe_id=g.groupe_id and ugc.user_id=$this->uid
where krpc.inn notnull order by krpc.name
SQL
				,'bind' => ':companyname','varType'=>'char',
			],

		],
		'modelName' => Mts_number_mts_period::class, ],
	$dt->filterKey);

$dt->addItem('Data', ['class' => 'click_tr',
		'templateURL' => $this->createURL('/mts/show_detail/id/%%pk%%'),
		'isCheckbox' => false,],
	$dt->dataKey);

$data=$dt->items[$dt->dataKey];
$dt->addItem('Summary', ['class' => 'it_summary', 'isTotal' => false, ], $dt->summaryKey);
$data->abFunc['OData']=function ($this_)
{
	if (!$this_->dataDB['detail'] || // Нет просмотра деталей
		(!$this_->dataDB['blocked'] // Не блокированный пользователь
                && $this_->dataDB['blk']) // Блокированный телефон
	    )
		$this_->templateURL='';
};
$ident= function ($this_)
{
	if (!((empty($this_->dataDB['fms']) || empty($this_->dataDB['tariff'])) && ($this_->dataDB['currentamount']) > 0.01)
		|| !$this_->dataDB['edit'])
	{
		$this_->template='';
		$this_->templateJS='';
	}
};
$data->addAct('OCAct', ['icon' => 'add.png', 'url' => 'mts/identify/id/%%pk%%', 'title' => 'Идентифицировать', 'alt' => 'Идентифицировать',], 'ident');
$data->actionItems['ident']->bbFunc['OCAct']=$ident;
$compense= function ($this_)
{
	if (!((($this_->dataDB['currentamount']) > 0.01 || ($this_->dataDB['compensation']) > 0.01))
		|| !$this_->dataDB['edit'])
	{
		$this_->template='';
		$this_->templateJS='';
	}
	else $this_->url = 'mts/compense/id/'.$this_->dataDB['mts_number_mts_period_id'].'/period/'.$this_->dataDB['mts_period_id'];
};
$data->addAct('OCAct', ['icon' => 'payment.png', 'url' => 'mts/compense/id/%%pk%%', 'title' => 'Компенсировать', 'alt' => 'Компенсировать',], 'compense');
$data->actionItems['compense']->bbFunc['OCAct']=$compense;
$fullcompense= function ($this_)
{
	if (!((($this_->dataDB['currentamount']) > 0.01 || ($this_->dataDB['compensation']) > 0.01))
		|| !$this_->dataDB['edit'])
	{
		$this_->template='';
		$this_->templateJS='';
	}
	else $this_->url = 'mts/full_compense/id/'.$this_->dataDB['mts_number_mts_period_id'];
};
$data->addAct('OCAct', ['icon' => 'cost.png', 'url' => 'mts/full_compense/id/%%pk%%', 'title' => 'Полностью компенсировать', 'alt' => 'Полностью компенсировать',], 'fullcompense');
$data->actionItems['fullcompense']->bbFunc['OCAct']=$fullcompense;