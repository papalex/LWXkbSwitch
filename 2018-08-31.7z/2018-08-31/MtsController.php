<?php

namespace app\controllers;

use app\core\Debug;
use app\models\Mts_aggregate;
use app\models\Mts_detail;
use app\models\Mts_number_mts_period;
use app\models\Mts_number;
use app\models\Mts_period_files;
use app\models\Mts_period;
use app\models\User;
use app\models\User_param;
use Dompdf\Exception;
use Yii;
use \app\core\Controller2;
use yii\filters\AccessControl;
use \app\core\HttpException2;

/**
 * @property $mnmp Mts_number_mts_period
 * @property $mpf Mts_period_files
 * @property $mn Mts_number
 */
class MtsController extends Controller2
// Базовый контроллер для модуля МТС
{
	public $activeActions=['admin']; // Активные стандартные действия
	public $modelClass='Mts_aggregate';
	public $accessibleKrpCompany=[];
	public $admin=false;
	public $mnmp;
	public $mn;
	public $mpf;

	public function behaviors()
	{
		return ['access' => ['class' => AccessControl::className(),
			'only' => ['admin','add_number','approve_invoice','show_invoice','show_detail','identify',
				'ac_number','compense','full_compense','phone_list','make_base','num_remove','edit_number_user',
				'ac_user',
			],
			'rules' => [['actions' => ['admin','add_number','approve_invoice','show_invoice','ac_number',
				'compense','full_compense','phone_list','edit_number_user','ac_user',
					],
				'allow' => true, 'roles' => ['MTS_EDIT','MTS_DETAIL','MTS_ADMIN']],
					['actions'=>['show_detail'],'allow'=>true,'roles'=>['MTS_DETAIL']],
					['actions'=>['identify','make_base','num_remove'],'allow'=>true,'roles'=>['MTS_EDIT']],
				],
		],
		];
	}

	public function getCompanyDocs($period=null)
	{
		$krpCombinedStr = implode("|",$this->accessibleKrpCompany);

		$accessibleKrpCompanyData= Yii::$app->db->CreateCommand(<<<SQL
select company.krp_company as krp_company, mpf.is_approve,mpf.period as date, mpf.mts_period_id,company.name from krp_company company
	left join (select mpf.is_approve ,mpf.krp_company,mpf.mts_period_id,mp.period from mts_period_files mpf
		join mts_period mp on mpf.mts_period_id = mp.mts_period_id  and ((:period notnull and mpf.mts_period_id= :period )or (:period isnull and mp.period =(date_trunc('month', now() - interval '1 month')::date)))) as mpf
		on mpf.krp_company = company.krp_company
where company.krp_company =any(string_to_array(:access,'|')) order by mpf.is_approve DESC NULLS LAST

SQL
		)->bindParam(':access',$krpCombinedStr)->bindParam(':period',$period)->queryAll(\PDO::FETCH_ASSOC);

		return $accessibleKrpCompanyData;
	}

	public function actions()
	{
		$actions=parent::actions();
		$defaultReturnURL='/Mts/admin';
		$uid=$this->uid;
		$this->accessibleKrpCompany= Yii::$app->db->CreateCommand(<<<SQL
select company.krp_company as krp_company from krp_company company where 
	(exists(select 'x' from groupe g
					join user_groupe_cache ugc on ugc.groupe_id=g.groupe_id and ugc.user_id=:uid
				where g.code ='MTS_' || company.krp_company)) and company.inn notnull 
SQL
		)->bindParam(':uid',$uid)->queryAll(\PDO::FETCH_COLUMN);
		$actions['admin']=['class' => 'app\core\actions\AdminAction' ];
		$actions['ac_user']=['class' => 'app\core\actions\Ac_userAction',];
		$actions['show_invoice']=['class' => 'app\core\actions\GetFileAction',
			'modelClass' => 'Mts_period_files'];

		return $actions;
	}

	/**
	 * used in /mnt/suz-test2/htdocs/src/protected2/views/mts/_list_amounts.php
	 * @param $id mts_number_mts_period_id
	 * @throws HttpException2
	 * @throws \yii\db\Exception
	 */
	public function actionIdentify($id)
	{
		if (($_POST['is_submit'] ?? false)
				&& ($data=$_POST[Mts_number_mts_period::MODELNAME] ?? false))
		{
			$this->mn->user_id = $data['user_id'] ?? $this->mn->user_id;//если не передано, или передано пустое то не меняется
			$this->mn->limit_amount = $data['limit_amount'] ?? $this->mn->limit_amount;
			$transaction = Yii::$app->db->beginTransaction('READ COMMITTED');
			if ($this->mn->save())
			{
				$this->mnmp->amount = $data['amount'] ?? $this->mnmp->amount ?? 0;
				$this->mnmp->description = $data['description'] ?? $this->mnmp->description;
				$this->mnmp->mts_tariff_plan = $data['mts_tariff_plan'] ?? $this->mnmp->mts_tariff_plan;
				$this->mnmp->user_id = $data['user_id'] ?? $this->mnmp->user_id;
				if ($this->mnmp->save())
				{

					$transaction->commit();
					$this->redirect($this->view->createURL(implode('/', ['mts', 'admin'])));
				}

			}
			else $this->mnmp->addErrors($this->mn->getFirstErrors());



			$transaction->rollBack();
		}

		return $this->render('form_identify', ['model' => $this->mnmp,'redirect'=>'identify']);
	}

	/**
	 * used in /mnt/suz-test2/htdocs/src/protected2/views/mts/_list_docs.php
	 * @param $id mts_period_files_id
	 * @throws HttpException2
	 */
	public function actionApprove_invoice($id)
	{
		$this->mpf->is_approve = true;
		if ($this->mpf->save()) $this->redirect($this->view->createURL("/mts/admin/activeTab/1"));
		else throw new HttpException2(500, $this->mpf->errorToString(),__LINE__);
	}

	/**
	 * used in /mnt/suz-test2/htdocs/src/protected2/views/mts/list_numbers_short.php
	 * @param $term
	 * @throws \yii\db\Exception
	 */
	public function actionAc_number($term)
	{
		$que = <<< SQL
select num.mts_number_id as "value", num.number as "text" from mts_number num
	inner join mts_person_account mpa on num.mts_person_account_id = mpa.mts_person_account_id
	inner join mts_contract contr on mpa.mts_contract_id = contr.mts_contract_id and contr.krp_company = :term
												where num.user_id is null
														--and is_active=0
												order by num.number
SQL;
		$result = Yii::$app->db->CreateCommand($que)->bindValues([':term'=>$term])->queryAll();

		$res = [];
		foreach ($result as $v) $res[] = ['text' => $v['text'], 'value' => $v['value']];
		echo json_encode($res);die();
	}

	/**
	 * used in /mnt/suz-test2/htdocs/src/protected2/views/mts/list_numbers_short.php
	 * @param $id mts_number_id
	 * @param int $period
	 * @return string
	 * @throws HttpException2
	 * @throws \yii\db\Exception
	 */
	public function actionEdit_number_user($id)
	{
		/**
		 * @var $model Mts_number
		 * @var $mnmp Mts_number_mts_period
		 */
		$lastperiod = Yii::$app->db->createCommand(<<<SQL
			select mts_period_id from mts_period order by period desc limit 1
SQL
		)->queryScalar();
		if (($_POST['is_submit']) ?? false && !empty($id))
		{
			$this->mn->limit_amount = empty($_POST['Mts_number']['limit_amount']) ? 0 : $_POST['Mts_number']['limit_amount'];
			$this->mn->mts_tariff_plan = $_POST['Mts_number']['mts_tariff_plan'] ?? null;
			$this->mnmp = Mts_number_mts_period::findOrNew(['mts_number_id' => $id, 'mts_period_id' => $lastperiod]);
			$this->mnmp->mts_tariff_plan = $this->mn->mts_tariff_plan;
			if ($this->mnmp->isNewRecord)
			{
				$this->mnmp->mts_period_id = $lastperiod;
				$this->mnmp->mts_number_id = $this->mn->mts_number_id;
				$this->mnmp->amount = 0;
			}

			$transaction = Yii::$app->db->beginTransaction('READ COMMITTED');
			try
			{
				if ($this->mnmp->save())
				{
					if ($this->mn->save())
					{
						$transaction->commit();
						$this->redirect($this->view->createURL("/mts/phone_list/id/" . $this->mn->user_id), []);
					}
					else
					{
						$this->mn->addError('otherError', 'Сохранить запись номера не удалось');
					}
				}
				$transaction->rollBack();
				$this->mnmp->addError('otherError', 'Сохранить запись номера\периоды не удалось');
				$this->mn->addErrors($this->mnmp->getFirstErrors());
			}catch (\Throwable $e)
			{
				$transaction->rollBack();
				$this->mnmp->addError('otherError', 'Сохранить запись не удалось, из-за неожиданных ошибок');
				$this->mn->addError('otherError', 'Сохранить запись не удалось, из-за неожиданных ошибок');
				if (Debug::developUID())$this->mn->addError('otherError', '<pre>'.$e->getTraceAsString().'</pre>');
				$this->mn->addErrors($this->mnmp->getFirstErrors());
			}
		}
		return $this->render('form_number', ['mts_number' => $this->mn,'redirect'=>'edit_number_user']);
	}

	/**
	 * used in /mnt/suz-test2/htdocs/src/protected2/views/mts/_list_numbers_short.php
	 * @param $id user_id
	 * @throws HttpException2
	 * @throws \yii\db\Exception
	 */
	public function actionAdd_number($id)
	{
		/**
		 * @var $model Mts_number
		 * @var $period Mts_period
		 * @var $user User
		 * @var $mtsNumPer Mts_number_mts_period
		 */

		if (!empty($_POST['is_submit']) && !empty($_POST['Mts_number']['mts_number_id']))
		{
			$this->mn->user_id = $id;
			$this->mn->is_active = 1;

			$lastperiod = Yii::$app->db->createCommand(<<<SQL
			select mts_period_id from mts_period order by period desc limit 1
SQL
			)->queryScalar();
			$period = Mts_period::findOne(['mts_period_id' => $lastperiod]);
			$this->mnmp = Mts_number_mts_period::findOrNew(['mts_number_id' => $this->mn->mts_number_id, 'mts_period_id' => $period->mts_period_id]);

			$this->mnmp->user_id = $id;
			if ($this->mnmp->isNewRecord)
			{
				$this->mnmp->mts_number_id = $this->mn->mts_number_id;
				$this->mnmp->mts_period_id = $period->mts_period_id;
				$this->mnmp->amount = 0;
			}
			$transaction = Yii::$app->db->beginTransaction('READ COMMITTED');
			try
			{
				if (!$this->mn->save())
				{
					$transaction->rollBack();
					throw new HttpException2(500, $this->mn->errorToString(), __LINE__);
				}
				if ($this->mnmp->save())
				{
					$transaction->commit();
					$this->redirect($this->view->createURL("/mts/phone_list/id/" . $id));
				}
				else
				{
					$transaction->rollBack();
					throw new HttpException2(500, $this->mnmp->errorToString(), __LINE__);
				}
			}
			catch (\Throwable $t)
			{
				if ($transaction && $transaction->getIsActive())
					$transaction->rollBack();
				throw $t;
			}
		}
		throw new HttpException2(500, "Номер не удалось найти, хотя этого не ожидалось.", __LINE__);
	}

	/**
	 * used in /mnt/suz-test2/htdocs/src/protected2/views/mts/_list_numbers.php
	 * used in /mnt/suz-test2/htdocs/src/protected2/views/mts/list_numbers_short.php
	 * @param $id mts_number_id
	 * @throws HttpException2
	 * @throws \yii\db\Exception
	 */
	public function actionNum_remove($id)
	{
		/**
		 * @var $model Mts_number
		 * @var $user User
		 */

		$ref = $_SERVER['HTTP_REFERER'] ?? $this->view->createURL("/mts/admin");
		$model = $this->mn;
		if ($model)
		{
			$curPeriodDate = date('Y-m-d',strtotime('first day of now'));

			$period = Mts_period::findOne(['period' => $curPeriodDate]);
			if ($period) // на данном этапе разработки текущего периода нет никогда
			{
				$this->mnmp = Mts_number_mts_period::findOrNew(['mts_number_id' => $this->mn->mts_number_id, 'mts_period_id' => $period->mts_period_id]);
			}
			else
			{
				$this->mnmp  =null;//что бы наверняка
			}
			$newNum = Yii::$app->db->createCommand(<<<SQL
  select number from Mts_number where user_id =:userid and is_active = 1 and mts_number_id <> :curnum limit 1
SQL
			)->bindValues([':userid' => $id, ':curnum' => $model->mts_number_id])->queryScalar();
			$user = User::findOne($model->user_id);
			$transaction = Yii::$app->db->beginTransaction('READ COMMITTED');
			try
			{
				if ($this->mnmp)//модели сейчас не будет
				{
					$this->mnmp->user_id = null;
					if (!$this->mnmp->save())
					{
						$transaction->rollBack();
						throw new HttpException2(500, explode('<br><hr>', [$model->errorToString(), $this->mnmp->errorToString(), $user->errorToString()]),__LINE__);
					}
				}

				$model->user_id = null;
				if (!$model->save())
				{
					$transaction->rollBack();
					throw new HttpException2(500, $model->errorToString(),__LINE__);
				}

                $user->addPhone($newNum,\PHONE_TYPE::WORK);
				if ($user->save())
				{
					$transaction->commit();
					$this->redirect($ref);
				}
				else
				{
					$transaction->rollBack();
					throw new HttpException2(500, $user->errorToString(),__LINE__);
				}
			}
			catch (\Throwable $t)
			{
				if ($transaction && $transaction->getIsActive())
					$transaction->rollBack();
				throw $t;
			}
		}
	}

	/**
	 * used in /mnt/suz-test2/htdocs/src/protected2/views/mts/_list_numbers_short.php
	 * @param $id mts_number_id
	 * @throws HttpException2
	 */
	public function actionMake_base($id)
	{
		/**
		 * @var $user User
		 */
		$user = User::findOne($this->mn->user_id);

        $user->addPhone($this->mn->number,\PHONE_TYPE::WORK);
		if ($user->save()) $this->redirect($this->view->createURL("/mts/phone_list/id/".($this->mn->user__id ?? Yii::$app->user->id)));
		else throw new HttpException2(500, $user->errorToString(),__LINE__);
	}

	/**
	 * used in /mnt/suz-test2/htdocs/src/protected/controllers/UserController.php
	 * @param $id user_id
	 * @return string
	 * @throws HttpException2
	 * @throws \yii\db\Exception
	 */
	public function actionPhone_list($id)
	{

		$usercompany = User_param::findOne($id)->krp_company ?? '';
		return $this->render('list_numbers_short', ['userid' => $id, 'usercompany' => $usercompany]);
	}

	/**
	 * used in /mnt/suz-test2/htdocs/src/protected2/views/mts/_list_amounts.php
	 * @param $id mts_number_mts_period_id
	 * @return string
	 * @throws HttpException2
	 * @throws \yii\db\Exception
	 */
	public function actionCompense($id)
	{
		$url = 'compense';
		if (!empty($_POST['is_submit']))
		{
			$data = $_POST[$this->mnmp::MODELNAME];
			$this->mnmp->amount = $data['amount'] ?? null;
			$this->mnmp->description = $data['description'] ?? null;

			if ($this->mnmp->save())
			{
				$this->redirect($this->view->createURL('/mts/admin'));
			}
		}
		return $this->render('form_compense', ['model' => $this->mnmp,'redirect'=>$url]);
	}

	/**
	 * used in /mnt/suz-test2/htdocs/src/protected2/views/mts/_list_amounts.php
	 * @param $id mts_number_mts_period_id
	 * @throws HttpException2
	 * @throws \yii\db\Exception
	 */
	public function actionFull_compense($id)
	{
		$amount = Yii::$app->db->createCommand(<<<SQL
select
	(sum(aggr.cost) - max(num.limit_amount) - coalesce(max(m2.amount),0)) as currentamount
	from mts_aggregate aggr
		inner join mts_number_mts_period tariff
			on aggr.mts_number_mts_period_id = tariff.mts_number_mts_period_id
		inner join mts_number num
			on num.mts_number_id = tariff.mts_number_id
			left join mts_tariff_plan m2 on tariff.mts_tariff_plan = m2.mts_tariff_plan
where aggr.mts_number_mts_period_id = :id
SQL
)->bindParam(':id',$id)->queryScalar();
		$this->mnmp->amount = $amount;
		$this->mnmp->description .= ' (Полностью)';
		if ($this->mnmp->save())$this->redirect($this->view->createURL('/mts/admin'));
		else throw new HttpException2(500, $this->mnmp->errorToString(),__LINE__);
	}

	/**
	 * used in /mnt/suz-test2/htdocs/src/protected2/views/mts/_list_amounts.php
	 * @param $id mts_number_mts_period_id
	 * @return string
	 */
	public function actionShow_detail($id)
	{
		return $this->render('list_detail', ['model' => $this->mnmp, 'ro' => false]);
	}

	public function beforeAction($action)
	{
		if ($t=parent::beforeAction($action))
		{
			$id=Yii::$app->request->get('id');
			switch (strtolower($action->id))
			{
				case 'add_number':
					if(User::findOne($id))
						throw new HttpException2(404, 'Ничего не найдено',__LINE__);

					$this->checkAccsessMN(Yii::$app->request->post('Mts_number')['mts_number_id'] ?? null);
					if (Yii::$app->user->can('MTS_EDIT')) return true;
				    else throw new HttpException2(403, 'У вас нет доступа на редактирование',__LINE__);
				case 'compense':
				case 'full_compense':
				case 'identify':
					$this->checkAccsessMNMP($id);
				case 'make_base':
				case 'edit_number_user':
				case 'num_remove':
					if (!$this->mn)
						$this->checkAccsessMN($id);
					return true;
				case 'approve_invoice':
				case 'show_invoice':
					$this->mpf = Mts_period_files::findOne($id);
					if (!in($this->mpf->krp_company,$this->accessibleKrpCompany))
						throw new HttpException2(403, 'У вас нет доступа к счету',__LINE__);
					return true;
				case 'phone_list':
					$user = User::findOne($id);
					if(empty($user))
						throw new HttpException2(404, 'Ничего не найдено',__LINE__);
					return true;
				case 'show_detail':
				    $this->checkAccsessMNMP($id);
                    $uid=$this->mnmp->user_id;
				    if (Yii::$app->db->createCommand(<<<SQL
select count(*) from user_groupe_cache
  where user_id = :userid
    and groupe_id = (select groupe_id from groupe where code = 'MTS_BLOCKED')
SQL
					        )->bindParam(':userid', $uid)->queryScalar() && !Yii::$app->user->can('MTS_BLOCKED'))
					    throw new HttpException2(403, 'Просмотр статистики данного сотрудника вам запрещен', __LINE__);
					return true;
				case 'ac_number':
				case 'ac_user':
				case 'admin':
					return true;
					break;
			}
		}
		return false;
	}
	public function checkAccsessMNMP($id)
	{
		if ($this->mnmp = Mts_number_mts_period::findOne($id)) $this->checkAccsessMN($this->mnmp->mts_number_id);
		else throw new HttpException2(404, 'Сочетание номера и периода не найдено',__LINE__);
	}
	public function checkAccsessMN($id)
	{
		if ($this->mn = Mts_number::findOne($id))
		{
			if (!Yii::$app->user->can('MTS_' . $this->mn->mts_person_account_->mts_contract_->krp_company))
				throw new HttpException2(403, 'У вас нет доступа ',__LINE__);
		}
		else throw new HttpException2(404, 'Не найдена номер.',__LINE__);
	}
}
?>
