<?php // на данный момент не используется для редактирования возможны все поля формы
/**
 * @var $iForm app\core\gui\ITable
 * @var $model \app\models\Mts_number
 * @var $contract \app\models\Mts_contract
 * @var $period  \app\models\Mts_period
 * @var $mts_num_per  \app\models\Mts_number_mts_period
 * @var $btn app\core\gui\IEButton
 *
 */
use \app\models\Mts_number_mts_period;
use \app\models\Mts_period;
use \app\core\gui\Page;

$runout =false;
if (!isset($view))
{
	$runout = true;
	$view = new Page();
	$view->addItem('Title', ['label' => 'Идентификация номера - ' . $model->number,]);
}
$view->addItem('ITable', [], 'iForm');

$iForm=$view->items['iForm'];
$iForm->model=$model;

$contract = $model->mts_person_account_->mts_contract_;
if ($period_id === -1)
{
	$curperiod = date('Y-m-d', strtotime('first day of'));
	$period = Mts_period::findOne(['period' => $curperiod]);
}
else
{
	$period = Mts_period::findOne($period_id);
	$curperiod = $period->period;
}
$mts_num_per = Mts_number_mts_period::findOrNew(['mts_number_id'=>$model->mts_number_id,'mts_period_id'=>$period->mts_period_id]);

$ro = isset($ro)? $ro:true;
$accessAdmin = !Yii::$app->user->can('MTS_DETAILS');

$rocontrols = array_map(function($value) {return !$value;},(isset($edt)?$edt:['mts_number_id' => false, 'mts_period_id' => $accessAdmin,  'mts_contract_id' => $accessAdmin,
	'krp_company' => $accessAdmin,  'mts_tariff_plan' => $accessAdmin,  'limit_amount' => $accessAdmin,
	'amount' => $accessAdmin,  'user_id'=>$accessAdmin]));

$iForm->addItem('IESelect', ['name' => 'mts_number_id','sql' => <<< SQL
select mts_number_id as pkey, number as name from mts_number order by number
SQL
	, 'isRequired' => true,  'isReadonly' => $rocontrols['mts_number_id'] ,]);
if (!isset($hidecontrols['mts_period_id']) || !$hidecontrols['mts_period_id'])
{
	$iForm->addItem('IESelect', [
		'label' => 'Период',
		'name' => 'mts_period_id',
		'value' => (empty($period) ? '-1' : $period->mts_period_id),
		'sql' => <<< SQL
select -1 as pkey,cast('$curperiod' as date) as name
union all 
select mts_period_id as pkey, period as name from mts_period order by pkey
SQL
		, 'isRequired' => $edt['mts_period_id'],
		'isReadonly' => $rocontrols['mts_period_id']]);
}
if (isset($hidecontrols['active_date']) && !$hidecontrols['active_date'])
{
	$iForm->addItem('IEDate', ['name' => 'active_date',
		'value' => $model->active_date,
		'isReadonly' => $rocontrols['active_date'] && $accessAdmin]);
}
if (isset($hidecontrols['mts_person_account_id']) && !$hidecontrols['mts_person_account_id'])
{
	$iForm->addItem('IEEdit', ['name' => 'mts_person_account_id',
		'value' => $model->mts_person_account_->number,
		'isReadonly' => $rocontrols['mts_person_account_id'] && $accessAdmin]);
}

$iForm->addItem('IESelectPrep',
	['name'=>'mts_contract_id','label'=>'Контракт',
		'value'=>$contract->mts_contract_id,
		'isReadonly'=>$rocontrols['mts_contract_id'],
		'queryParams'=>[':uid'=>$this->uid],
		'sql'=> <<<SQL
select mts_contract_id, krpc.name || ' (' || contract.number || ')' as name from mts_contract contract
	inner join krp_company krpc on krpc.krp_company=contract.krp_company
	inner join groupe g on g.code='MTS_' || krpc.krp_company
	inner join user_groupe_cache ug on ug.groupe_id=g.groupe_id and ug.user_id=:uid
order by krpc.name, contract.number;
SQL
	]);
if (!isset($hidecontrols['krp_company']) || !$hidecontrols['krp_company'])
	$iForm->addItem('IESelectPrep', ['name' => 'krp_company',
		'label'=>'Юр.лицо',
		'value'=>$contract->krp_company,
		'sql' => <<< SQL
select krpc.krp_company, krpc.name as name from krp_company krpc
	inner join groupe g on g.code='MTS_' || krpc.krp_company
	inner join user_groupe_cache ug on ug.groupe_id=g.groupe_id and ug.user_id=:uid
SQL
		, 'isRequired' => true,
		'isReadonly' => $rocontrols['krp_company'],
		'queryParams'=>[':uid'=>$this->uid],
		'change'=>['url'=>$this->createURL('/mts/ac_number'),'selector'=>'#Mts_number_mts_number_id']]);

	$iForm->addItem('IESelect', ['name' => 'mts_tariff_plan',
		'label'=>'Тарифный план',
		'value'=>empty($mts_num_per)?null:$mts_num_per->mts_tariff_plan,
		'sql' => <<< SQL
select mtp.mts_tariff_plan, mtp.name as name from mts_tariff_plan mtp 
	where mtp.is_visible = 1
SQL
		, 'isRequired' => true,
		'isReadonly' => $rocontrols['mts_tariff_plan'] && (!(empty($mts_num_per) || !$mts_num_per->mts_tariff_plan) || $accessAdmin)
		,]);
if (!isset($hidecontrols['limit_amount']) || !$hidecontrols['limit_amount'])
	$iForm->addItem('IEEdit', ['name' => 'limit_amount',
		'label' => 'Дополнительный лимит',
		'value' => $model->limit_amount,
		'isReadonly' => $rocontrols['limit_amount'] && $accessAdmin,]);
if (!isset($hidecontrols['description']) || !$hidecontrols['description'])
	$iForm->addItem('IEEdit', ['name' => 'description',
		'label' => 'Обоснование',
		'value' => empty($mts_num_per)?0:$mts_num_per->description,
		'isReadonly' => $rocontrols ['description'] && $accessAdmin,]);
if (!isset($hidecontrols['amount']) || !$hidecontrols['amount'])
	$iForm->addItem('IEEdit', ['name' => 'amount',
		'label' => 'Компенсация',
		'value' => empty($mts_num_per)?0:$mts_num_per->amount,
		'isReadonly' => $rocontrols ['amount'] && $accessAdmin,]);
$iForm->addItem('IEAjax',
	[	 'name' => 'user_id',
		'min' => 1,
		'max' => 10000,
		'isOverflow' => true,
		'isRequired' => $edt['user_id'], //так как считаем, что по настроке нельзя редактировать, то и поле не обязательное
		'isReadonly' => $rocontrols['user_id'],
		'autocompleteURL' => $this->createURL('/mts/ac_user'),
	]);

$iForm->addItem('IEMessage', [], 'bl');
$iForm->items['bl']->breakLine();

$iForm->addItem('IEButton', [], 'btn');
$btn=$iForm->items['btn'];
$u=['url' => $this->createURL('mts/'. $redirect.'/id/'.$model->getPkey())];
$btn->addSaveBtn($u);

if ($runout) $view->out();
?>