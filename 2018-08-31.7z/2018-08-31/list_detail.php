<?php
/**
 * @var $aggre \app\models\Mts_aggregate
 * @var $model \app\models\Mts_aggregate
 * @var $numper \app\models\Mts_number_mts_period
 * @var $rpt \app\core\gui\ioTablePrep
 */
use \app\models\Mts_detail;
use \app\core\gui\Page;

$view= new Page();
$numper= $model;
$view->addItem('Title', ['label' => 'Детали - '.$numper->mts_number_->number, ]);
$view->addItem('IconToolBar', [], $view->iconToolBar);
$view->leftDefaultBtn['Back']=['url' => $this->createURL('/mts/admin'),];
$view->addItem('Tab', ['id' => 'tab',], 'tab');
$tab=$view->items['tab'];
$tab->addItem('TabItem', ['label' => 'Основные', 'id' => 'general',], 'general');

$tabitem = $tab->items['general'];
$tabitem->addItem('ioTablePrep', [
	'isBtn' => false,
	'nameForm' => 'mts_detail',
	'db' => Yii::$app->db,
	'alias' => 'details',
	'pkey' => 'mts_detail_id',
	'templateSQL' => <<< SQL
select %%fld%% from mts_detail details
	inner join mts_number_mts_period mnmp on mnmp.mts_number_mts_period_id = details.mts_number_mts_period_id
	inner join mts_number number on number.mts_number_id = mnmp.mts_number_id
	inner join mts_period per on per.mts_period_id = mnmp.mts_period_id
	where (1=1) %%whr%% and mnmp.mts_number_id = :number and mnmp.mts_period_id = :period
%%srt%%
%%ofst%% %%lmt%%
SQL
	, 'defaultSort'=>'service_date desc'], 'report');

$rpt=$tabitem->items['report'];

$rpt->queryParam = [':period'=>$numper->mts_period_id,':number'=>$numper->mts_number_id];
$rpt->addItem('Pager', ['nameForm' => 'numbers',], $rpt->pager);
$rpt->addItem('OTable', ['class' => 'it_data_table','modelName' => Mts_detail::class,
	'columns' => [
		'destination',
		'specified_amount',
		'specified_cost',
		'service_type',
		'service_date'=>['type'=>'Date'],
		'operator_name',
		'operator_division',
	],],

	$rpt->dataTable);
$dt=$rpt->items[$rpt->dataTable];
$dt->addTitleFromModel('Title', ['class' => 'it_head'], $dt->titleKey);

$dt->addItem('Order', ['class' => 'it_sort',
	'columns' => ['service_date' => ['field' => 'service_date',],],],
	$dt->orderKey);

$dt->addItem('Filter', ['class' => 'filter',
	'columns' => [
		'destination' => ['type' => 'Edit', 'like' => '%_%',],
		'specified_amount' => ['type' => 'Edit', 'like' => '%_%',],
		'service_date' => ['varType' => 'date', ],
		'specified_cost'=>['type'=>'Edit','isUserManualOperation'=>true,],

		'service_type' => ['type' => 'Select',
			'sql' => <<< SQL
select  distinct service_type, service_type as pkey from mts_detail where mts_number_mts_period_id = $model->mts_number_mts_period_id
SQL
			,],
		'operator_name' => ['type' => 'Select',
			'sql' => <<< SQL
select  distinct operator_name, operator_name as pkey from mts_detail where mts_number_mts_period_id = $model->mts_number_mts_period_id
SQL
			,],
		'operator_division' => ['type' => 'Select',
			'sql' => <<< SQL
select  distinct operator_division, operator_division as pkey from mts_detail where mts_number_mts_period_id = $model->mts_number_mts_period_id
SQL
			,],
	],
		'modelName' => Mts_detail::class, ],
	$dt->filterKey);

$dt->addItem('Data', ['class' => 'click_tr',
	'columns' => [
		'destination',
		'specified_amount'=> ['align' => 'justify',],
		'specified_cost',
		'service_type',
		'service_date'=> ['nobr' => true, 'align' => 'center',],
		'operator_name',
		'operator_division',
	],
	'isCheckbox'=>false
	],
	$dt->dataKey);

$data=$dt->items[$dt->dataKey];

$this->render('_list_add_service', ['view' => $view, 'model' => $model, 'ro' => $ro]);

$view->out();
?>