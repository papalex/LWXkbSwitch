<?php
/**
 * @var $model \app\models\Mts_aggregate
 * @var $numper \app\models\Mts_number_mts_period
 * @var $rpt \app\core\gui\ioTablePrep
 */


use \app\core\gui\Page;
use \app\core\gui\_Icon32;
use \app\models\Mts_add_service;
$runout =false;
if (!isset($view))
{
	$runout = true;
	$view = new Page();
	$view->addItem('Title', ['label' => 'Детали - ' . $model->mts_number_->number,]);
	$view->addItem('Tab', ['id' => 'tab',], 'tab');
}
$tab=$view->items['tab'];
$tab->addItem('TabItem', ['label' => 'Дополнительные', 'id' => 'additional',], 'additional');

$numper = $model;

$tabitem = $tab->items['additional'];
$tabitem->addItem('ioTablePrep', [
	'isBtn' => false,
	'nameForm' => 'mts_add_service',
	'db' => Yii::$app->db,
	'alias' => 'mas',
	'pkey' => 'mts_add_service_id',
	'templateSQL' => <<< SQL
select %%fld%% from mts_add_service mas
join mts_number_mts_period mnmp on mnmp.mts_number_mts_period_id = mas.mts_number_mts_period_id
	where (1=1) %%whr%% and mnmp.mts_number_id = :number and mnmp.mts_period_id = :period
%%srt%%
%%ofst%% %%lmt%%
SQL
	, 'defaultSort'=>'name asc'], 'report');

$rpt=$tabitem->items['report'];

$rpt->queryParam = [':period'=>$numper->mts_period_id,':number'=>$numper->mts_number_id];

$rpt->addItem('Pager', ['nameForm' => 'numbers',], $rpt->pager);
$rpt->addItem('OTable',
				['class' => 'it_data_table',
					'modelName' => Mts_add_service::class,
					'columns' => ['name',
								'cost',
								'service_date'=>['type'=>'Date','label'=>'Дата'],
					],
				],
				$rpt->dataTable);
$dt=$rpt->items[$rpt->dataTable];
$dt->addTitleFromModel('Title', ['class' => 'it_head'], $dt->titleKey);

$dt->addItem('Order',
		['class' => 'it_sort',
		'columns' => ['service_date' => ['field' => 'service_date',],],],
		$dt->orderKey);

$dt->addItem('Filter', ['class' => 'filter',
				'columns' => [
					'service_date' => ['type' => 'Date', ],
					'cost'=>['type'=>'Edit','isUserManualOperation'=>true,],
					'name' => ['type' => 'Select',
						'sql' => <<< SQL
select  distinct name , name as pkey from mts_add_service where mts_number_mts_period_id = $model->mts_number_mts_period_id
SQL
							,
						],
					],
				'modelName' => Mts_add_service::class,
				],
				$dt->filterKey);

$dt->addItem(	'Data',
				['class' => 'click_tr',
				    'columns' => [
								'name'=>['align' => 'justify',],
								'cost',
								'service_date'=> ['nobr' => true, 'align' => 'center',],
					],
					'isCheckbox'=>false
				],
				$dt->dataKey);

$data=$dt->items[$dt->dataKey];
if ($runout) $view->out();
?>