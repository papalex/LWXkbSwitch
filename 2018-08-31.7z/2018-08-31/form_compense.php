<?php
/**
 * @var $iForm app\core\gui\ITable
 * @var $model \app\models\Mts_number_mts_period
 * @var $contract \app\models\Mts_contract
 * @var $period  \app\models\Mts_period
 * @var $mts_number \app\models\Mts_number
 * @var $btn app\core\gui\IEButton
 *
 */
use \app\models\Mts_number_mts_period;
use \app\models\Mts_period;
use \app\core\gui\Page;
$mts_number = $model->mts_number_;
$view = new Page();
$view->addItem('Title', ['label' => 'Компенсация - ' . $mts_number->number,]);
$view->addItem('IconToolBar', [], $view->iconToolBar);
$view->leftDefaultBtn['Back']=['url' => $this->createURL('/mts/admin'),];
$view->leftDefaultBtn['ChangeOwner']=[];

$view->addItem('ITable', [], 'iForm');

$iForm=$view->items['iForm'];
$iForm->model=$model;

$contract = $mts_number->mts_person_account_->mts_contract_;
$mtp = $model->mts_tariff_plan_;
$accessAdmin = !Yii::$app->user->can('MTS_DETAILS');

$iForm->addItem('IESelect', ['name' => 'mts_number_id','sql' => <<< SQL
select mts_number_id as pkey, number as name from mts_number order by number
SQL
	,  'isReadonly' => true ,]);
$iForm->addItem('IEEdit', [
		'label' => 'Период',
		'name' => 'mts_period_id',
		'value' => $model->mts_period_->period,
		'isReadonly' => true]);
$iForm->addItem('IEEdit',
	['name'=>'mts_contract_id','label'=>'Контракт',
		'value'=>$contract->number ." ({$contract->krp_company_->name})",
		'isReadonly'=>true,
	]);
$iForm->addItem('IEEdit', ['name' => 'mts_tariff_plan',
	'label'=>'Тарифный план',
	'value'=>empty($mtp)?null:$mtp->name,
	'isReadonly' => true
	,]);

$iForm->addItem('IEEdit', ['name' => 'limit_amount',
	'label' => 'Дополнительный лимит',
	'value' => $mts_number->limit_amount,
	'isReadonly' =>true,]);

$iForm->addItem('IEEdit', ['name' => 'description',
	'label' => 'Обоснование',
	'value' => empty($model)?0:$model->description,
	'isReadonly' => !$accessAdmin,]);

$iForm->addItem('IEEdit', ['name' => 'amount',
	'label' => 'Компенсация',
	'value' => empty($model)?0:$model->amount,
	'isReadonly' => !$accessAdmin,]);

$iForm->addItem('IEAjax',
	[	'name' => 'user_id',
		'min' => 1,
		'max' => 10000,
		'isOverflow' => true,
		'isReadonly' => true,
		'autocompleteURL' => $this->createURL('/mts/ac_user'),
	]);

$iForm->addItem('IEMessage', [], 'bl');
$iForm->items['bl']->breakLine();

$iForm->addItem('IEButton', [], 'btn');
$btn=$iForm->items['btn'];
$u=['url' => $this->createURL('mts/'. $redirect.'/id/'.$model->getPkey())];
$btn->addSaveBtn($u);

$view->out();
?>