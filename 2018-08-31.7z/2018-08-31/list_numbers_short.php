<?php
/**
 * @var $rpt \app\core\gui\ioTablePrep
 */
use \app\core\gui\Page;
use \app\models\Mts_number;
use \app\models\Mts_period;

$view=new Page();
Yii::$app->cnt=$view;

$view->addItem('Title', ['label' => 'Номера МТС', ]);
$view->addItem('IconToolBar', [], $view->iconToolBar);
$view->leftDefaultBtn['Back']=['url' => '/user/update/id/'.$userid,];
$view->leftDefaultBtn['ChangeOwner']=[];
$view->addItem('ITable', [], 'iForm');
$iForm=$view->items['iForm'];

$iForm->model=new Mts_number();


if (Yii::$app->user->can('MTS_EDIT'))
{
	$curperiod = date('Y-m-d', strtotime('first day of'));
	$period = Mts_period::findOne(['period' => $curperiod]);
	$iForm->addItem('IESelectPrep', ['name' => 'krp_company', 'label' => 'Юр.лицо','value' => $usercompany, 'sql' => <<< SQL
select krpc.krp_company, krpc.name as name from krp_company krpc
	inner join groupe g on g.code='MTS_' || krpc.krp_company
	inner join user_groupe_cache ug on ug.groupe_id=g.groupe_id and ug.user_id=:uid
where (1=1)
SQL
		, 'isRequired' => true, 'isReadonly' => false, 'queryParams' => [':uid' => $userid], 'change' => ['url' => $this->createURL('/mts/ac_number'), 'selector' => '#Mts_number_mts_number_id']]);
	$iForm->addItem('IESelectPrep', ['name' => 'mts_number_id', 'readonly' => true, 'sql' => <<< SQL
select mts_number_id as pkey, number as name from mts_number where is_active=1 and user_id isnull order by number
SQL
		, 'isRequired' => true, 'isReadonly' => false,]);
	$iForm->addItem('IEMessage', [], 'bl');
	$iForm->items['bl']->breakLine();

	$iForm->addItem('IEButton', ['label'=>'Добавить'], 'btn');
	$btn=$iForm->items['btn'];
	$u=['url' => $this->createURL('mts/add_number/id/'.$userid)];
	$btn->addSaveBtn($u,['label'=>'Добавить']);
}
$view->addItem('ioTablePrep', [
	'isBtn' => false,
	'nameForm' => 'mts_number',
	'db' => Yii::$app->db,
	'alias' => 'num',
	'pkey' => 'mts_number_id',
	'templateSQL' => <<< SQL
select mts_number_id,number,mts_tariff_plan,limit_amount,(mobile_phone = num.number) as base from mts_number num
	join  "user" own on own.user_id =num.user_id
	              and own.user_id = :userid
  where (1=1) %%whr%%
%%srt%%
%%ofst%% %%lmt%%
SQL
		,'queryAgg' => <<< SQL
select count(*) as cnt from mts_number num
	join  "user" own on own.user_id =num.user_id
	              and own.user_id = :userid
  where (1=1) %%whr%%
%%srt%%
%%ofst%% %%lmt%%
SQL
	, ], 'report');


$rpt=$view->items['report'];
$rpt->queryParam =[':userid'=>$userid];


$rpt->addItem('IconToolBar', [], [], $rpt->iconToolBar);

$rpt->addItem('Pager', ['nameForm' => 'numbers',], $rpt->pager);
$rpt->addItem('OTable', ['class' => 'it_data_table','modelName' => Mts_number::class,
									'columns' => [
										'number',
										'mts_tariff_plan',
										'limit_amount',
										'base'=>['label' =>'Основной','alias'=>'own','asis'=>true, 'field'=>'base'],
													],],

			$rpt->dataTable);
	$dt=$rpt->items[$rpt->dataTable];

	$dt->addTitleFromModel('Title', ['class' => 'it_head'], $dt->titleKey);

	$dt->addItem('Order', ['class' => 'it_sort',
			'columns' => ['number' => ['field' => 'number',],],],
			$dt->orderKey);

	$dt->addItem('Data', ['class' => 'click_tr',
					'columns' => [ 'number' => ['align' => 'justify',],
									'tariff_plan_id',
									'limit_amount',
									'base' => ['nobr' => true, 'align' => 'center','type'=>'bool'],
						],
					'templateURL' => $this->createURL('/mts/edit_number_user/id/%%pk%%'),
					'isCheckbox'=>false
					],
					$dt->dataKey);

	$data=$dt->items[$dt->dataKey];
	$data->addAct('OCAct',
		[	'icon' => 'cancel.png',
			'url' => 'mts/num_remove/id/%%pk%%',
			'title' => 'Забрать',
			'alt' => 'Забрать',
		],
		'remove');
	$data->addAct('OCAct',
		[	'icon' => 'OK.png',
			'url' => 'mts/make_base/id/%%pk%%',
			'title' => 'Сделать основным',
			'alt' => 'Сделать основным',
		],
		'make_base');

	$view->out($view);
?>