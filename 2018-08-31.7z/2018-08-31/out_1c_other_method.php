<?php
function docuReady($period=null)//перенесена из контроллера в эту тестовую вьюху за ненадобностью в контроллере
{
	$uid =Yii::$app->user->getId();
	$accessibleKrpCompany= Yii::$app->db->CreateCommand(<<<SQL
select company.krp_company as krp_company from krp_company company where
	exists(select 'x' from groupe g
					join user_groupe_cache ugc on ugc.groupe_id=g.groupe_id and ugc.user_id=:uid
				where g.code ='MTS_' || company.krp_company)
SQL
	)->bindParam(':uid',$uid)->queryAll(\PDO::FETCH_COLUMN);
	$krpCombinedStr = implode("<br>",$accessibleKrpCompany);
	$a= Yii::$app->db->CreateCommand(<<<SQL
select kc.krp_company, kc.name, sum(mpf.is_approve),mp.period from mts_period_files mpf
		inner join krp_company kc on kc.krp_company = mpf.krp_company
		inner join mts_period mp on mpf.mts_period_id= mp.mts_period_id 
			and ((:period isnull and mp.period=(select cast(date_trunc('month', now() -  interval '1 months') as date)) or (:period notnull and mp.period=:period))
		 	and kc.krp_company =any(string_to_array(:access,'<br>'))
		 --where mpf.is_approve=1
		group by kc.krp_company,kc.name,mp.period
SQL
	)->bindValues([':access'=>$krpCombinedStr,':period'=>$period])->queryAll(\PDO::FETCH_ASSOC);

	$key = 'krp_company';
	$combo = [];
	/* какой вариант быстрее надо смотреть
	  $combo = array_combine(array_map(function($m) use ($key){
		return $m[$key];
	},$a),$a);
	$combo= arrayLevelDegrade(array_map(function($m){
		return ['key'=>$m['krp_company'],'val'=>$m];
	},$a));
	*/
	if (empty($a))
	{
		array_map(function ($item)use (&$combo,$key){  $combo[$item] = [$key=>$item,'sum'=>0] ;},$accessibleKrpCompany);
		return $combo;
	}

	array_map(
		function ($item) use (&$combo,$key) {$combo[$item[$key]] = $item;}
		,$a);
	return  $combo;
}
$ctrl = $this->context;
/**
 * @var $ctrl \app\controllers\MtsController
 */
$companies = $ctrl->getCompanyDocs($period);
$combo=[0,0,0];
$params = [
	['condition'=>1,'title'=>'Одобрено','img'=>'yes.png'],
	['condition'=>0,'title'=>'Нет документов','img'=>'delete.png'],
	['condition'=>function($v){return is_null($v);},'title'=>'Не утверждены','img'=>'no.png']
];
$conditionKey ='is_approve';
$combostr=<<<HTML

<style>.infoblock{margin: 1vh;display: flex;flex-wrap: wrap;justify-content: space-evenly;flex-basis: fit-content;}
.infoblock li{list-style: none;}
.infoblock > li{box-sizing: border-box;-moz-box-sizing: border-box;margin: 0.1vh; background-color: rgb(229, 241, 244);padding: 1%;}
.infoblock > ul > li > img{margin-left:0.3vw;}
.infoblock > ul > li:first-child{list-style: none;font-size: large;}
</style><div class="infoblock">

HTML;
$key ='krp_company';
$lastcond = null;
ob_start();
foreach ($companies as $k=>$item)
{

	foreach ($params as $parmid=>$param)
	{

		if (is_object($param['condition']) and $param['condition']($item[$conditionKey]))
		{
			break;
		}
		else if($param['condition'] === $item[$conditionKey])
		{
			break;
		}
		else if(is_null($lastcond))
		{?>
			<ul><li><?=$params[$parmid]['title']; $params[$parmid]['outputed'] =1;?></li></ul>
			<?php
		}
		else if (empty($params[$parmid]['outputed']))
		{if ($cnt>2){?>
			</details><?php }?>
			</ul><ul><li><?=$params[$parmid]['title']; $params[$parmid]['outputed'] =1;?></li></ul>
			<?php
		}
	}
	if ($parmid !== $lastcond)
	{?>
		<?php if (!is_null($lastcond))
	{	if ($cnt>2){?>
		</details>
	<?php } ?>
		</ul>
		<?php
	}
		?><ul><li><?=$params[$parmid]['title']?></li><?php $params[$parmid]['outputed'] =1;
		$cnt =0;
		$lastcond = $parmid;
	}
	$cnt++;
if ($cnt===3){?>
	<details><summary>Еще ....</summary>
<?php }?>
	<li title="<?=$params[$parmid]['title']?>"><?=$item['name']?><img  alter="<?=$params[$parmid]['title']?>" src="/dsn/ico/16/<?=$params[$parmid]['img']?>"> </li>
	<?php
}
$combostr .=ob_get_clean() .'<div>';
$view->addItem('IEMessage', ['label' => 'Данные по компаниям', 'message' => $combostr, 'countLine' => 1,],'company_data');
$view->items['bl']->breakLine();
