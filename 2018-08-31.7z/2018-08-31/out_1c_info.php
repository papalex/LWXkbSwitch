<?php

$ctrl = $this->context;
/**
 * @var $ctrl \app\controllers\MtsController
 */
$companies = $ctrl->getCompanyDocs($period);
$combostrNone='<ul><li>Нет документов</li>';
$combostrNoPruve='<ul><li>Не утверждены</li>';
$combo=[0,0,0];
$params = [
	['condition'=>1,'title'=>'Одобрено','img'=>'yes.png'],
	['condition'=>0,'title'=>'Нет документов','img'=>'delete.png'],
	['condition'=>function($v){return is_null($v);},'title'=>'Не утверждены','img'=>'no.png']
];
$conditionKey ='is_approve';
$combostr=<<<HTML

<style>.infoblock{margin: 1vh;display: flex;flex-wrap: wrap;justify-content: space-evenly;flex-basis: fit-content;}
.infoblock li{list-style: none;}
.infoblock > li{box-sizing: border-box;-moz-box-sizing: border-box;margin: 0.1vh; background-color: rgb(229, 241, 244);padding: 1%;}
.infoblock > ul img{margin-left:0.3vw;}
.infoblock > ul > li:first-child{list-style: none;font-size: large;}
</style><div class="infoblock">

HTML;
$key ='krp_company';
$lastcond = null;
$combostr.="<ul><li>Одобрено</li>";
array_map(function ($item)use (&$combo,&$combostr,&$combostrNone,&$combostrNoPruve,&$params,&$lastcond,$key)
{
	if ($item['is_approve'])
	{
		if ($combo[0]===2)
		{
			$combostr .= '<details ><summary> Еще ....</summary>';
		}
		$combostr .= '<li title="Одобрено">'.$item['name'].'<img  alter="Одобрено" src="/dsn/ico/16/yes.png"> </li>';
		$combo[0]++;
	}
	else if (is_null($item['is_approve']))
	{
		if ($combo[1]===2)
			$combostrNone .= '<details ><summary> Еще ....</summary>';
		//_Icon32::Cancel
		$combostrNone .= '<li title="Нет документов">'.$item['name'].'<img  alter="Нет документов" src="/dsn/ico/16/delete.png"> </li>';
		$combo[1]++;
	}
	else
	{
		if ($combo[2]===2)
			$combostrNoPruve .= '<details ><summary> Еще ....</summary>';

		$combostrNoPruve .= '<li title="Нет документов">'.$item['name'].'<img  alter="Не утверждены" src="/dsn/ico/16/no.png"> </li>';
		$combo[2]++;
	}

	$combo[$item[$key]] = $item;
}
	,$companies);
$combostr .= ($combo[0]>2 ? '</details>' : '');
$combostrNoPruve .= ($combo[1]>2 ? '</details>' : '');
$combostrNone .= ($combo[2]>2 ? '</details>' : '');

$combostr = implode('</ul>',[$combostr,$combostrNoPruve,$combostrNone]).'</ul></div>';
$view->addItem('IEMessage', ['label' => 'Данные по компаниям', 'message' => $combostr, 'countLine' => 1,],'company_data');
$view->items['bl']->breakLine();
