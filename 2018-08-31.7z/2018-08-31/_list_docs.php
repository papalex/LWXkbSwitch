<?php
/**
 * @var $rpt \app\core\gui\ioTablePrep
 */
use \app\core\gui\_Icon32;
use \app\models\Mts_period_files;

/*lex--> */
$view->addItem('ioTablePrep',  [
	'isBtn' => false,
	'nameForm' => 'mts_files',
	'db' => Yii::$app->db,
	'alias' => 'files',
	'pkey' => 'mts_period_file_id',
	'hideField' => ['unidentifyed' ],
	'templateSQL' => <<< SQL
select %%fld%% from(select t.mts_period_file_id,
	company.name as name,
	mpf.invoice_number,
	mpf.invoice_date,
	mpf.create_date,
	sum(t.amount) as mtsamount,
	mpf.amount,
	mpf.is_approve,
	sum(case when abs(t.amount)>0.01 and t.cnt1<>t.cnt2 then 1 else 0 end)<>0 as unidentifyed
from (select mpf.mts_period_file_id, sum(ma.cost+ma.discount) as amount, count(*) as cnt1, sum(case when mnp.user_id is null then 0 else 1 end) as cnt2 from mts_period_files mpf
	inner join mts_number_mts_period mnp on mnp.mts_period_id=mpf.mts_period_id --and mpf.mts_period_id = 27
	inner join mts_contract mc on mc.krp_company=mpf.krp_company
	inner join mts_person_account mpa on mpa.mts_contract_id=mc.mts_contract_id
	inner join mts_number mn on mn.mts_person_account_id=mpa.mts_person_account_id
								and mn.mts_number_id=mnp.mts_number_id
	inner join mts_aggregate ma on ma.mts_number_mts_period_id=mnp.mts_number_mts_period_id
group by mpf.mts_period_file_id, mnp.mts_number_id ) as t
	inner join mts_period_files mpf on mpf.mts_period_file_id=t.mts_period_file_id
	join krp_company company on mpf.krp_company = coalesce(:companyname,company.krp_company) and exists(select 'x' from groupe g
					join user_groupe_cache ugc on ugc.groupe_id=g.groupe_id and ugc.user_id=:uid
				where g.code ='MTS_' || company.krp_company)		
group by t.mts_period_file_id,mpf.invoice_number, mpf.invoice_date,mpf.create_date,mpf.amount,mpf.is_approve,company.name) as files
	where (1=1) %%whr%%
%%srt%%
%%ofst%% %%lmt%%
SQL
	, 'defaultSort'=>'invoice_date desc, files.name asc'], 'report');

$rpt=$view->items['report'];
$rpt->addItem('Title', ['label' => 'Документы', ], 'title');

$rpt->queryParam = [':companyname' => null, ':uid'=>$this->uid];
if (!$ro && isset($model))
{
	$rpt->addItem('IconToolBar', [], [], $rpt->iconToolBar);
	$rpt->items[$rpt->iconToolBar]->addItem('IconToolBarItem', ['label' => 'Добавить', 'image' => _Icon32::Create, 'url' => $this->createURL('/mts/add_number/id/'.$model->getPkey()),]);
	$rpt->items[$rpt->iconToolBar]->addItem('IconToolBarItem', ['label' => 'Добавить с созданием', 'image' => _Icon32::CreateAdd, 'url' => $this->createURL('/mts/number/create/aggregate_id/'.$model->getPkey()),]);
}

$rpt->addItem('Pager', ['nameForm' => 'numbers',], $rpt->pager);
$rpt->addItem('OTable', ['class' => 'it_data_table','modelName' => Mts_period_files::class,
	'columns' => [
		'krp_company'=>['label' =>'Юр.лицо','alias'=>'files','field'=>'name','name'=>'name'],
		'invoice_number'=>['label'=>'Номер счета','alias'=>'files'],
		'invoice_date'=>['label'=>'Дата счета','type'=>'Date'],
		'mtsamount'=>['label'=>'Сумма разобрано','alias'=>'files','agg'=>'sum'],
		'amount'=>['label'=>'Сумма','agg'=>'sum'],
		'create_date'=>['label'=>'Дата передачи','type'=>'Date'],
		'is_approve'=>['type'=>'Bool'],
	],],

	$rpt->dataTable);
$dt=$rpt->items[$rpt->dataTable];
$dt->addTitleFromModel('Title', ['class' => 'it_head',], $dt->titleKey);

$dt->addItem('Order', ['class' => 'it_sort',
	'columns' => ['mts_number_id' => ['field' => 'mts_number_id',],],],
	$dt->orderKey);

$dt->addItem('Filter', ['class' => 'filter',
	'columns' => [
		'invoice_number' => ['type' => 'Edit', 'like' => '%_%',],
		'create_date' => ['type' => 'Date', ],
		'mtsamount'=>['type'=>'Edit','isUserManualOperation'=>true,],
		'amount'=>['type'=>'Edit','isUserManualOperation'=>true,],
		'krp_company' => ['type' => 'SelectPrep',
			'sql' => <<< SQL
select  distinct krp_company, krpc.name from krp_company krpc
inner join groupe g on g.code ='MTS_' || krpc.krp_company and krpc.inn notnull 
		inner join user_groupe_cache ug on ug.groupe_id=g.groupe_id and ug.user_id=:uid order by krpc.name
SQL
			,'bind' => ':companyname','varType'=>'char','queryParams'=>[':uid'=>$this->uid]
		],


	],
		'modelName' => Mts_period_files::class, ],
	$dt->filterKey);

$dt->addItem('Data', ['class' => 'click_tr',
	'columns' => [ 'krp_company' => ['align' => 'justify',],
		'mts_person_account_id',
		'invoice_number',
		'create_date' => ['nobr' => true, 'align' => 'center',],
		'is_approve' => ['type' => 'Bool'],
	],
	'templateURL' => $this->createURL('/mts/show_invoice/id/%%pk%%'),
	'isCheckbox'=>false
	],
	$dt->dataKey);

$data=$dt->items[$dt->dataKey];
$data->templateJS = <<< JS
$("#%%id%%").click(
function()
{
    var win = window.open('%%url%%', '_blank');
    win.focus();    
});
JS;


$act= function ($this_)
{
	if($this_->dataDB['unidentifyed'] || (
		$this_->dataDB['is_approve']
		|| $this_->dataDB['mtsamount'] === $this_->dataDB['amount']
		|| !Yii::$app->user->can('MTS_EDIT') ))
	{
		$this_->template='';
		$this_->templateJS='';
	}
};
$data->addAct('OCAct', ['icon' => 'yes.png', 'url' => 'mts/approve_invoice/id/%%pk%%', 'title' => 'Утвердить', 'alt' => 'Утвердить',], 'edit');
$data->actionItems['edit']->bbFunc['OCAct']=$act;
?>

