<?php
Yii::import('core_app.components.Action');

class DeleteAction extends Action
{
	public $act='actionDelete'; // Действие
	public $redirect=''; // Переадресация
	
	public function run()
	{
		if (!array_key_exists($this->key, $_GET)) throw new CHttpException(404);
		
		$model=ActiveRecord::model($this->modelClass)->findByPk($this->isInt ? (int)$_GET[$this->key] : $_GET[$this->key]);

		if ($model)
		{
			if ($this->SaveLog($model->{$model->primaryKey()}))
			{

				if ($this->redirect) eval('$this->redirect='.$this->redirect.";");
				else $this->redirect='/'.strtolower($this->modelClass).'/'.$this->defaultRediredct;

				if ($model->delete()) Yii::app()->request->redirect($this->redirect);
				else throw new CHttpException(500, 'Не удалось удалить запись');
			}
			else throw new CHttpException(500, 'Не удалось записать факт удаления записи');
		}
		else throw new CHttpException(404);
	}
}
?>
