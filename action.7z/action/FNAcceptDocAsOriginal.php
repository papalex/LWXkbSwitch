<?php
/**
 * Created by PhpStorm.
 * User: kruchinin
 * Date: 14.03.18
 * Time: 14:26
 */

class FNAcceptDocAsOriginal
{
	/**
	 * @param $args
	 */
	public function run($args)
	{
		$task_id = $args;

		require_once "/srv/www/htdocs/src/protected/models/Dictonary_old.php";

		$document_id = Yii::app()->doc_db->createCommand(<<<SQL
select document_id
		from document d
		where d.task_id = $task_id
SQL
				)->queryScalar();

		if ($document_id)
		{
			$rc = Register_contract::model()->findByAttributes(['document_id' => $document_id]);
			if ($rc)
			{
				$rc->original_type = Register_contract::ORIGINAL_TYPE_ORIGINAL;
				if (!$rc->save())
					z('Ошибка при отметке о наличии оригинала.');
			}
			else
				z('Документ не зарегистрирован в реестре договоров');
		}
		else
			z('Документ не найден.');
	}
	public static function getOld()
	{
		$old = <<<'SQL'
CREATE OR REPLACE FUNCTION public.fn_td_event_cld_accept_document_as_original(sid bigint)
 RETURNS SETOF character varying
 LANGUAGE plpgsql
AS $function$
declare
    is_regscan smallint;
    tid bigint;
BEGIN

    select task_id into tid from subtask where subtask_id=sid;
    select _int into is_regscan from task_param where task_id=tid and task_diag_param='IS_PRESENT_ORIGINAL';

    if is_regscan = 1 then

    insert into crond_task (script) values ('

    $task_id = ' || tid || ';

    require_once "/srv/www/htdocs/src/protected/models/Dictonary_old.php";

	CActiveRecord::$db = Yii::app()->doc_db;
	$document_id = Yii::app()->doc_db->createCommand("select document_id"
								." from document d"
								." where d.task_id = $task_id")->queryScalar();
	if ($document_id)
	{
		$rc = Register_contract::model()->findByAttributes(array(''document_id'' => $document_id));
		if ($rc)
		{
			$rc->original_type = ''ORIGINAL'';
			if (!$rc->save())
				z(''Ошибка при отметке о наличии оригинала.'');
		}
		else
			z(''Документ не зарегистрирован в реестре договоров'');
	}
	else
		z(''Документ не найден.'');

;');

    end if;

    return query (select cast(null as varchar));

END;$function$
SQL;
		return $old;
	}
}