<?php
/**
 * Created by PhpStorm.
 * User: kruchinin
 * Date: 14.03.18
 * Time: 14:26
 */

class FNCreateDocumentDA
{
	/**
	 * @param $args
	 */
	public function run($args)
	{
		$task_id = $args;

		require_once "/srv/www/htdocs/src/protected/models/Dictonary_old.php";
		Yii::import("doc.models.Document");
		Yii::import("doc.models.File2");

		$file=Task_file::model()->find("link='".Yii::app()->db->CreateCommand("select _text from task_param tp where tp.task_id=$task_id and task_diag_param='CURRENT_VERSION'")->queryScalar()."'");

		if ($file)
		{
			/* Грузим в память все файлы, чтобы потом не переставлять источники данных*/
			$docFileList=Yii::app()->db->CreateCommand("select _text from task_param tp where tp.task_id=$task_id and task_diag_param='INTEGRATED_FILE'")->queryScalar();
			if ($docFileList)
			{
				$docFileList=unserialize($docFileList);
				foreach ($docFileList as $k => $v)
					$docFileList[$k]["file"]=Task_file::model()->findByPk($v["task_diag_file_id"]);
			}

			$model=new Document();
			$model->task_id=$task_id;
			/* Готовим общие переменные */
			$model->name=Yii::app()->db->CreateCommand("select _varchar from task_param tp where tp.task_id=$task_id and task_diag_param='NAME'")->queryScalar();
			$model->is_important_on_probation=Yii::app()->db->CreateCommand("select _int from task_param tp where tp.task_id=$task_id and task_diag_param='IS_IMPORTANT_ON_PROBATION'")->queryScalar();
			$model->is_important_on_probation=$model->is_important_on_probation ? 1 : 0;
			$rs=Yii::app()->db->CreateCommand("select _int as user_id, fn_get_department(cast(_int as integer)) as groupe_id from task_param tp where tp.task_id=$task_id and task_diag_param='PUBLISHER'")->queryRow();
			$model->user_id=$rs["user_id"];
			$model->owner=$model->user_id;
			$model->groupe_id=$rs["groupe_id"];
			$model->keyword=Yii::app()->db->CreateCommand("select _varchar from task_param tp where tp.task_id=$task_id and task_diag_param='KEYWORDS'")->queryScalar();
			$model->sbe_groupe_id=Yii::app()->db->CreateCommand("select _int from task_param tp where tp.task_id=$task_id and task_diag_param='ACTIVITY'")->queryScalar();
			$model->is_public=Yii::app()->db->CreateCommand("select _int from task_param tp where tp.task_id=$task_id and task_diag_param='IS_ACCESS_KRP'")->queryScalar();
			$model->is_public=$model->is_public ? 1 : 0;
			$model->is_sbe_public=Yii::app()->db->CreateCommand("select _int from task_param tp where tp.task_id=$task_id and task_diag_param='IS_ACCESS_SBE'")->queryScalar();
			$model->is_sbe_public=$model->is_sbe_public ? 1 :0;
			$model->document_type=Yii::app()->db->CreateCommand("select _varchar from task_param tp where tp.task_id=$task_id and task_diag_param=:tdparm")->queryScalar([':tdparm'=>Task_diag_param::DOCUMENT_TYPE]);
			$model->activity_type=Yii::app()->db->CreateCommand("select _varchar from task_param tp where tp.task_id=$task_id and task_diag_param=:tdparm")->queryScalar([':tdparm'=>Task_diag_param::ACTIVITY_TYPE]);
			$t = Yii::app()->db->CreateCommand("select _text from task_param tp where tp.task_id=$task_id and task_diag_param='INVALID'")->queryScalar();
			$t = unserialize($t);
			$model->parent_id = $t[0]['document_id'];
			$rs=Yii::app()->db->CreateCommand("select _varchar as number, user_id as user__id from task_param tp where tp.task_id=$task_id and task_diag_param='DOC_NUMBER'")->queryRow();
			$model->number=$rs["number"];
			$model->uid=$rs["user__id"];
			$model->user__id=$model->uid;
			$model->action_date=Yii::app()->db->CreateCommand("select _datetime from task_param tp where tp.task_id=$task_id and task_diag_param='PUBLIC_DATE'")->queryScalar();
			$model->action_date=$model->action_date ? $model->action_date : null;
			$model->is_readonly=$model->number ? 1 : 0;
			$t=Yii::app()->db->CreateCommand("select _text from task_param tp where tp.task_id=$task_id and task_diag_param='DOCUMENT_NODE_TREE'")->queryScalar();
			$t=unserialize($t);
			$model->tree_id=$t[0]["node_id"];
			$accessListGroupe=Yii::app()->db->CreateCommand("select _text from task_param tp where tp.task_id=$task_id and task_diag_param='ACCESS_GROUPE_LIST'")->queryScalar();
            $ngid=[];
			if ($accessListGroupe)
			{
				$accessListGroupe=unserialize($accessListGroupe);
				$t="";
				foreach ($accessListGroupe as $v)
                {
					$t[]=$v["groupe_id"].", {DID}";
                    $ngid[]=$v["groupe_id"];
                }
				$accessListGroupe="(".implode("), (", $t).")";
			}
			$accessListUser=Yii::app()->db->CreateCommand("select _text from task_param tp where tp.task_id=$task_id and task_diag_param='ACCESS_USER_LIST'")->queryScalar();
            $nuid=[];
			if ($accessListUser)
			{
				$accessListUser=unserialize($accessListUser);
				$t="";
				foreach ($accessListUser as $v)
                {
					$t[]=$v["user_id"].", {DID}";
                    $nuid[]=$v["user_id"];
                }
				$accessListUser="(".implode("), (", $t).")";
			}

			$trn=Yii::app()->db->beginTransaction();

			$tt=true;

			if ($model->parent_id)
			{
				// Установка признака того, что отменённый документ утратил силу (частично или полностью)
				$parentModel = Document::model()->findByPk($model->parent_id);
				if (Yii::app()->db->CreateCommand("select _int from task_param tp where tp.task_id=$task_id and task_diag_param='IS_PARTIALLY_INVALID'")->queryScalar())
					$parentModel->is_partially_invalid = 1;
				else
					$parentModel->is_invalid = 1;
				if (!$parentModel->save())
				{
					$tt=false;
					pe($parentModel);
					$trn->rollback();
				}
			}

			if ($tt && $model->save())
			{
				$model=Document::model()->findByPk($model->document_id);

                $mname=escape($model->name);
                $mnumber=escape($model->number);
                $maction_date=RUDateTime($model->action_date);
                $maction_date=$maction_date ? "'".$maction_date."'" : 'null';
                $mintroduction_date=RUDateTime($model->introduction_date);
                $mintroduction_date=$mintroduction_date ? "'".$mintroduction_date."'" : 'null';
                $mimportant_desc=escape($model->important_desc);
                // Новая библиотека
                $newSQL=<<< SQL
insert into doc (name, number, doc_type, owner, task_id, tree_id, is_readonly, user_id, original_id)
  values
  ('{$mname}', '{$mnumber}', 'DOC_TYPE|DOCUMENT', {$model->user_id}, {$model->task_id}, {$model->tree_id},
    {$model->is_readonly}, {$model->user__id}, {$model->document_id});
insert into doc_document (doc_id, groupe_id, sbe_groupe_id, parent_id, action_date, is_invalid, is_partially_invalid,
                              is_important_on_probation, introduction_date, important_desc, user_id, owner)
  (select d.doc_id, {$model->groupe_id}, {$model->sbe_groupe_id},
SQL
   .($model->parent_id ? "(select doc_id from doc where original_id={$model->parent_id})," : 'null,').
<<< SQL
    {$maction_date}, {$model->is_invalid}, {$model->is_partially_invalid}, {$model->is_important_on_probation},
    {$mintroduction_date}, '{$mimportant_desc}', {$model->user__id}, {$model->user_id} from doc d
      where d.original_id={$model->document_id});

SQL;
                if ($model->is_public)
                    $newSQL.=<<< SQL
insert into doc_department (doc_id, groupe_id, is_view, user__id)
  (select d.doc_id, gc.groupe_id, 1, {$model->user__id} from doc d
    inner join groupe gp on gp.code='HEAD'
	inner join groupe_tree gt on gt.parent_id=gp.groupe_id
	inner join groupe gc on gc.groupe_id=gt.child_id
					and gc.groupe_type in (select _fn_get_org_groupe_type())
	where d.original_id={$model->document_id});

SQL;
                else if ($model->is_sbe_public)
                        if ($model->user_id==4333) // Холод всегда КРП
                            $newSQL.=<<< SQL
insert into doc_department (doc_id, groupe_id, is_view, user__id)
  (select d.doc_id, gc.groupe_id, 1, {$model->user__id} from doc d
    inner join groupe h on h.code='HEAD'
	inner join groupe_tree gt on gt.parent_id=h.groupe_id
	inner join groupe gc on gc.groupe_id=gt.child_id
	                    and gc.groupe_type='KRP'
    where d.original_id={$model->document_id});

SQL;
                        else $newSQL.=<<< SQL
insert into doc_department (doc_id, groupe_id, is_view, user__id)
  (select d.doc_id, gc.groupe_id, 1, {$model->user__id} from doc d
    inner join groupe h on h.code='HEAD'
	inner join groupe_tree gt on gt.parent_id=h.groupe_id
	inner join groupe gc on gc.groupe_id=gt.child_id
	inner join groupe gp on gp.groupe_type=gc.groupe_type
						and gp.groupe_id=(select fn_get_position({$model->user_id}))
    where d.original_id={$model->document_id});

SQL;

                $glTempl=$accessListGroupe ? "insert into access_groupe (groupe_id, document_id) values ".$accessListGroupe : null;
				$ulTempl=$accessListUser ? "insert into access_user (user_id, document_id) values ".$accessListUser : null;

				// Выдаем права на основной документ
				if ($glTempl) Yii::app()->db->CreateCommand(str_replace("{DID}", $model->document_id, $glTempl))->query();
				if ($ulTempl) Yii::app()->db->CreateCommand(str_replace("{DID}", $model->document_id, $ulTempl))->query();

                if ($nuid=implode(',', $nuid))
                    $newSQL.=<<< SQL
insert into doc_user (doc_id, user_id, is_view, user__id)
  (select d.doc_id, u.user_id, 1, {$model->user__id} from doc d
    inner join "user" u on u.user_id in ($nuid)
    where d.original_id={$model->document_id});

SQL;
                if ($ngid=implode(',', $ngid))
                    $newSQL.=<<< SQL
insert into doc_groupe (doc_id, groupe_id, is_view, user__id)
(select d.doc_id, g.groupe_id, 1, {$model->user__id} from doc d
    inner join groupe g on g.groupe_id in ($ngid)
    where d.original_id={$model->document_id});

SQL;

                // Создаем и копируем основной файл

				$f=new File2();
				$f->isCommand=true;
				$f->name=$model->document_type_->name." ".$model->number." от ".RUDate($model->action_date)." - ".$model->name;

				$fs=Task_file::createPath().$file->link; // Что копировать
				$f->link=createPath(File2::createPath())."/".basename($file->link).".pdf"; // Куда копировать
				$fd=File2::createPath().$f->link;

				if (!PDFConvert($fs, $fd))
				{
					z("Не удалось конвертировать - {$fs}\n в PDF - {$fd}");
					$trn->rollback();
				}
				else
				{
					$f->filename=$f->name.".pdf";
					$f->user_id=$model->user__id;
					$f->document_id=$model->document_id;
					$f->user__id=$model->user__id;

					$fCopy[]=$f->link;

                    $mname=escape($f->name);
                    $mfilename=escape($f->filename);
                    $newSQL.=<<< SQL
insert into files (user_id, name, filename, link)
  values
  ({$model->user__id}, '{$mname}', '{$mfilename}', '{$f->link}');
insert into doc_files (doc_id, files_id, user_id, document_type, is_inherit)
  (select d.doc_id, f.files_id, d.user_id, '{$model->document_type}', 1 from doc d
    inner join files f on f.link='{$f->link}'
                      and f.name='{$mname}'
                      and f.filename='{$mfilename}'
    where d.original_id={$model->document_id});

SQL;

					if ($f->save())
					{
                        z("Копируем - $fd >>> ".str_replace('document', 'yii2', $fd));
                        // REMARK - Тут такая тема, что в директории назначения может не быть директории приемника, такая вероятность мала, но она есть
                        //          Т.к. это временное решение, а вероятность маленькая, оставим так, раз в месяц можно заткнуть руками, надеюсь что это добро
                        //          проживет не больше полугода, после чего будет перепсано на новый движек
                        copy($fd, str_replace('document', 'yii2', $fd));

						$pr=true;

						if ($docFileList)
						{
							/* Генерируем и кладем остальные документы со ссылкой на родителя */
							$pid=$model->document_id;
							$number=$model->number;
							$n=0;
							foreach ($docFileList as $v)
							{
								$n++;
								$m=$model;
								$m->isNewRecord=true;
								unset($m->document_id);
								unset($m->number);
								$m->parent_id=$pid;
								$m->document_type=$v["document_type"];
								$m->name=$v["name"];

								if ($m->save())
								{
									$m=Document::model()->findByPk($m->document_id);
									if ($glTempl) Yii::app()->db->CreateCommand(str_replace("{DID}", $m->document_id, $glTempl))->query();
									if ($ulTempl) Yii::app()->db->CreateCommand(str_replace("{DID}", $m->document_id, $ulTempl))->query();

									$f->isNewRecord=true;
									unset($f->file2_id);
									$f->name=$m->document_type_->name." ".$n." ".$number." от ".RUDate($model->action_date)." - ".$m->name;

									$fs=Task_file::createPath().$v["file"]->link; // Что копировать
									$f->link=createPath(File2::createPath())."/".basename($v["file"]->link).".pdf"; // Куда копировать
									$fd=File2::createPath().$f->link;

									if (!PDFConvert($fs, $fd))
									{
										z("Не удалось конвертировать - {$fs}\n в PDF - {$fd}");
										$pr=false;
										$trn->rollback();
									}
									else
									{
										$f->filename=$f->name.".pdf";
										$f->document_id=$m->document_id;
										$fCopy[]=$v["file"]->link;

										if (!$f->save())
										{
											pe($f);
											$pr=false;
											$trn->rollback();
										}

                                        z("Копируем - $fd >>> ".str_replace('document', 'yii2', $fd));
                                        // REMARK - Тут такая тема, что в директории назначения может не быть директории приемника, такая вероятность мала, но она есть
                                        //          Т.к. это временное решение, а вероятность маленькая, оставим так, раз в месяц можно заткнуть руками, надеюсь что это добро
                                        //          проживет не больше полугода, после чего будет перепсано на новый движек
                                        copy($fd, str_replace('document', 'yii2', $fd));

                                        $mname=escape($f->name);
                                        $mfilename=escape($f->filename);
                                        $newSQL.=<<< SQL
insert into files (user_id, name, filename, link)
  values
  ({$model->user__id}, '{$mname}', '{$mfilename}', '{$f->link}');
insert into doc_files (doc_id, files_id, user_id, document_type, is_inherit)
  (select d.doc_id, f.files_id, d.user_id, '{$m->document_type}', 1 from doc d
    inner join files f on f.link='{$f->link}'
                      and f.name='{$mname}'
                      and f.filename='{$mfilename}'
    where d.original_id={$model->document_id});

SQL;
                                    }
								}
								else
								{
									pe($m);
									$pr=false;
									$trn->rollback();
								}

							}
						}

						/* Физически копируем файлы */

						if ($pr)
						{
							if (Yii::app()->db->CreateCommand("select _varchar from task_param tp where tp.task_id=$task_id and task_diag_param='IS_ORDER_DEMAND'")->queryScalar())
							{
								$model->is_readonly=1; // REMARK - Устанавливаем признак только для чтения для документов, которые издаются приказом, остальные можно менять потом
								CDbAuthManager::$privelegy["DOC_ADMIN"]="WEBAPP";
								$model->save();

                                $newSQL.=<<< SQL
update doc set is_readonly=1 where original_id={$model->document_id};

SQL;
							}

							$trn->commit();

							if (Yii::app()->db->CreateCommand("select _int from task_param tp where tp.task_id=$task_id and task_diag_param='IS_MAIL_NOT_SEND'")->queryScalar()===0)
                            {
								Document::sendmail(isset($pid) ? $pid : $model->document_id);
                                $newSQL.=<<< SQL
insert into sendmail (email, subject, body, return_name, user_id)
    (select u.email, substr('НЕЗАБУДКА - ' || coalesce(' №' || d.number, '') || coalesce(' от ' ||  to_char(dd.action_date, 'DD.MM.YYYY'), '') || ' - ' || f.name || ' [' || dt.name || '] ', 1, 255),
            '<html><body style="font-size:12px; color:black;"><a href="https://suz.rp.ru/myosotis/doc/efdocument/id/' || df.doc_files_id || '">'
                    || coalesce('№' || d.number, '') || coalesce(' от ' ||  to_char(dd.action_date, 'DD.MM.YYYY'), '') || ' - ' || f.name
                || '</a> | <span style="color:grey;">Прикрепил - </span>' || o.f_ms || '</span></body></html>', 'НЕЗАБУДКА', {$model->user__id}
        from doc_files df
        inner join files f on f.files_id=df.files_id
        inner join doc d on d.doc_id=df.doc_id
                      and d.original_id={$model->document_id}
        inner join "user" u on u.user_id in (select user_id from _fn_get_effective_access_doc((select doc_id from doc where original_id={$model->document_id})))
                            and u.is_disabled=0
                            and u.user_id not in (4333, 5325, 4235, 4224)
                            and u.email is not null
        inner join "user" o on o.user_id=df.user_id
        inner join dictonary dt on dt.pkey=df.document_type
        inner join doc_document dd on dd.doc_id=d.doc_id);
SQL;
                            }

                            z('Выполненный запрос:'.$newSQL);
                            Yii::app()->db->createCommand($newSQL)->query();
						}
					}
					else
					{
						pe($f);
						$trn->rollback();
					}
				}
			}
			else
			{
				if ($tt)
				{
					pe($model);
					$trn->rollback();
				}
			}
		}
	}
	public static function getOld()
	{
		$old = <<<'SQL'
CREATE OR REPLACE FUNCTION fn_td_event_da_create_document(sid bigint)
  RETURNS SETOF character varying AS
$BODY$

BEGIN

insert into crond_task (script) values (
'$task_id=' || (select task_id from subtask where subtask_id=sid) || ';
require_once "/srv/www/htdocs/src/protected/models/Dictonary_old.php";
Yii::import("doc.models.Document");
Yii::import("doc.models.File2");
CActiveRecord::$db=Yii::app()->workflow_db;
$file=Task_file::model()->find("link=''".Yii::app()->workflow_db->CreateCommand("select _text from task_param tp where tp.task_id=$task_id and task_diag_param=''CURRENT_VERSION''")->queryScalar()."''");

if ($file)
{
    /* Грузим в память все файлы, чтобы потом не переставлять источники данных*/
    $docFileList=Yii::app()->workflow_db->CreateCommand("select _text from task_param tp where tp.task_id=$task_id and task_diag_param=''INTEGRATED_FILE''")->queryScalar();
    if ($docFileList)
    {
        $docFileList=unserialize($docFileList);
        foreach ($docFileList as $k => $v)
            $docFileList[$k]["file"]=Task_file::model()->findByPk($v["task_diag_file_id"]);
    }

    CActiveRecord::$db=Yii::app()->doc_db;
    $model=new Document();
    $model->task_id=$task_id;
    /* Готовим общие переменные */
    $model->name=Yii::app()->workflow_db->CreateCommand("select _varchar from task_param tp where tp.task_id=$task_id and task_diag_param=''NAME''")->queryScalar();
    $model->is_important_on_probation=Yii::app()->workflow_db->CreateCommand("select _int from task_param tp where tp.task_id=$task_id and task_diag_param=''IS_IMPORTANT_ON_PROBATION''")->queryScalar();
    $model->is_important_on_probation=$model->is_important_on_probation ? 1 : 0;
    $rs=Yii::app()->workflow_db->CreateCommand("select _int as user_id, fn_get_department(cast(_int as integer)) as groupe_id from task_param tp where tp.task_id=$task_id and task_diag_param=''PUBLISHER''")->queryRow();
    $model->user_id=$rs["user_id"];
    $model->owner=$model->user_id;
    $model->groupe_id=$rs["groupe_id"];
    $model->keyword=Yii::app()->workflow_db->CreateCommand("select _varchar from task_param tp where tp.task_id=$task_id and task_diag_param=''KEYWORDS''")->queryScalar();
    $model->sbe_groupe_id=Yii::app()->workflow_db->CreateCommand("select _int from task_param tp where tp.task_id=$task_id and task_diag_param=''ACTIVITY''")->queryScalar();
    $model->is_public=Yii::app()->workflow_db->CreateCommand("select _int from task_param tp where tp.task_id=$task_id and task_diag_param=''IS_ACCESS_KRP''")->queryScalar();
    $model->is_public=$model->is_public ? 1 : 0;
    $model->is_sbe_public=Yii::app()->workflow_db->CreateCommand("select _int from task_param tp where tp.task_id=$task_id and task_diag_param=''IS_ACCESS_SBE''")->queryScalar();
    $model->is_sbe_public=$model->is_sbe_public ? 1 :0;
    $model->document_type=Yii::app()->workflow_db->CreateCommand("select _varchar from task_param tp where tp.task_id=$task_id and task_diag_param=''DOCUMENT_TYPE''")->queryScalar();
    $model->activity_type=Yii::app()->workflow_db->CreateCommand("select _varchar from task_param tp where tp.task_id=$task_id and task_diag_param=''ACTIVITY_TYPE''")->queryScalar();
    $t = Yii::app()->workflow_db->CreateCommand("select _text from task_param tp where tp.task_id=$task_id and task_diag_param=''INVALID''")->queryScalar();
    $t = unserialize($t);
    $model->parent_id = $t[0][''document_id''];
    $rs=Yii::app()->workflow_db->CreateCommand("select _varchar as number, user_id as user__id from task_param tp where tp.task_id=$task_id and task_diag_param=''DOC_NUMBER''")->queryRow();
    $model->number=$rs["number"];
    $model->uid=$rs["user__id"];
    $model->user__id=$model->uid;
    $model->action_date=Yii::app()->workflow_db->CreateCommand("select _datetime from task_param tp where tp.task_id=$task_id and task_diag_param=''PUBLIC_DATE''")->queryScalar();
    $model->action_date=$model->action_date ? $model->action_date : null;
    $model->is_readonly=$model->number ? 1 : 0;
    $t=Yii::app()->workflow_db->CreateCommand("select _text from task_param tp where tp.task_id=$task_id and task_diag_param=''DOCUMENT_NODE_TREE''")->queryScalar();
    $t=unserialize($t);
    $model->tree_id=$t[0]["node_id"];
    $accessListGroupe=Yii::app()->workflow_db->CreateCommand("select _text from task_param tp where tp.task_id=$task_id and task_diag_param=''ACCESS_GROUPE_LIST''")->queryScalar();
    if ($accessListGroupe)
    {
        $accessListGroupe=unserialize($accessListGroupe);
        $t="";
        foreach ($accessListGroupe as $v)
            $t[]=$v["groupe_id"].", {DID}";
        $accessListGroupe="(".implode("), (", $t).")";
    }
    $accessListUser=Yii::app()->workflow_db->CreateCommand("select _text from task_param tp where tp.task_id=$task_id and task_diag_param=''ACCESS_USER_LIST''")->queryScalar();
    if ($accessListUser)
    {
        $accessListUser=unserialize($accessListUser);
        $t="";
        foreach ($accessListUser as $v)
            $t[]=$v["user_id"].", {DID}";
        $accessListUser="(".implode("), (", $t).")";
    }

    $trn=Yii::app()->doc_db->beginTransaction();

	$tt=true;

	if ($model->parent_id)
	{
	    // Установка признака того, что отменённый документ утратил силу (частично или полностью)
	    $parentModel = Document::model()->findByPk($model->parent_id);
	    if (Yii::app()->workflow_db->CreateCommand("select _int from task_param tp where tp.task_id=$task_id and task_diag_param=''IS_PARTIALLY_INVALID''")->queryScalar())
		    $parentModel->is_partially_invalid = 1;
	    else
			$parentModel->is_invalid = 1;
	    if (!$parentModel->save())
	    {
		$tt=false;
		    pe($parentModel);
		    $trn->rollback();
	    }
	}

	if ($tt && $model->save())
	    {
		$model=Document::model()->findByPk($model->document_id);

		$glTempl=$accessListGroupe ? "insert into access_groupe (groupe_id, document_id) values ".$accessListGroupe : null;
		$ulTempl=$accessListUser ? "insert into access_user (user_id, document_id) values ".$accessListUser : null;

		// Выдаем права на основной документ
		if ($glTempl) Yii::app()->doc_db->CreateCommand(str_replace("{DID}", $model->document_id, $glTempl))->query();
		if ($ulTempl) Yii::app()->doc_db->CreateCommand(str_replace("{DID}", $model->document_id, $ulTempl))->query();

		// Создаем и копируем основной файл

		$f=new File2();
		$f->isCommand=true;
		$f->name=$model->document_type_->name." ".$model->number." от ".RUDate($model->action_date)." - ".$model->name;

		$fs=Task_file::createPath().$file->link; // Что копировать
		$f->link=createPath(File2::createPath())."/".basename($file->link).".pdf"; // Куда копировать
		$fd=File2::createPath().$f->link;

		if (!PDFConvert($fs, $fd))
		{
		    z("Не удалось конвертировать - {$fs}\n в PDF - {$fd}");
		    $trn->rollback();
		}
		else
		{
		    $f->filename=$f->name.".pdf";
		    $f->user_id=$model->user__id;
		    $f->document_id=$model->document_id;
		    $f->user__id=$model->user__id;

		    $fCopy[]=$f->link;

		    if ($f->save())
		    {
			$pr=true;

			if ($docFileList)
			{
			    /* Генерируем и кладем остальные документы со ссылкой на родителя */
			    $pid=$model->document_id;
			    $number=$model->number;
			    $n=0;
			    foreach ($docFileList as $v)
			    {
				$n++;
				$m=$model;
				$m->isNewRecord=true;
				unset($m->document_id);
				unset($m->number);
				$m->parent_id=$pid;
				$m->document_type=$v["document_type"];
				$m->name=$v["name"];

				if ($m->save())
				{
				    $m=Document::model()->findByPk($m->document_id);
				    if ($glTempl) Yii::app()->doc_db->CreateCommand(str_replace("{DID}", $m->document_id, $glTempl))->query();
				    if ($ulTempl) Yii::app()->doc_db->CreateCommand(str_replace("{DID}", $m->document_id, $ulTempl))->query();

				    $f->isNewRecord=true;
				    unset($f->file2_id);
				    $f->name=$m->document_type_->name." ".$n." ".$number." от ".RUDate($model->action_date)." - ".$m->name;

				    $fs=Task_file::createPath().$v["file"]->link; // Что копировать
				    $f->link=createPath(File2::createPath())."/".basename($v["file"]->link).".pdf"; // Куда копировать
				    $fd=File2::createPath().$f->link;

				    if (!PDFConvert($fs, $fd))
				    {
					z("Не удалось конвертировать - {$fs}\n в PDF - {$fd}");
					$pr=false;
					$trn->rollback();
				    }
				    else
				    {
					$f->filename=$f->name.".pdf";
					$f->document_id=$m->document_id;
					$fCopy[]=$v["file"]->link;

					if (!$f->save())
					{
					    pe($f);
					    $pr=false;
					    $trn->rollback();
					}
				    }
				}
				else
				{
				    pe($m);
				    $pr=false;
				    $trn->rollback();
				}

			    }
			}

			/* Физически копируем файлы */

			    if ($pr)
			    {
				if (Yii::app()->workflow_db->CreateCommand("select _varchar from task_param tp where tp.task_id=$task_id and task_diag_param=''IS_ORDER_DEMAND''")->queryScalar())
				{
				    $model->is_readonly=1; // REMARK - Устанавливаем признак только для чтения для документов, которые издаются приказом, остальные можно менять потом
				    CDbAuthManager::$privelegy["DOC_ADMIN"]="WEBAPP";
				    $model->save();
				}

				$trn->commit();

				if (Yii::app()->workflow_db->CreateCommand("select _int from task_param tp where tp.task_id=$task_id and task_diag_param=''IS_MAIL_NOT_SEND''")->queryScalar()===0)
				    Document::sendmail(isset($pid) ? $pid : $model->document_id);
			    }
		    }
		    else
		    {
			pe($f);
			$trn->rollback();
		    }
		}
	    }
	    else
	    {
		if ($tt)
		{
			pe($model);
			$trn->rollback();
		}
	    }
}
;');

    return query (select cast(null as varchar));

END;$BODY$
  LANGUAGE plpgsql VOLATILE
  COST 100
  ROWS 1000;
ALTER FUNCTION fn_td_event_da_create_document(bigint)
  OWNER TO postgres;
GRANT EXECUTE ON FUNCTION fn_td_event_da_create_document(bigint) TO postgres;
GRANT EXECUTE ON FUNCTION fn_td_event_da_create_document(bigint) TO public;

SQL;
		return $old;
	}
}