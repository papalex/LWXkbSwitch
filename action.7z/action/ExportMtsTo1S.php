<?php
class ExportMtsTo1S
{
	/**
	 * @param $args
	 */
	public function run($args)
	{
		$period_files_id = $args;
		$connectionStr = str_replace(';',' ',substr(Yii::app()->db->connectionString,strlen('pgsql:'))).' user='.Yii::app()->db->username.' password='.Yii::app()->db->password;
		$connectionStr = 'host=10.101.3.188 port=5432 dbname=common user='.Yii::app()->db->username.' password='.Yii::app()->db->password;
		z("Начата выгрузка МТС в 1С " );
		//REMARK в следующем запросе оставлены параметры и бинды т.к. полученный результат предыдущего, им соответствует
		Yii::app()->c1->createCommand(<<<SQL
		select 'suz' = any(dblink_get_connections()) or 'OK' = dblink_connect('suz', '{$connectionStr}');
insert into  mts_document(mts_document_id,number,doc_date,period,amount,inn, filename)
	select * from dblink('suz', 'select mpf.mts_period_files_id as mts_document_id, mpf.invoice_number as number, mpf.invoice_date as doc_date, mp.period,
	                                  mpf.amount, company.inn, f.filename from mts_period_files mpf
                                    inner join mts_period mp on mpf.mts_period_id = mp.mts_period_id
                                    inner join files f on f.files_id=mpf.files_id
                                    inner join krp_company company on mpf.krp_company = company.krp_company
                                    where mts_period_files_id = {$period_files_id}')
            as t(mts_document_id bigint, number varchar,doc_date date,period date,amount decimal(12,4), inn varchar, filename varchar);
insert into mts_employee(mts_document_id, uid24,amount, limit_amount, discount_amount, contract, charge_amount, payment_amount,phone)
	select * from dblink('suz', 'select mts_document_id, employee_id,amount, limit_amount, discount_amount, contract, charge_amount, payment_amount, phone
	                                from (select mpf.mts_period_files_id as mts_document_id, u.employee_id,
                                                        case when sum(coalesce(mtp.amount,0) + mnmp.amount + mn.limit_amount) >0
                                                                then sum(coalesce(mtp.amount,0) + mnmp.amount + mn.limit_amount)
                                                             else 0 end as limit_amount,
                                                  sum(ma.discount) as discount_amount, sum(ma.cost) as charge_amount,
                                                  case when (sum(ma.cost) - (sum(coalesce(mtp.amount,0)) + sum(mnmp.amount) +sum(mn.limit_amount)))>0
                                                          then sum(ma.cost) - (sum(coalesce(mtp.amount,0)) + sum(mnmp.amount) +sum(mn.limit_amount))
                                                      else 0 end as amount,
                                                  sum(ma.cost + ma.discount)  as payment_amount, mc.number as contract, mn.number as phone
                                              from mts_period_files mpf
                                              join mts_contract mc on mpf.krp_company = mc.krp_company
                                              join mts_person_account mpa on mc.mts_contract_id = mpa.mts_contract_id
                                              join mts_number mn on mpa.mts_person_account_id = mn.mts_person_account_id
                                              join mts_number_mts_period mnmp on mn.mts_number_id = mnmp.mts_number_id and mnmp.mts_period_id = mpf.mts_period_id and mnmp.user_id notnull
                                              left join mts_tariff_plan mtp on mnmp.mts_tariff_plan = mtp.mts_tariff_plan
                                              join "user" u on u.user_id=mnmp.user_id
                                              join (select mag.mts_number_mts_period_id, sum(mag.cost) as cost, sum(mag.discount) as discount from mts_aggregate mag group by mag.mts_number_mts_period_id) as ma on mnmp.mts_number_mts_period_id = ma.mts_number_mts_period_id
									          where mpf.mts_period_files_id = {$period_files_id}
									          group by mpf.mts_period_files_id,mc.number,u.user_id, u.uid24,mn.number) as foo')
	          as x(mts_document_id bigint,uid24 varchar,amount decimal(12,2),limit_amount decimal(12,4),discount_amount decimal(12,4),contract varchar, charge_amount decimal(12,4),payment_amount decimal(12,4), phone varchar);
SQL
		)->execute();
		Yii::app()->db->createCommand(<<<SQL
		update mts_period_files set is_exported=1 where mts_period_files_id ={$period_files_id};
SQL
			)->execute();
			z('Выгрузка завершена');
	}
}