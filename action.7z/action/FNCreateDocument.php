<?php
/**
 * Created by PhpStorm.
 * User: kruchinin
 * Date: 14.03.18
 * Time: 14:26
 */

class FNCreateDocument
{
	/**
	 * @param $args
	 */
	public function run($args)
	{
		$task_id = $args;

		require_once "/srv/www/htdocs/src/protected/models/Dictonary_old.php";
		//TODO lex: пока сделаем require, позже перенесем возможно в baseConstants
		//require_once "/srv/www/workflow/models/Task_diag_node.php";
		require_once "/srv/www/workflow/models/Task_diag_param.php";
		require_once "/srv/www/document/models/File2.php";
		require_once "/srv/www/document/models/Register_contract.php";
		/*
		 * в index.php объявлен как 'document' а в yiic.php 'doc'
		 * Yii::import('document.models.File2',true);
		 * Yii::import('document.models.Register_contract',true);
		*/

		// Процесс
		$task = Task::model()->findByPk($task_id);
		// Подписант
		$subscriber_id = Yii::app()->db->createCommand(<<<SQL
select s.owner from subtask s
		inner join task_diag_node tdn on tdn.task_diag_node_id = s.task_diag_node_id
	where task_id = :taskid and task_diag_node = :diagnode
SQL
			)->queryScalar([':diagnode'=>TaskDiagNodes::APPROVE_CONTRACT_SUBSCRIBE , ':taskid'=>$task_id]);

		$model = new Document();
		$model->task_id = $task_id;
		// Готовим общие переменные
		$model->name = Yii::app()->db->CreateCommand("select _varchar from task_param where task_id=? and task_diag_param = ?")->queryScalar([$task_id, Task_diag_param::CONTRACT_NUMBER_LEGAL]);
		$model->number = Yii::app()->db->CreateCommand("select substr(_varchar, 1, 32) from task_param where task_id=? and task_diag_param = ?")->queryScalar([$task_id, Task_diag_param::CONTRACT_NUMBER_LEGAL]);
		$model->user_id = $subscriber_id;
		$model->owner = $task->initiator;
		$model->groupe_id = Yii::app()->db->createCommand("select fn_get_department($task->initiator)")->queryScalar();
		$model->sbe_groupe_id = Yii::app()->db->createCommand("select fn_get_direction($task->initiator)")->queryScalar();
		$model->sbe_groupe_id=$model->sbe_groupe_id ? $model->sbe_groupe_id : $model->groupe_id;
		$model->document_type = DocTypes::CONTRACT;//REMARK lex ----> заменил
		$model->activity_type = Yii::app()->db->CreateCommand("select _int from task_param where task_id=$task_id and task_diag_param = :tdparm")
                                                ->queryScalar([':tdparm'=>Task_diag_param::ECONOMIC_CONTRACT]) ? EActivityTypes::ECONOMIC : EActivityTypes::INTER;
		$model->user__id = User::USERDEFAULT_ADM;
		$model->action_date = RU_Date(time());

		$trn = Yii::app()->db->beginTransaction();

		if ($model->save())
		{
            $mname=escape($model->name);
            $mnumber=escape($model->number);
            $maction_date=RUDateTime($model->action_date);
            // Новая библиотека
            $newSQL=<<< SQL
insert into doc (name, number, doc_type, owner, task_id, user_id, original_id)
  values
  ('{$mname}', '{$mnumber}', 'DOC_TYPE|REGISTER', {$model->user_id}, {$model->task_id}, {$model->user__id}, {$model->document_id});
insert into doc_document (doc_id, groupe_id, sbe_groupe_id, action_date, user_id, owner)
  (select d.doc_id, {$model->groupe_id}, {$model->sbe_groupe_id}, '{$maction_date}', {$model->user__id}, {$model->user_id} from doc d
      where d.original_id={$model->document_id});

SQL;

			$participants = Yii::app()->db->CreateCommand("select distinct owner from subtask where task_id = $task_id and owner is not null")->queryColumn();
			$rc_view_groupe_id = (Yii::app()->db->CreateCommand(<<< SQL
select g.groupe_id
	from task_param tp
		inner join groupe g on g.code = 'RC_VIEW_' || tp._varchar
	where task_id={$task_id} and task_diag_param = :taskdiparm
SQL
					)->queryScalar([':taskdiparm'=>Task_diag_param::KRP_COMPANY_FOR_CONTRACT]));

			if ($participants)
			{
				$values = implode(",", array_map(function ($v) use ($model) {return "($v, $model->document_id)";}, $participants));
				Yii::app()->db->CreateCommand("insert into access_user (user_id, document_id) values $values;")->query();

                $newSQL=<<< SQL
insert into doc_user (doc_id, user_id, user__id, is_view)
  (select d.doc_id, ua.user_id, {$model->user__id}, 1 from doc d
      inner join access_user au on au.document_id=d.original_id
      where d.original_id={$model->document_id});

SQL;
			}

			// Выдаем права на основной документ
			if (is_int($rc_view_groupe_id))
			{
				Yii::app()->db->CreateCommand("insert into access_groupe (groupe_id, document_id) values ($rc_view_groupe_id, $model->document_id)")->query();

                $newSQL=<<< SQL
insert into doc_groupe (doc_id, groupe_id, user__id, is_view)
  (select d.doc_id, ag.groupe_id, {$model->user__id}, 1 from doc d
      inner join access_groupe ag on ag.document_id=d.original_id
      where d.original_id={$model->document_id});

SQL;
		    }

			$task_files = Yii::app()->db->createCommand(<<< SQL
select _text, task_diag_param from task_param
	where task_id=?
		and task_diag_param=?
SQL
					)->queryAll(true,[$task_id,Task_diag_param::SCANNED_FILE]);

			foreach ($task_files as $v)
			{
				foreach (unserialize($v["_text"]) as $vv)
				{
					$file = Task_file::model()->findByPk($vv["task_diag_file_id"]);

					$f = new File2;
					// fs и fd - полные пути
					$fs = Task_file::createPath().$file->link;                           // Что и откуда
					$f->isCommand = true;
					$f->link = createPath(File2::createPath())."/".basename($file->link); // Куда
					$fd = File2::createPath().$f->link;

					$f->name = $vv['name'];
					$f->document_type = $v["task_diag_param"] === Task_diag_param::PROJECT ? DocTypes::CONTRACT : $vv["document_type"];

					if (copy($fs, $fd))
					{
						chown($fd, "wwwrun");
						$f->filename=$f->name;
						$f->filename=$file->filename;
						$f->user_id=$model->user__id;
						$f->document_id=$model->document_id;
						$f->user__id=$model->user__id;
						$f->save();

                        $mname=escape($f->name);
                        $mfilename=escape($f->filename);
                        $newSQL.=<<< SQL
insert into files (user_id, name, filename, link)
  values
  ({$model->user__id}, '{$mname}', '{$mfilename}', '{$f->link}');

insert into doc_files (doc_id, files_id, user_id, document_type, is_inherit)
  (select d.doc_id, f.files_id, d.user_id, '{$model->document_type}', 1 from doc d
    inner join files f on f.link='{$f->link}'
                      and f.name='{$mname}'
                      and f.filename='{$mfilename}'
    where d.original_id={$model->document_id});

SQL;
                        z("Копируем - $fd >>> ".str_replace('document', 'yii2', $fd));
                        // REMARK - Тут такая тема, что в директории назначения может не быть директории приемника, такая вероятность мала, но она есть
                        //          Т.к. это временное решение, а вероятность маленькая, оставим так, раз в месяц можно заткнуть руками, надеюсь что это добро
                        //          проживет не больше полугода, после чего будет перепсано на новый движек
                        copy($fd, str_replace('document', 'yii2', $fd));
					}
					else
					{
						$trn->rollBack();
						x("Ошибка при копировании файла.");
					}
				}
			}

			if (empty($task_files)
				&& Yii::app()->db->CreateCommand("select _int from task_param where task_id=:taskid and task_diag_param = :tdparm")->queryScalar([":tdparm"=>Task_diag_param::ACCEPTED_AS_ORIGINAL,":taskid"=>$task_id]))
			{//PRELIMINARY_SCAN
				$preliminary_scan = Yii::app()->db->CreateCommand("select _varchar as filename, _text as link from task_param where task_id=:taskid and task_diag_param = :tdparm and _text is not null")->queryRow(true,[":tdparm"=>Task_diag_param::PRELIMINARY_SCAN,":taskid"=>$task_id]);
				if (is_array($preliminary_scan))
				{
					$f = new File2;
					$fs = Task_file::createPath().$preliminary_scan["link"];
					$f->isCommand = true;
					$f->link = createPath(File2::createPath())."/".basename($preliminary_scan["link"]);
					$fd = File2::createPath().$f->link;

					$f->name = $preliminary_scan["filename"];
					$f->document_type = DocTypes::CONTRACT;

					if (copy($fs, $fd))
					{
						chown($fd, "wwwrun");
						$f->filename=$preliminary_scan["filename"];
						$f->user_id=$model->user__id;
						$f->document_id=$model->document_id;
						$f->user__id=$model->user__id;
						$f->save();

                        $mname=escape($f->name);
                        $mfilename=escape($f->filename);
                        $newSQL.=<<< SQL
insert into files (user_id, name, filename, link)
  values
  ({$model->user__id}, '{$mname}', '{$mfilename}', '{$f->link}');

insert into doc_files (doc_id, files_id, user_id, document_type, is_inherit)
  (select d.doc_id, f.files_id, d.user_id, '{$model->document_type}', 1 from doc d
    inner join files f on f.link='{$f->link}'
                      and f.name='{$mname}'
                      and f.filename='{$mfilename}'
    where d.original_id={$model->document_id});

SQL;
                        z("Копируем - $fd >>> ".str_replace('document', 'yii2', $fd));
                        // REMARK - Тут такая тема, что в директории назначения может не быть директории приемника, такая вероятность мала, но она есть
                        //          Т.к. это временное решение, а вероятность маленькая, оставим так, раз в месяц можно заткнуть руками, надеюсь что это добро
                        //          проживет не больше полугода, после чего будет перепсано на новый движек
                        copy($fd, str_replace('document', 'yii2', $fd));

					}
					else
					{
						$trn->rollBack();
						x("Ошибка при копировании файла.");
					}
				}
			}

			$trn->commit();
		}
		else
		{
			$trn->rollBack();
			pe($model);
            pa($model);
		}

		$mapParamsToFields = array(
			"number" => array("task_diag_param" => Task_diag_param::CONTRACT_NUMBER_LEGAL, "type" => "_varchar"),
			"start_date" => array("task_diag_param" => Task_diag_param::CONTRACT_START_DATE, "type" => "_datetime"),
			"end_date" => array("task_diag_param" => Task_diag_param::CONTRACT_END_DATE, "type" => "_datetime"),
			"payment_form_type" => array("task_diag_param" => Task_diag_param::PAYMENT_FORM_TYPE, "type" => "_varchar"),
			"currency" => array("task_diag_param" => Task_diag_param::CURR, "type" => "_varchar"),
			"contract_type" => array("task_diag_param" => Task_diag_param::CONTRACT_TYPE, "type" => "_varchar"),
			"description" => array("task_diag_param" => Task_diag_param::DESCRIPTION, "type" => "_text"),
			"krp_company" => array("task_diag_param" => Task_diag_param::KRP_COMPANY_FOR_CONTRACT, "type" => "_varchar"),
			"other_payment_form" => array("task_diag_param" => Task_diag_param::PAYMENT_FORM_TYPE_OTHER, "type" => "_text"),
			"amount" => array("task_diag_param" => Task_diag_param::CONTRACT_AMOUNT, "type" => '_currency'),
			"postponing" => array("task_diag_param" => Task_diag_param::PAYMENT_POSTPONEMENT, "type" => "_text"),
			"currency_rate_type" => array("task_diag_param" => Task_diag_param::CURRENCY_RATE_TYPE, "type" => "_varchar"),
			"subject" => array("task_diag_param" => Task_diag_param::CONTRACT_SUBJECT, "type" => "_text"),
			"reg_number" => array("task_diag_param" => Task_diag_param::REGISTRY_NUMBER, "type" => "_varchar"),
			"reg_date" => array("task_diag_param" => Task_diag_param::REGISTRY_DATE, "type" => "_datetime"),
			"is_prolongation" => array("task_diag_param" => Task_diag_param::IS_PROLONGABLE, "type" => "_int"),
		);

		$rc = new Register_contract();

		foreach ($mapParamsToFields as $k => $v)
			$rc->$k = Yii::app()->db->CreateCommand("select {$v['type']} from task_param where task_id=$task_id and task_diag_param = '{$v['task_diag_param']}'")->queryScalar();

		$original_type = Yii::app()->db->CreateCommand("select _varchar from task_param where task_id=? and task_diag_param = ?")->queryScalar([$task_id,Task_diag_param::ORIGINAL_TYPE]);
		$rc->original_type = $original_type ? $original_type : Register_contract::ORIGINAL_TYPE_DEFAULT;

		$rc->name = Yii::app()->db->CreateCommand("select _varchar from task_param where task_id=? and task_diag_param = ?")->queryScalar([$task_id,Task_diag_param::PROJECT]);
		$rc->owner = User::USERDEFAULT_ADM;
		$rc->document_id = $model->document_id;
		$c = unserialize(Yii::app()->db->CreateCommand("select _text from task_param where task_id=? and task_diag_param = ?")->queryScalar([$task_id,Task_diag_param::CONTRACTOR_ID]));
		$c = $c[0];
		$rc->contractor_id = (int)$c["contractor"];
		$rc->storage = Register_contract::STORAGE_BUH;
		if (!$rc->save())
			p('Ошибка при сохранении.', $rc->errorToString());

		// Отгружаем в движение
		$tp=Task_param::model()->find("task_id={$task_id} and task_diag_param=:tdparm",[':tdparm'=>Task_diag_param::RUN_CONTRACT_NUMBER]);
		if ($tp)
		{
			$t=unserialize($tp->_text);
			if (is_array($t) && array_key_exists("uid24", $t) && $t["uid24"]) // Если номера сделки нет, то собственно некуда отгружать и крепить соответственно
				Yii::app()->run_db->CreateCommand("insert into exchange.docprnacc (docname, docurl, login, deal_uid24) values "
					."('{$model->name}', 'https://suz.rp.ru/document/view/id/{$model->document_id}', '{$task->initiator_->login}', '{$t['uid24']}')")
					->query();

		}

        z('Исполняем - '.$newSQL);
        Yii::app()->db->createCommand($newSQL)->query();
	}
	public static function getOld()
	{
		return /*old function
		 *
		 *
		 ****************/
			<<<'SQL'
		DROP FUNCTION fn_td_event_cld_create_document(bigint);

CREATE OR REPLACE FUNCTION fn_td_event_cld_create_document(sid bigint)
  RETURNS SETOF character varying AS
$BODY$
declare
    is_regscan smallint;
    tid bigint;
BEGIN

    select task_id into tid from subtask where subtask_id=sid;
    select _int into is_regscan from task_param where task_id=tid and task_diag_param='IS_REGISTER_AND_SCAN_COMPLETED';

    if (is_regscan = 1) then

    update task set is_success=1 where task_id=tid;

    insert into crond_task (script) values ('

    $task_id = ' || tid || ';

    require_once "/srv/www/htdocs/src/protected/models/Dictonary_old.php";

    CActiveRecord::$db = Yii::app()->workflow_db;

    // Процесс
    $task = Task::model()->findByPk($task_id);
    // Подписант
    $subscriber_id = Yii::app()->db->createCommand("select s.owner"
                                                                ." from subtask s"
                                                                    ." inner join task_diag_node tdn on tdn.task_diag_node_id = s.task_diag_node_id"
                                                                ." where task_id = {$task_id} and task_diag_node = ''APPROVE_CONTRACT_SUBSCRIBE''")->queryScalar();

    CActiveRecord::$db = Yii::app()->doc_db;
    $model = new Document();
    $model->task_id = $task_id;
    //// Готовим общие переменные ///
			$model->name = Yii::app()->db->CreateCommand("select _varchar from task_param where task_id=$task_id and task_diag_param = ''CONTRACT_NUMBER_LEGAL''")->queryScalar();
			$model->number = Yii::app()->db->CreateCommand("select _varchar from task_param where task_id=$task_id and task_diag_param = ''CONTRACT_NUMBER_LEGAL''")->queryScalar();
			$model->user_id = $subscriber_id;
			$model->owner = $task->initiator;
			$model->groupe_id = Yii::app()->db->createCommand("select fn_get_department($task->initiator)")->queryScalar();
			$model->sbe_groupe_id = Yii::app()->doc_db->createCommand("select fn_get_direction($task->initiator)")->queryScalar();
			$model->sbe_groupe_id=$model->sbe_groupe_id ? $model->sbe_groupe_id : $model->groupe_id;
			$model->document_type = ''CONTRACT'';
    $model->activity_type = Yii::app()->db->CreateCommand("select _int from task_param where task_id=$task_id and task_diag_param = ''ECONOMIC_CONTRACT''")->queryScalar() ? "ECONOMIC" : "INTER";
    $model->user__id = 4000;
    $model->action_date = RU_Date(time());

    $trn = Yii::app()->doc_db->beginTransaction();

    if ($model->save())
	{
		$participants = Yii::app()->db->CreateCommand("select distinct owner from subtask where task_id = $task_id and owner is not null")->queryColumn();
		$rc_view_groupe_id = (Yii::app()->db->CreateCommand("select g.groupe_id"
			." from task_param tp"
			." inner join groupe g on g.code = ''RC_VIEW_'' || tp._varchar"
			." where task_id=$task_id"
			." and task_diag_param = ''KRP_COMPANY_FOR_CONTRACT''")->queryScalar());

		if ($participants)
		{
			$values = implode(",", array_map(function ($v) use ($model) {return "($v, $model->document_id)";}, $participants));
			Yii::app()->doc_db->CreateCommand("insert into access_user (user_id, document_id) values $values;")->query();
		}

		// Выдаем права на основной документ
		if (is_int($rc_view_groupe_id))
			Yii::app()->doc_db->CreateCommand("insert into access_groupe (groupe_id, document_id) values ($rc_view_groupe_id, $model->document_id)")->query();

		$task_files = Yii::app()->db->createCommand("select _text, task_diag_param"
			." from task_param"
			." where task_id={$task_id}"
			." and task_diag_param=''SCANNED_FILE''")->queryAll();

		foreach ($task_files as $v)
		{
			foreach (unserialize($v["_text"]) as $vv)
			{

				CActiveRecord::$db = Yii::app()->workflow_db;
				$file = Task_file::model()->findByPk($vv["task_diag_file_id"]);

				CActiveRecord::$db = Yii::app()->doc_db;
				$f = new File2;
				// fs и fd - полные пути
				$fs = Task_file::createPath().$file->link;                           // Что и откуда
				$f->isCommand = true;
				$f->link = createPath(File2::createPath())."/".basename($file->link); // Куда
				$fd = File2::createPath().$f->link;

				$f->name = $vv[''name''];
                $f->document_type = $v["task_diag_param"] === "PROJECT" ? "CONTRACT" : $vv["document_type"];

                if (copy($fs, $fd))
				{
					chown($fd, "wwwrun");
					$f->filename=$f->name;
					$f->filename=$file->filename;
					$f->user_id=$model->user__id;
					$f->document_id=$model->document_id;
					$f->user__id=$model->user__id;
					$f->save();
				}
				else
				{
					$trn->rollBack();
					x("Ошибка при копировании файла.");
				}
            }
		}

		if (empty($task_files)
			&& Yii::app()->db->CreateCommand("select _int from task_param where task_id={$task_id} and task_diag_param = ''ACCEPTED_AS_ORIGINAL''")->queryScalar())
		{
			$preliminary_scan = Yii::app()->db->CreateCommand("select _varchar as filename, _text as link from task_param where task_id={$task_id} and task_diag_param = ''PRELIMINARY_SCAN'' and _text is not null")->queryRow();
			if (is_array($preliminary_scan))
			{
				CActiveRecord::$db = Yii::app()->doc_db;
				$f = new File2;
				$fs = Task_file::createPath().$preliminary_scan["link"];
				$f->isCommand = true;
				$f->link = createPath(File2::createPath())."/".basename($preliminary_scan["link"]);
				$fd = File2::createPath().$f->link;

				$f->name = $preliminary_scan["filename"];
				$f->document_type = "CONTRACT";

				if (copy($fs, $fd))
				{
					chown($fd, "wwwrun");
					$f->filename=$preliminary_scan["filename"];
					$f->user_id=$model->user__id;
					$f->document_id=$model->document_id;
					$f->user__id=$model->user__id;
					$f->save();
				}
				else
				{
					$trn->rollBack();
					x("Ошибка при копировании файла.");
				}
			}
		}

		$trn->commit();
	}
	else
	{
		$trn->rollBack();
		pe($model);
	}

    $mapParamsToFields = array(
		"number" => array("task_diag_param" => "CONTRACT_NUMBER_LEGAL", "type" => "_varchar"),
		"start_date" => array("task_diag_param" => "CONTRACT_START_DATE", "type" => "_datetime"),
		"end_date" => array("task_diag_param" => "CONTRACT_END_DATE", "type" => "_datetime"),
		"payment_form_type" => array("task_diag_param" => "PAYMENT_FORM_TYPE", "type" => "_varchar"),
		"currency" => array("task_diag_param" => "CURR", "type" => "_varchar"),
		"contract_type" => array("task_diag_param" => "CONTRACT_TYPE", "type" => "_varchar"),
		"description" => array("task_diag_param" => "DESCRIPTION", "type" => "_text"),
		"krp_company" => array("task_diag_param" => "KRP_COMPANY_FOR_CONTRACT", "type" => "_varchar"),
		"other_payment_form" => array("task_diag_param" => "PAYMENT_FORM_TYPE_OTHER", "type" => "_text"),
		"amount" => array("task_diag_param" => "CONTRACT_AMOUNT", "type" => ''_currency''),
        "postponing" => array("task_diag_param" => "PAYMENT_POSTPONEMENT", "type" => "_text"),
        "currency_rate_type" => array("task_diag_param" => "CURRENCY_RATE_TYPE", "type" => "_varchar"),
        "subject" => array("task_diag_param" => "CONTRACT_SUBJECT", "type" => "_text"),
        "reg_number" => array("task_diag_param" => "REGISTRY_NUMBER", "type" => "_varchar"),
        "reg_date" => array("task_diag_param" => "REGISTRY_DATE", "type" => "_datetime"),
        "is_prolongation" => array("task_diag_param" => "IS_PROLONGABLE", "type" => "_int"),
    );

    CActiveRecord::$db = Yii::app()->doc_db;
    $rc = new Register_contract();

    foreach ($mapParamsToFields as $k => $v)
		$rc->$k = Yii::app()->db->CreateCommand("select {$v[''type'']} from task_param where task_id=$task_id and task_diag_param = ''{$v[''task_diag_param'']}''")->queryScalar();

    $original_type = Yii::app()->db->CreateCommand("select _varchar from task_param where task_id=$task_id and task_diag_param = ''ORIGINAL_TYPE''")->queryScalar();
    $rc->original_type = $original_type ? $original_type : ''SCAN'';

    $rc->name = Yii::app()->db->CreateCommand("select _varchar from task_param where task_id=$task_id and task_diag_param = ''PROJECT''")->queryScalar();
    $rc->owner = 4000;
	$rc->document_id = $model->document_id;
    $c = unserialize(Yii::app()->db->CreateCommand("select _text from task_param where task_id=$task_id and task_diag_param = ''CONTRACTOR_ID''")->queryScalar());
    $c = $c[0];
    $rc->contractor_id = (int)$c["contractor"];
    $rc->storage = ''BUHGALTER'';
    if (!$rc->save())
		p(''Ошибка при сохранении.'', $rc->errorToString());

// Отгружаем в движение
	CActiveRecord::$db = Yii::app()->workflow_db;
	$tp=Task_param::model()->find("task_id={$task_id} and task_diag_param=''RUN_CONTRACT_NUMBER''");
	if ($tp)
	{
		$t=unserialize($tp->_text);
		if (is_array($t) && array_key_exists("uid24", $t) && $t["uid24"]) // Если номера сделки нет, то собственно некуда отгружать и крепить соответственно
			Yii::app()->run_db->CreateCommand("insert into exchange.docprnacc (docname, docurl, login, deal_uid24) values "
				."(''{$model->name}'', ''https://suz.rp.ru/document/view/id/{$model->document_id}'', ''{$task->initiator_->login}'', ''{$t[''uid24'']}'')")
				->query();
	}

;');
    end if;

    return query (select cast(null as varchar));

END;$BODY$
  LANGUAGE plpgsql VOLATILE
  COST 100
  ROWS 1000;
ALTER FUNCTION fn_td_event_cld_create_document(bigint)
  OWNER TO postgres;
GRANT EXECUTE ON FUNCTION fn_td_event_cld_create_document(bigint) TO postgres;
GRANT EXECUTE ON FUNCTION fn_td_event_cld_create_document(bigint) TO public;
SQL;
		/****************************
		*/
	}
}