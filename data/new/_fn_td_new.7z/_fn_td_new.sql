create or replace function fn_td_event_cld_create_document(sid bigint)
	returns SETOF character varying
language plpgsql
as $$
declare
	is_regscan smallint;
	tid bigint;
BEGIN

	select task_id into tid from subtask where subtask_id=sid;
	select _int into is_regscan from task_param where task_id=tid and task_diag_param='IS_REGISTER_AND_SCAN_COMPLETED';

	if (is_regscan = 1) then

		update task set is_success=1 where task_id=tid;

		insert into crond_task (script) values ('(new FNCreateDocument)->run(' || tid || ');');

	end if;
	return query (select cast(null as varchar));

END;
$$;
ALTER FUNCTION fn_td_event_cld_create_document(bigint)
OWNER TO postgres;
GRANT EXECUTE ON FUNCTION fn_td_event_cld_create_document(bigint) TO postgres;
GRANT EXECUTE ON FUNCTION fn_td_event_cld_create_document(bigint) TO web;

----------------fn_td_event_sf_resubordinate------------------
----------------fn_td_event_sf_change_position----------------
----------------fn_td_event_sf_disabled_position--------------
----------------fn_td_event_sf_disabled_position_itr----------
----------------fn_td_event_sf_disabled_department------------
----------------fn_td_event_sf_disabled_department_itr--------
-----------fn_td_event_sf_create_position_itr---тольк удалил закоменченое и неиспользуемое----
create or replace function fn_td_event_sf_change_position(sid bigint)
	returns SETOF character varying
language plpgsql
as $$
declare
	tid bigint;
BEGIN
	select s.task_id into tid from subtask s where s.subtask_id=sid;

	-- Выясняем все ли согласовали
	if ((select count(*)-sum(_int) from task_param
	where task_diag_param in ('APPROVE_ZAM_HEAD_OF_STAFF_TRANSFER_TO_ANOTHER_POSITION', 'IN_CONCERT_WITH_UNIT_MANAGER_TRANSLATION_ANOTHER_POST')
		  and task_id=tid)=0) then

		insert into crond_task ("script", process_date)
		values('(new FNEventChangePosition)->run(' || tid || ');',
			   (select _datetime from task_param
			   where task_id=tid
					 and task_diag_param='DATE_TRANSFER_TO_ANOTHER_POSITION'));
	end if;

	return query (select cast(null as varchar));

END;
$$;
ALTER FUNCTION fn_td_event_sf_change_position(bigint)
OWNER TO postgres;
GRANT EXECUTE ON FUNCTION fn_td_event_sf_change_position(bigint) TO postgres;
GRANT EXECUTE ON FUNCTION fn_td_event_sf_change_position(bigint) TO web;

create function fn_td_event_sf_resubordinate(sid bigint)
	returns SETOF character varying
language plpgsql
as $$
declare
	tid bigint;



BEGIN
	select s.task_id into tid from subtask s where s.subtask_id=sid;

	-- Выясняем все ли согласовали
	if ((select count(*)-sum(_int) from task_param
	where task_diag_param in ('IS_IN_CONCERT_WITH_THE_DEPUTY_DIRECTOR_ON_WORK_WITH_PERSONNEL', 'IS_IN_CONCERT_WITH_UNIT_MANAGER')
		  and task_id=tid)=0) then



		insert into crond_task ("script", process_date)
		values ('(new FNEventResubordinate)->run(' || tid || ');', (select _datetime from task_param
		where task_id=tid
			  and task_diag_param='APPLY_DATE_SUBORDINATION_POSITIONS'));
	end if;

	return query (select cast(null as varchar));

END;
$$;

ALTER FUNCTION fn_td_event_sf_resubordinate(bigint)
OWNER TO postgres;
GRANT EXECUTE ON FUNCTION fn_td_event_sf_resubordinate(bigint) TO postgres;
GRANT EXECUTE ON FUNCTION fn_td_event_sf_resubordinate(bigint) TO web;



create function fn_td_event_sf_disabled_position(sid bigint)
	returns SETOF character varying
language plpgsql
as $$
declare
	tid bigint;
BEGIN
	select s.task_id, into tid from subtask s where s.subtask_id=sid;

	-- Выясняем все ли согласовали
	if ((select count(*)-sum(_int) from task_param
	where task_diag_param in ('IS_STAFF_CHANGE_SALARY_APROVE_HEAD_SBE', 'IS_STAFF_CHANGE_SALARY_APROVE_ZAM', 'IS_APPROVAL_OF_THE_HEAD')
		  and task_id=tid)=0) then

		insert into crond_task ("script", process_date)
		values('(new FNEventDisabledPosition)->run(' || tid || ');',
			   (select _datetime from task_param
			   where task_id=tid
					 and task_diag_param='APPLY_DATE'));
	end if;

	return query (select cast(null as varchar));

END;
$$;
ALTER FUNCTION fn_td_event_sf_disabled_position(bigint)
OWNER TO postgres;
GRANT EXECUTE ON FUNCTION fn_td_event_sf_disabled_position(bigint) TO postgres;
GRANT EXECUTE ON FUNCTION fn_td_event_sf_disabled_position(bigint) TO web;


create function fn_td_event_sf_disabled_position_itr(sid bigint)
	returns SETOF character varying
language plpgsql
as $$
declare
	tid bigint;
BEGIN
	select s.task_idinto tid from subtask s where s.subtask_id=sid;

	-- Выясняем все ли согласовали
	if ((select count(*)-sum(_int) from task_param
	where task_diag_param in ('COORDINATED_DEPUTY_ZAM_DIR_HR_REDUCTION_POSTS_ITR')
		  and task_id=tid)=0) then

		insert into crond_task ("script", process_date)
		values ('(new FNEventDisabledPosition)->runITR(' || tid || ');'
			, (select _datetime from task_param
			where task_id=tid
				  and task_diag_param='APPLY_DATE_ITR'));
	end if;

	return query (select cast(null as varchar));

END;
$$;
ALTER FUNCTION fn_td_event_sf_disabled_position_itr(bigint)
OWNER TO postgres;
GRANT EXECUTE ON FUNCTION fn_td_event_sf_disabled_position_itr(bigint) TO postgres;
GRANT EXECUTE ON FUNCTION fn_td_event_sf_disabled_position_itr(bigint) TO web;

create function fn_td_event_sf_disabled_department(sid bigint)
	returns SETOF character varying
language plpgsql
as $$
declare
	tid bigint;
BEGIN
	select s.task_id into tid from subtask s where s.subtask_id=sid;

	-- Выясняем все ли согласовали
	if ((select count(*)-sum(_int) from task_param
	where task_diag_param in ('APPROVAL_OF_THE_HEAD_ZAM_REDUCTION_UNIT', 'APPROVAL_OF_THE_HEAD_REDUCTION_UNIT', 'IN_CONCERT_THE_HEAD_SBE_REDUCTION_UNIT')
		  and task_id=tid)=0) then

		insert into crond_task ("script", process_date)
		values ('(new FNEventDisabledDepartment)->run(' || tid || ');'
			, (select _datetime from task_param
			where task_id=tid
				  and task_diag_param='APPLY_DATE'));
	end if;

	return query (select cast(null as varchar));

END;
$$;
ALTER FUNCTION fn_td_event_sf_disabled_department(bigint)
OWNER TO postgres;
GRANT EXECUTE ON FUNCTION fn_td_event_sf_disabled_department(bigint) TO postgres;
GRANT EXECUTE ON FUNCTION fn_td_event_sf_disabled_department(bigint) TO web;

create function fn_td_event_sf_disabled_department_itr(sid bigint)
	returns SETOF character varying
language plpgsql
as $$
declare
	tid bigint;
BEGIN
	select s.task_id into tid from subtask s where s.subtask_id=sid;

	-- Выясняем все ли согласовали
	if ((select count(*)-sum(_int) from task_param
	where task_diag_param in ('COORDINATED_DEPUTY_ZAM_DIR_HR_REDUCTION_POSTS_ITR')
		  and task_id=tid)=0) then

		insert into crond_task ("script", process_date)
		values ('(new FNEventDisabledDepartment)->runITR(' || tid || ');'
			, (select _datetime from task_param
			where task_id=tid
				  and task_diag_param='APPLY_DATE_ITR'));
	end if;

	return query (select cast(null as varchar));

END;
$$;
ALTER FUNCTION fn_td_event_sf_disabled_department_itr(bigint)
OWNER TO postgres;
GRANT EXECUTE ON FUNCTION fn_td_event_sf_disabled_department_itr(bigint) TO postgres;
GRANT EXECUTE ON FUNCTION fn_td_event_sf_disabled_department_itr(bigint) TO web;

create function fn_td_event_sf_create_position_itr(sid bigint)
	returns SETOF character varying
language plpgsql
as $$
declare
	tid bigint;
	uid integer;
	pname varchar(127);
	puid varchar(24);
	pgt varchar(64);
	pgid integer;

	gid bigint;

BEGIN
	select s.task_id, coalesce(t.shadow_initiator, t.initiator) into tid, uid from subtask s
		inner join task t on t.task_id=s.task_id
	where s.subtask_id=sid;

	-- Выясняем все ли согласовали
	if ((select count(*)-sum(_int) from task_param
	where task_diag_param in ('COORDINATED_DEPUTY_ZAM_DIR_HR_ITR')
		  and task_id=tid)=0) then

		select _varchar into pname from task_param
		where task_id=tid
			  and task_diag_param='STAFF_LIST_POSITION_NEW_ITR';

		-- Проверяем есть ли такая должность в справочнике
		select post into puid from post
		where name=pname;
		if (puid is null) then
			insert into post (name, is_visible) values (pname, 1) returning post into puid;
		end if;

		-- Создаем должность
		select _int into pgid from task_param
		where task_id=tid
			  and task_diag_param='STAFF_LIST_POSITION_ITR';

		select groupe_type into pgt from groupe
		where groupe_id=pgid;

		insert into groupe (name, post, is_disabled, groupe_type, user__id) values (pname, puid, 0, pgt, uid) returning groupe_id into gid;

		insert into groupe_tree (parent_id, child_id, user__id) values ((select fn_get_assistant(pgid)), gid, uid);

	end if;

	return query (select cast(null as varchar));

END;
$$;
ALTER FUNCTION fn_td_event_sf_create_position_itr(bigint)
OWNER TO postgres;
GRANT EXECUTE ON FUNCTION fn_td_event_sf_create_position_itr(bigint) TO postgres;
GRANT EXECUTE ON FUNCTION fn_td_event_sf_create_position_itr(bigint) TO web;


create function fn_td_event_dae_dismissal_user(sid bigint)
	returns SETOF character varying
language plpgsql
as $$
declare
	tid bigint;
BEGIN
	select s.task_id into tid from subtask s where s.subtask_id=sid;

	if (((select count(*) from task_param
	where task_id=tid
		  and task_diag_param in ('APPROVAL_OF_DEPUTY_DIRECTOR_FOR_WORK_WITH_PERSONNEL_OF_EMPLO',
								  'IN_COORDINATION_WITH_THE_DIVISION_MANAGER_EMPLOYEE', 'IN_CONCERT_WITH_THE_HEAD_OF_SBE_EMPLOYEE'))
		 -(select sum(_int) from task_param
	where task_id=tid
		  and task_diag_param in ('APPROVAL_OF_DEPUTY_DIRECTOR_FOR_WORK_WITH_PERSONNEL_OF_EMPLO',
								  'IN_COORDINATION_WITH_THE_DIVISION_MANAGER_EMPLOYEE', 'IN_CONCERT_WITH_THE_HEAD_OF_SBE_EMPLOYEE')))=0) then

		insert into crond_task (script)
		values ('(new FNEventDismissalUser)->run('|| tid ||');'
		);
	end if;

	return query (select cast(null as varchar));

END;
$$;
ALTER FUNCTION fn_td_event_dae_dismissal_user(bigint)
OWNER TO postgres;
GRANT EXECUTE ON FUNCTION fn_td_event_dae_dismissal_user(bigint) TO postgres;
GRANT EXECUTE ON FUNCTION fn_td_event_dae_dismissal_user(bigint) TO web;

create or replace function fn_td_event_cot_create_department_post(sid bigint)
	returns SETOF character varying
language plpgsql
as $$
declare
	tid bigint;
	uid integer;

	c bigint;
	dgid bigint;
	pgid bigint;
	pid character varying;
	d character varying;
	p character varying;

	ad timestamp without time zone;
	ad_ timestamp without time zone;
	i smallint;
BEGIN
	ad_=null;
	select task_id into tid from subtask where subtask_id=sid;
	select initiator into uid from task where task_id=tid;

	-- Применение изменений в оргструктуру

	select * into c, dgid, pgid, d, p, pid from department_post where department_post_id=fn_get_int(tid, 'DEPARTMENT_POSITION');
	ad=fn_get_datetime(tid, 'APPLY_DATE');
	c=fn_get_int(tid, 'REMOVE_VACANCY');

	if (c>0) then
		ad_=ad;
		if (pgid is not null) then -- Упразднить должность
			insert into crond_task (script, process_date) values
				('(new FNEventCreateDepartmentPost)->run(['|| tid ||');' ,ad);
			raise notice '%';
		else
			if (dgid is not null) then -- Упразднить руководящую должность и подразделение которым она руководит

				insert into crond_task (script, process_date) values
					('(new FNEventCreateDepartmentPost)->removeManagerPost('|| tid ||');' ,ad);
				raise notice '%';
			end if;
		end if;
	else
		c=fn_get_int(tid, 'ADD_VACANCY');
		d=replace(d, '"', '\"');
		p=replace(p, '"', '\"');
		if ((c>0) or (d is not null)) then
			if (pgid is not null) then -- Увеличить количество ставок на должности
				update groupe_param set vacancy=vacancy + c where groupe_id=pgid;
				update groupe set is_disabled=0, user__id=uid where groupe_id=pgid;
			else
				if (dgid is not null) then -- Подразделение задано, добавляем туда должность и ставки
					-- REMARK - дальше применяется потенциально косячный алгоритм генерации должностей и подразделений связанный с тем, что
					--	сделана ставка на то, что между выполнением команды вставки в таблицу и следующей командой никто не успеет проскочить
					--	принципе все таблицы малонагруженные по операциям вставки, поэтому пока оставим так, если будут косяки, то надо переписывать с изменение скрипта
					--	и открытием транзакции в PHP

					if (d is not null) then -- Задано подразделение в свободном виде, значит создаем новое подразделение
						if ((pid is not null) or (p is not null)) then -- Должность из справочника

							if ((pid is null) and (p is not null)) then -- Должность в свободном виде
								pid=fn_create_uid24(0);
								insert into post (post, name, is_visible) values (pid, p, 1);

							end if;

							if (c>0) then c=1; -- Руководящих ставок может быть только 1
							else c=0; end if; -- Но у подразделения может не быть руководителя, тогда ставок нет

							insert into groupe (name, is_disabled, groupe_type, user__id, post, is_manager, department_name) values
								((select name from post where post=pid), 0, 'KRP', uid, pid, 1, d);

							update groupe_param set vacancy=cast(c as varchar) where groupe_id=(select groupe_id from groupe order by groupe_id desc limit 1);

							-- Следующая операция более затратная, поэтому делаем последней, чтобы не поиметь проблем с параллельными потоками
							insert into groupe_tree (parent_id, child_id, user__id) values (fn_get_assistant(dgid), (select groupe_id from groupe order by groupe_id desc limit 1),uid );

							insert into groupe (name, is_disabled, groupe_type, user__id, is_manager)
							values ((select 'Заместитель руководителя ' || name from post where post= pid ), 0, 'KRP', uid, 1);

							-- Будем надеятся что еще никто не успел вклиниться
							insert into groupe_tree (parent_id, child_id, user__id) values ((select groupe_id from (select groupe_id from groupe order by groupe_id desc limit 2) as t order by groupe_id limit 1), (select groupe_id from groupe order by groupe_id desc limit 1), uid);

						end if;
					else
						if ((pid is not null) or (p is not null)) then -- Должность из справочника

							if ((pid is null) and (p is not null)) then -- Должность в свободном виде
								pid=fn_create_uid24(0);
								insert into post (post, name, is_visible) values (pid , p , 1);

							end if;

							insert into groupe (name, is_disabled, groupe_type, user__id, post) values ((select name from post where post= pid ), 0, 'KRP', uid, pid);

							update groupe_param set vacancy=c where groupe_id=(select groupe_id from groupe order by groupe_id desc limit 1); -- Руководящих ставок может быть только 1

							-- Следующая операция более затратная, поэтому делаем последней, чтобы не поиметь проблем с параллельными потоками
							insert into groupe_tree (parent_id, child_id, user__id) values (fn_get_assistant(dgid), (select groupe_id from groupe order by groupe_id desc limit 1), uid );
						end if;
					end if;
				end if;

			-- Остальные варианты в лес, потому что если нет подразделения то непонятно собственно куда в дереве надо прикреплять должность или подразделение
			end if;
		else
			c=fn_get_int(tid, 'MINUS_VACANCY');

			if ((c>0) and (pgid is not null)) then -- Сократить количество ставок на должности в подразделении. Руководящие должности можно только упразднить только вместе с подразделением
				update groupe_param set vacancy=vacancy - c where groupe_id= pgid;
			end if;
			-- Остальные варианты упразднения игнорируем
		end if;
	end if;

	return query (select cast(null as varchar));

END;
$$;
ALTER FUNCTION fn_td_event_cot_create_department_post(bigint)
OWNER TO postgres;
GRANT EXECUTE ON FUNCTION fn_td_event_cot_create_department_post(bigint) TO postgres;
GRANT EXECUTE ON FUNCTION fn_td_event_cot_create_department_post(bigint) TO web;


create function fn_td_event_cld_accept_document_as_original(sid bigint)
	returns SETOF character varying
language plpgsql
as $$
declare
	is_regscan smallint;
	tid bigint;
BEGIN

	select task_id into tid from subtask where subtask_id=sid;
	select _int into is_regscan from task_param where task_id=tid and task_diag_param='IS_PRESENT_ORIGINAL';

	if (is_regscan = 1) then

		update task set is_success=1 where task_id=tid;

		insert into crond_task (script) values ('(new FNEventDocumentAsOriginal())->run(' || tid || ');');

	end if;
	return query (select cast(null as varchar));

END;
$$;
ALTER FUNCTION fn_td_event_cld_accept_document_as_original(bigint)
OWNER TO postgres;
GRANT EXECUTE ON FUNCTION fn_td_event_cld_accept_document_as_original(bigint) TO postgres;
GRANT EXECUTE ON FUNCTION fn_td_event_cld_accept_document_as_original(bigint) TO web;

create or replace function fn_td_event_sc_change_salary(sid bigint)
	returns SETOF character varying
language plpgsql
as $$
declare
	tid bigint;
	uid integer;
BEGIN
	select s.task_id, t.initiator
	into tid, uid
	from subtask s
		inner join task t on t.task_id=s.task_id
	where s.subtask_id=sid;

	if (
		(((select _int from task_param
		where task_id=tid
			  and task_diag_param='IS_LIKHAREV')=1)
		 and (((select _int from task_param
		where task_id=tid
			  and task_diag_param='IS_STAFF_CHANGE_SALARY_APROVE_HEAD_SBE')=1))
		)
		or (
			((select _int from task_param
			where task_id=tid
				  and task_diag_param='IS_LIKHAREV')=0)
			and (
				((select _int from task_param
				where task_id=tid
					  and task_diag_param='IS_STAFF_CHANGE_SALARY_APROVE_HEAD')=1))))
	then
		update user_param set salary=(select _int from task_param
		where task_id=tid
			  and task_diag_param='SALARY_OKLAD')
			, user__id=uid where user_id= (select _int from task_param
		where task_id=tid
			  and task_diag_param='INVITATION_EMPLOYEE') ;
	end if;

	return query (select cast(null as varchar));

END;
$$;
ALTER FUNCTION fn_td_event_sc_change_salary(bigint)
OWNER TO postgres;
GRANT EXECUTE ON FUNCTION fn_td_event_sc_change_salary(bigint) TO postgres;
GRANT EXECUTE ON FUNCTION fn_td_event_sc_change_salary(bigint) TO web;

create or replace function fn_td_event_scs_change_salary(sid bigint)
	returns SETOF character varying
language plpgsql
as $$
declare
	tid bigint;
	uid integer;

	min_ bigint;
	max_ bigint;
	gid bigint;

BEGIN
	select s.task_id, t.initiator
	into tid, uid
	from subtask s
		inner join task t on t.task_id=s.task_id
	where s.subtask_id=sid;
	select _int into min_ from task_param
	where task_id=tid
		  and task_diag_param='STAFF_CHANGE_SALARY_MIN';
	select _int into max_ from task_param
	where task_id=tid
		  and task_diag_param='STAFF_CHANGE_SALARY_MAX';
	select _int into gid from task_param
	where task_id=tid
		  and task_diag_param='UNIT_STAFF';
	if ((min_ is not null)
		and (max_ is not null)
		and (gid is not null)
		and (uid is not null)
		and (select _int from task_param
	where task_id=tid
		  and task_diag_param='IS_STAFF_CHANGE_SALARY_APROVE_HEAD_SBE')=1) then
		update groupe_param set min_salary=min_ , max_salary= max_ , user__id=uid where groupe_id= gid;
	end if;


	return query (select cast(null as varchar));

END;
$$;

ALTER FUNCTION fn_td_event_scs_change_salary(bigint)
OWNER TO postgres;
GRANT EXECUTE ON FUNCTION fn_td_event_scs_change_salary(bigint) TO postgres;
GRANT EXECUTE ON FUNCTION fn_td_event_scs_change_salary(bigint) TO web;

create or replace function fn_td_event_tew_create_user(sid bigint)
	returns SETOF character varying
language plpgsql
as $$
declare
	tid bigint;
	uid integer;
	message varchar;

	pf varchar;
	lpf varchar;
	isok smallint;
BEGIN
	select task_id, user_id into tid, uid from subtask where subtask_id=sid;
	select _int into isok from task_param where task_id=tid and task_diag_param='IS_OK';

	if ((isok is null) or (isok=0)) then

		-- Задание на создание пользователя в СУЗ, LDAP, заданий в Helpdesc

		insert into crond_task (script) values ('(new FNEventTewCreateUser())->run('|| sid ||');');

		-- На всякий случай проверим, если есть фото, то добавим задачу в крон
		select replace(replace(substring(trim(_varchar) from 1 for 256), '"', ''), '''', ''),
			replace(replace(substring(trim(_text) from 1 for 256), '"', ''), '''', '') into pf, lpf
		from task_param
		where task_id=tid
			  and task_diag_param='PHOTO'
			  and is_file=1
			  and is_readonly=1;

		if ((pf is not null) and (lpf is not null)) then -- Для обработки фотки ставим отдельное задание, вероятность что оно навернется достаточна большая
			insert into crond_task (script) values ('(new FNEventTewCreateUser())->resamplePhoto('|| tid ||');');
		end if;

		-- Рассылает уведомления в АХО и Техотдел о смене даты выхода сотрудника
		-- оставлено в SQL, т.к. никакой генерации PHP кода в этой части нет
		if ((select _int from task_param
		where task_diag_param='CONFIRM_NEW_DATE_EMPLOYEE'
			  and task_id=tid
			 limit 1)=1) then
			insert into sendmail (email, subject, body, return_name)
				(select email, 'СУЗ - изменена дата выхода нового сотрудника', '<html><body>Дата выхода - '
																			|| coalesce((select _varchar from task_param
				where task_diag_param='FMS' and task_id=tid), 'Сотрудника определить не удалось. Процесс - ' || cast(tid as varchar))
																			|| ' изменена c - '
																			|| coalesce((select to_char(_datetime, 'DD.MM.YYYY') from task_param
				where task_diag_param='ESTIMATED_DATE' and task_id=tid ), 'Изначальную дату не задали. Процесс - ' || cast(tid as varchar))
																			|| ' на - '
																			|| coalesce((select to_char(_datetime, 'DD.MM.YYYY') from task_param
				where task_diag_param='NEW_ESTIMATED_DATE' and task_id=tid ), 'Новую дату не задали. Процесс - ' || cast(tid as varchar))
																			|| '</body></html>', 'СУЗ' from "user" u
					inner join user_groupe ug on ug.user_id=u.user_id
					inner join groupe g on g.groupe_id=ug.groupe_id
				 where g.code in ('KRP_AHO', 'TECH_DEPARTMENT', '_KRP_AHO', '_TECH_DEPARTMENT', 'HEAD_SECRETARY', '_HEAD_SECRETARY', 'SECRETARY'));
		end if;

		-- Отмечаем что пользователя уже создали
		if (isok is null) then insert into task_param (task_id, _int, task_diag_param, user_id) values (tid, 1, 'IS_OK', uid);
		else update task_param set _int=1 where task_diag_param='IS_OK' and task_id=tid;
		end if;
	end if;

	return query (select cast(null as varchar));

END;
$$;


ALTER FUNCTION fn_td_event_tew_create_user(bigint)
OWNER TO postgres;
GRANT EXECUTE ON FUNCTION fn_td_event_tew_create_user(bigint) TO postgres;
GRANT EXECUTE ON FUNCTION fn_td_event_tew_create_user(bigint) TO web;

create or replace function fn_td_event_sf_create_position(sid bigint)
	returns SETOF character varying
language plpgsql
as $$
declare
	tid bigint;
BEGIN
	select s.task_id into tid from subtask s where s.subtask_id=sid;

	-- Выясняем все ли согласовали
	if ((select count(*)-sum(_int) from task_param
	where task_diag_param in ('IS_STAFF_CHANGE_SALARY_APROVE_ZAM', 'IS_STAFF_CHANGE_SALARY_APROVE_HEAD', 'IS_STAFF_CHANGE_SALARY_APROVE_HEAD_SBE')
		  and task_id=tid)=0) then

		insert into crond_task ("script", process_date)
		values ('(new FNEventCreatePosition())->run(' || sid || ')', (select _datetime from task_param
		where task_id=tid
			  and task_diag_param='APPLY_DATE'));
	end if;

	return query (select cast(null as varchar));

END;
$$;
ALTER FUNCTION fn_td_event_sf_create_position(bigint)
OWNER TO postgres;
GRANT EXECUTE ON FUNCTION fn_td_event_sf_create_position(bigint) TO postgres;
GRANT EXECUTE ON FUNCTION fn_td_event_sf_create_position(bigint) TO web;


/*INSERT INTO "public"."subtask" ("subtask_id", "task_id", "task_diag_node_id", "name", "owner", "priority", "create_date", "desirable_date", "due_date", "panic_date", "warning_date", "planned_date", "end_date", "user_id", "execute_time", "is_check_executed", "err", "err_date", "owner_groupe_id", "subtask_type", "is_concentrator") VALUES (DEFAULT, 70106, 87, 'Тестовый прием на работу', 7464, DEFAULT, DEFAULT, 'NULL', 'NULL', 'NULL', 'NULL', 'NULL', 'NULL', 7464, 'NULL', DEFAULT, 'NULL', DEFAULT, NULL, 'WAIT', DEFAULT)
INSERT INTO "public"."task" ("task_id", "task_diag", "name", "initiator", "start_subtask_id", "priority", "create_date", "desirable_date", "due_date", "end_date", "panic_date", "warning_date", "is_canceled", "user_id", "is_complete", "start_task_diag_id", "task_order_id", "task_link_id", "planned_time", "user_percent", "task_type", "planned_start_date", "is_approved", "initiator_groupe_id", "shadow_initiator", "shadow_initiator_groupe_id", "is_success", "is_terminated") VALUES (70106, 'EMPLOYMENT', 'Тестовый пользак', 7464, NULL, DEFAULT, DEFAULT, 'NULL', 'NULL', 'NULL', 'NULL', 'NULL', DEFAULT, 7464, DEFAULT, NULL, NULL, NULL, 'NULL', DEFAULT, 'NULL', 'NULL', DEFAULT, NULL, NULL, NULL, NULL, DEFAULT)
insert into task_param ("task_param_id","task_id","_currency","_float","_datetime","_int","_numeric","_text","_varchar",
						"is_file","is_readonly","task_diag_param","user_id","owner","success",
						"subtask_id","file_attribute_name") values
	(517908,70106,null,null,null,null,null,null,'NEW',0,0,'WORKPLACE',4492,null,0,null,null),
	(517901,70106,null,null,null,null,null,'Мобильная связь - пакет 4',null,0,0,'COMPENSATING_OTHER',4492,null,0,null,null),
	(517891,70106,null,null,null,null,null,null,'Губарева Юлия Викторовна',0,0,'FMS',4492,null,0,null,null),
	(517892,70106,null,null,null,0,null,null,null,0,0,'IS_REINCARNATION',4492,null,0,null,null),
	(517893,70106,null,null,null,2096,null,null,null,0,0,'DEPARTMENT_POSITION2',4492,null,0,null,null),
	(517894,70106,null,null,null,917,null,null,null,0,0,'OFFICE',4492,null,0,null,null),
	(517895,70106,null,null,null,null,null,null,'OTHER_SRE',0,0,'SEARCH_REASON_EMLOYEE',4492,null,0,null,null),
	(517896,70106,null,null,null,null,null,'Реорганизация департамента',null,0,0,'ADD_INFO_SRE',4492,null,0,null,null),
	(517897,70106,null,null,'2018-07-02 09:00:00',null,null,null,null,0,0,'ESTIMATED_DATE',4492,null,0,null,null),
	(517898,70106,null,null,null,null,null,'В разработке',null,0,0,'FORMULA_PAYMENT_BONUSES',4492,null,0,null,null),
	(517899,70106,null,null,null,null,null,null,'NET',0,0,'SALARY_TYPE',4492,null,0,null,null),
	(517900,70106,null,null,null,null,null,null,'PF_MONTH',0,0,'PAYMENT_FORM',4492,null,0,null,null),
	(517902,70106,null,null,null,null,null,'3 месяца',null,0,0,'TRAIL_PERIOD',4492,null,0,null,null),
	(517903,70106,null,null,null,null,null,'2018/06/1530254062.4593.JPG','паспорт Губарева0004.JPG',1,1,'SCAN_PASSPORT',4492,null,0,null,null),
	(517904,70106,null,null,null,null,null,'2018/06/1530254062.4613.JPG','паспорт Губарева0005.JPG',1,1,'SCAN_PASSPORT',4492,null,0,null,null),
	(517907,70106,null,null,'1977-04-14 00:00:00',null,null,null,null,0,0,'BIRTH_DATE',4492,null,0,null,null),
	(517935,70106,null,null,null,null,null,null,null,0,0,'COMMENTS_PERSONNEL_MANAGMENT',4492,null,0,null,null),
	(517909,70106,null,null,null,'1',null,null,null,0,0,'PROVISION_MOBILE',4492,null,0,null,null),
	(517911,70106,null,null,null,null,null,null,'+79184310990',0,0,'PRIVATE_MOBILE',4492,null,0,null,null),
	(517920,70106,null,null,null,null,null,'2018/06/1530254739.2253.odt','Губарева_Юлия_39576217.odt',1,1,'RESUME_FILE',4492,null,0,null,null),
	(517906,70106,null,null,null,null,null,null,null,0,0,'PASSPORT',4492,null,0,null,null),
	(517921,70106,null,null,null,'1',null,null,null,0,0,'IS_HR',4492,null,0,null,null),
	(517923,70106,null,null,null,'120000',null,null,null,0,0,'SALARY_TRAIL_CANDIDATE',4492,null,0,null,null),
	(517924,70106,null,null,null,'120000',null,null,null,0,0,'SALARY_CANDIDATE',4492,null,0,null,null),
	(517925,70106,null,null,null,'0',null,null,null,0,0,'IS_PERSON_AUTO',4492,null,0,null,null),
	(517934,70106,null,null,null,'1',null,null,null,0,0,'RECOMMENDED_PERSONNEL_MANAGMENT',4492,null,0,null,null),
	(517936,70106,null,null,null,'405',null,null,null,0,0,'KRP_COMPANY',4492,null,0,null,null),
	(517922,70106,null,null,null,null,null,'106',null,0,0,'CABINET',4492,null,0,null,null),
	(517938,70106,null,null,null,'1',null,null,null,0,0,'READY_DIRECTOR_MANAGMENT',4492,null,0,null,null),
	(517926,70106,null,null,null,null,null,null,null,0,0,'CAR_MODEL',4492,null,0,null,null),
	(517927,70106,null,null,null,null,null,null,null,0,0,'CAR_PASSPORT',4492,null,0,null,null),
	(517928,70106,null,null,null,null,null,null,null,0,0,'CAR_YEAR_CREATE',4492,null,0,null,null),
	(517929,70106,null,null,null,null,null,null,null,0,0,'CAR_ENGINE',4492,null,0,null,null),
	(518286,70106,null,null,null,'1',null,null,null,0,0,'RECOMMENDED_SECURITY',4225,null,0,null,null),
	(518287,70106,null,null,null,null,null,null,null,0,0,'COMMENTS_SECURITY',4225,null,0,null,null),
	(517930,70106,null,null,null,null,null,null,null,0,0,'CAR_NUMBER',4492,null,0,null,null),
	(517931,70106,null,null,null,null,null,null,null,0,0,'COLOR',4492,null,0,null,null),
	(517932,70106,null,null,null,null,null,null,null,0,0,'CAR_COMPENSATION_AMOUNT',4492,null,0,null,null),
	(517933,70106,null,null,null,null,null,null,null,0,0,'CAR_GASOLINE_COMPENSATION_AMOUNT',4492,null,0,null,null),
	(517890,70106,null,null,null,'665',null,null,null,0,0,'WORK_DAY',4492,null,0,null,null),
	(517937,70106,null,null,null,null,null,null,null,0,0,'SALARY_NON_STANDART',4492,null,0,null,null),
	(518296,70106,null,null,null,'1',null,null,null,0,0,'RECOMMENDED_DIRECTOR_PERSONNEL_MANAGMENT',4492,null,0,null,null),
	(518297,70106,null,null,null,null,null,null,null,0,0,'COMMENTS_DIRECTOR_PERSONNEL_MANAGMENT',4492,null,0,null,null),
	(518313,70106,null,null,null,'1',null,null,null,0,0,'RECOMMENDED_FINANCE_DIRECTOR',4554,null,0,null,null),
	(518314,70106,null,null,null,null,null,null,null,0,0,'COMMENTS_FINANCE_DIRECTOR',4554,null,0,null,null),
	(518315,70106,null,null,'2018-07-02 09:00:00',null,null,null,null,0,0,'DATE_ORGANIZATION_WORKPLACE',4554,null,0,null,null),
	(518316,70106,null,null,'2018-07-02 09:00:00',null,null,null,null,0,0,'DATE_ORGANIZATION_WORKSTATION',4554,null,0,null,null),
	(518339,70106,null,null,null,'1',null,null,null,0,0,'READY_CONFIRMATION',7134,null,0,null,null),
	(518340,70106,null,null,null,'1',null,null,null,0,0,'IS_EQUAL_DATE',7134,null,0,null,null),
	(518441,70106,null,null,null,'1',null,null,null,0,0,'IS_OK',4235,null,0,null,null),
	(518646,70106,null,null,null,'1',null,null,null,0,0,'IS_CONTRACT_SIGNED',5408,null,0,null,null),
	(517910,70106,null,null,null,null,null,null,null,0,0,'PRIVATE_PHONE',4191,null,0,null,null),
	(519325,70106,null,null,null,'1',null,null,null,0,0,'IS_MANAGE_CONTRACT_SIGNED',4191,null,0,null,null),
	(519833,70106,null,null,null,null,null,null,'79167684623',0,0,'MOBILE_PHONE',7134,null,0,null,null),
	(519834,70106,null,null,null,'1',null,null,null,0,0,'IS_MOBILE_PHONE',7134,null,0,null,null),
	(525715,70106,null,null,null,'1',null,null,null,0,0,'IS_ADMINISTRATIVE_CONTRACT_SIGNED',4286,null,0,null,null),
	(517912,70106,null,null,null,'4',null,null,null,0,0,'COMPENSATING_MOBILE',4492,null,0,null,null);

select
			(select replace(replace(substring(trim(_varchar) from 1 for 20), '"', ''), '''', '') from task_param
					where task_id=st.task_id
				and task_diag_param='PRIVATE_PHONE') as pp,
			(select replace(replace(substring(trim(_varchar) from 1 for 20), '"', ''), '''', '') from task_param
				where task_id=st.task_id
			  and task_diag_param='PRIVATE_MOBILE') as pmp,
			(select _datetime bd from task_param
				where task_id=st.task_id
					and task_diag_param='BIRTH_DATE') as bd,
			(select _int from task_param
				where task_id=st.task_id
			  and task_diag_param='IS_REINCARNATION') as isreinc,
			(select replace(replace(replace(_varchar, '"', ''), '''', ''), '  ', ' ') from task_param
				where task_id=st.task_id
				and task_diag_param='FMS') as fms_,
			(select _int from task_param
				where task_id=st.task_id
				and task_diag_param='OFFICE') as office,
			replace(replace(substring(trim(ph._varchar) from 1 for 256), '"', ''), '''', '') as pf, replace(replace(substring(trim(ph._text) from 1 for 256), '"', ''), '''', '') as lpf,
		st.task_id as tid, st.user_id as uid from subtask st
		left join task_param ph
		on ph.task_id=st.task_id
			  and ph.task_diag_param='PHOTO'
			  and ph.is_file=1
			  and ph.is_readonly=1
		where st.subtask_id=203617 ;
select dept_post.department_groupe_id as dgid
	,replace(replace(dept.department_name, '"', ''), '''', '') as department
	,replace(replace(post_groupe.name, '"', ''), '''', '') as post
from department_post as dept_post
	join  groupe dept
		on dept.groupe_id = dept_post.department_groupe_id
	left join groupe as post_groupe on  post_groupe.groupe_id=dept_post.post_groupe_id
where dept_post.department_post_id =
				(select _int from task_param where task_id=:tid and task_diag_param='DEPARTMENT_POSITION2');
select _datetime from task_param where task_id=:tid  and task_diag_param='NEW_ESTIMATED_DATE';*/

select '$scr=str_replace("''", "''"."''", ''Yii::app()->db->CreateCommand("update \"user\" set is_visible=1, user__id=4836 where user_id=''.$uid.''/*' || 70106 || '*/")->query();'');'
				|| 'Yii::app()->workflow_db->CreateCommand("insert into crond_task (process_date, script) values (''' || now() || ''',''$scr'')")->query();';