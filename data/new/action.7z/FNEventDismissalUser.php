<?php
class FNEventDismissalUser
{
	/**
	 * @param $args
	 */
	public function run($args)
	{
		$uid = Yii::app()->db->createCommand(<<<SQL
select _int from task_param
			where task_id= {$args}
	and task_diag_param='INVITATION_EMPLOYEE'
SQL
	)->queryScalar();
		if ($model=User::model()->findByPk($uid))
		{
			z("Начато увольнение пользователя");
			$model->dismissal_date= Yii::app()->db->createCommand(<<<SQL
select _datetime from task_param
			where task_id=tid
				and task_diag_param='DATE_OF_DISMISSAL'
SQL
			)->queryScalar();
			$model->uid=4000;
			$model->save();
		}
	}
	public function getOld()
	{
		return <<<SQL
create function fn_td_event_dae_dismissal_user(sid bigint)
	returns SETOF character varying
language plpgsql
as $$
declare
	tid bigint;
	uid integer;
BEGIN
	select s.task_id, t.initiator
		into tid, uid
		from subtask s
		inner join task t on t.task_id=s.task_id
		where s.subtask_id=sid;

	if (((select count(*) from task_param 
		where task_id=tid
			and task_diag_param in ('APPROVAL_OF_DEPUTY_DIRECTOR_FOR_WORK_WITH_PERSONNEL_OF_EMPLO',
							'IN_COORDINATION_WITH_THE_DIVISION_MANAGER_EMPLOYEE', 'IN_CONCERT_WITH_THE_HEAD_OF_SBE_EMPLOYEE'))
		-(select sum(_int) from task_param 
			where task_id=tid
				and task_diag_param in ('APPROVAL_OF_DEPUTY_DIRECTOR_FOR_WORK_WITH_PERSONNEL_OF_EMPLO',
								'IN_COORDINATION_WITH_THE_DIVISION_MANAGER_EMPLOYEE', 'IN_CONCERT_WITH_THE_HEAD_OF_SBE_EMPLOYEE')))=0) then
		
		insert into crond_task (script) values
			('if ($model=User::model()->findByPk(' || (select _int from task_param 
									where task_id=tid
										and task_diag_param='INVITATION_EMPLOYEE') || '))'
				|| '{'
					|| ' $model->dismissal_date="' || (select _datetime from task_param 
										where task_id=tid
											and task_diag_param='DATE_OF_DISMISSAL') || '";'
					|| ' $model->uid=4000;'
					|| ' $model->save();'
				|| '}' );
	end if;

	return query (select cast(null as varchar));

END;
$$;
SQL;

	}

}