<?php
class FNEventCreateDepartmentPost
{
	/**
	 * @param $args
	 */
	public function run($args)
	{
		$uid = Yii::app()->db->createCommand(<<<SQL
select initiator from task where task_id={$args};
SQL
		)->queryScalar();

		$postGroupId = Yii::app()->db->createCommand(<<<SQL
select post_groupe_id from department_post where department_post_id=fn_get_int({$args}, 'DEPARTMENT_POSITION');
SQL
		)->queryScalar();
		z("Начато применение изменений в оргструктуру");
		Yii::app()->db->createCommand(<<<SQL
update groupe_param set vacancy=0 where groupe_id={$postGroupId};
update groupe set is_disabled=1, user__id={$uid} where groupe_id={$postGroupId};
SQL
		)->execute();

	}
	public function removeManagerPost($args)
	{
		$uid = Yii::app()->db->createCommand(<<<SQL
select initiator from task where task_id={$args};
SQL
		)->queryScalar();
		$deptGroupId=Yii::app()->db->createCommand(<<<SQL
select department_groupe_id from department_post where department_post_id=fn_get_int({$args}, 'DEPARTMENT_POSITION');
SQL
		)->queryScalar();
		Yii::app()->db->createCommand(<<<SQL
update groupe_param set vacancy=0 where groupe_id={$deptGroupId};
update groupe set is_disabled=1, user__id= {$uid} where groupe_id={$deptGroupId} or groupe_id=(select fn_get_assistant({$deptGroupId}));
SQL
		)->execute();
SQL;

	}
	public function getOld()
	{
		return <<<SQL
create or replace function fn_td_event_cot_create_department_post(sid bigint)
	returns SETOF character varying
language plpgsql
as $$
declare
	tid bigint;
	uid integer;

	c bigint;
	dgid bigint;
	pgid bigint;
	pid character varying;
	d character varying;
	p character varying;

	ad timestamp without time zone;
	ad_ timestamp without time zone;

	scr character varying[];

	i smallint;
BEGIN
	ad_=null;
	select task_id into tid from subtask where subtask_id=sid;
	select initiator into uid from task where task_id=tid;

	-- Применение изменений в оргструктуру

	select * into c, dgid, pgid, d, p, pid from department_post where department_post_id=fn_get_int(tid, 'DEPARTMENT_POSITION');
	/*
	c = department_post_id,
	dgid = department_groupe_id,
	pgid = post_groupe_id,
	d = department (dev = null)
	p = post (dev = null)
	pid = other_post (dev = null)
	 */
	--department_post_id   in(235,237,238,214,550,1154,1688,1711,1784,1800,1815,1710,)
	--task_id    in(5321,5347,5348,3249,7248,16435,46113,47474,50511,51065,51798,47461)
	d=replace(d, '"', '\"');
	p=replace(p, '"', '\"');
	ad=fn_get_datetime(tid, 'APPLY_DATE');
	c=fn_get_int(tid, 'ADD_VACANCY');

	if ((c>0) or (d is not null)) then
		if (pgid is not null) then -- Увеличить количество ставок на должности
			scr[1]='update groupe_param set vacancy=vacancy + ' || c || ' where groupe_id=' || pgid;
			scr[2]='update groupe set is_disabled=0, user__id=' || uid || ' where groupe_id=' || pgid;
		else
			if (dgid is not null) then -- Подразделение задано, добавляем туда должность и ставки
				-- REMARK - дальше применяется потенциально косячный алгоритм генерации должностей и подразделений связанный с тем, что
				--	сделана ставка на то, что между выполнением команды вставки в таблицу и следующей командой никто не успеет проскочить
				--	принципе все таблицы малонагруженные по операциям вставки, поэтому пока оставим так, если будут косяки, то надо переписывать с изменение скрипта
				--	и открытием транзакции в PHP

				if (d is not null) then -- Задано подразделение в свободном виде, значит создаем новое подразделение
					if ((pid is not null) or (p is not null)) then -- Должность из справочника
						i=1;
						if ((pid is null) and (p is not null)) then -- Должность в свободном виде
							pid=fn_create_uid24(0);
							scr[i]='insert into post (post, name, is_visible) values (''' || pid || ''', ''' || p || ''', 1)';
							i=i+1;
						end if;

						if (c>0) then c=1; -- Руководящих ставок может быть только 1
						else c=0; end if; -- Но у подразделения может не быть руководителя, тогда ставок нет

						scr[i]='insert into groupe (name, is_disabled, groupe_type, user__id, post, is_manager, department_name) values ((select name from post where post=''' || pid || '''), 0, ''KRP'', ' || uid || ', ''' || pid || ''', 1, ''' || d || ''')';
						i=i+1;
						scr[i]='update groupe_param set vacancy=' || cast(c as varchar) || ' where groupe_id=(select groupe_id from groupe order by groupe_id desc limit 1)';
						i=i+1;
						-- Следующая операция более затратная, поэтому делаем последней, чтобы не поиметь проблем с параллельными потоками
						scr[i]='insert into groupe_tree (parent_id, child_id, user__id) values (fn_get_assistant(' || dgid || '), (select groupe_id from groupe order by groupe_id desc limit 1), ' || uid || ')';
						i=i+1;
						scr[i]='insert into groupe (name, is_disabled, groupe_type, user__id, is_manager) values ((select ''Заместитель руководителя '' || name from post where post=''' || pid || '''), 0, ''KRP'', ' || uid || ', 1)';
						i=i+1;
						-- Будем надеятся что еще никто не успел вклиниться
						scr[i]='insert into groupe_tree (parent_id, child_id, user__id) values ((select groupe_id from (select groupe_id from groupe order by groupe_id desc limit 2) as t order by groupe_id limit 1), (select groupe_id from groupe order by groupe_id desc limit 1), ' || uid || ')';
						i=i+1;
					end if;
				else
					if ((pid is not null) or (p is not null)) then -- Должность из справочника
						i=1;
						if ((pid is null) and (p is not null)) then -- Должность в свободном виде
							pid=fn_create_uid24(0);
							scr[i]='insert into post (post, name, is_visible) values (''' || pid || ''', ''' || p || ''', 1)';
							i=i+1;
						end if;

						scr[i]='insert into groupe (name, is_disabled, groupe_type, user__id, post) values ((select name from post where post=''' || pid || '''), 0, ''KRP'', ' || uid || ', ''' || pid || ''')';
						i=i+1;
						scr[i]='update groupe_param set vacancy=' || c || ' where groupe_id=(select groupe_id from groupe order by groupe_id desc limit 1)'; -- Руководящих ставок может быть только 1
						i=i+1;
						-- Следующая операция более затратная, поэтому делаем последней, чтобы не поиметь проблем с параллельными потоками
						scr[i]='insert into groupe_tree (parent_id, child_id, user__id) values (fn_get_assistant(' || dgid || '), (select groupe_id from groupe order by groupe_id desc limit 1), ' || uid || ')';
					end if;
				end if;
			end if;

		-- Остальные варианты в лес, потому что если нет подразделения то непонятно собственно куда в дереве надо прикреплять должность или подразделение
		end if;
	else
		c=fn_get_int(tid, 'MINUS_VACANCY');

		if ((c>0) and (pgid is not null)) then -- Сократить количество ставок на должности в подразделении. Руководящие должности можно только упразднить только вместе с подразделением
			scr[1]='update groupe_param set vacancy=vacancy - ' || c || ' where groupe_id=' || pgid;
		else
			c=fn_get_int(tid, 'REMOVE_VACANCY');

			if (c>0) then
				ad_=ad;
				if (pgid is not null) then -- Упразднить должность
					scr[1]='update groupe_param set vacancy=0 where groupe_id=' || pgid;
					scr[2]='update groupe set is_disabled=1, user__id=' || uid || ' where groupe_id=' || pgid;
				else
					if (dgid is not null) then -- Упразднить руководящую должность и подразделение которым она руководит
						scr[1]='update groupe_param set vacancy=0 where groupe_id=' || dgid;
						scr[2]='update groupe set is_disabled=1, user__id= ' || uid || 'where groupe_id=' || dgid || ' or groupe_id=(select fn_get_assistant(' || dgid || '))';
					end if;
				end if;

			-- Остальные варианты упразднения игнорируем
			end if;
		end if;
	end if;

	if (scr is not null) then
		insert into crond_task (script, process_date) values ('Yii::app()->db->CreateCommand("' || array_to_string(scr, ';" . "') || ';")->query();', ad_);
		raise notice '%', scr;
	end if;

	return query (select cast(null as varchar));

END;
$$;

SQL;

	}
}