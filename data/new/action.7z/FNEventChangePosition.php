<?php
class FNEventChangePosition
{
	/**
	 * @param $args
	 */
	public function run($args)
	{
		z("Начата смена должности" );

		$params = Yii::app()->db->createCommand(<<<SQL
		select (select _int from task_param
		where task_id ={$args}
			  and task_diag_param='UNIT_STAFF') as gid,

		(select cast(_int as integer) from task_param
		where task_id ={$args}
			  and task_diag_param='INVITATION_EMPLOYEE') as uid2,
		(select coalesce(t.shadow_initiator, t.initiator) from task
				where task_id ={$args}) as uid

SQL
		)->queryRow();

		Yii::app()->db->createCommand(<<<SQL
		delete from user_groupe where user_id={$params['uid2']} and groupe_id in (select groupe_id from groupe where groupe_type in (select _fn_get_org_groupe_type()));
		insert into user_groupe (user_id, groupe_id, user__id) values ({$params['uid2']}, {$params['gid']}, {$params['uid']});
SQL
		)->query();


	}
	public static function getOld()
	{
		return /*old function
		 *
		 *
		 ****************/
			<<<SQL

create or replace function fn_td_event_sf_change_position(sid bigint)
	returns SETOF character varying
language plpgsql
as $$
declare
	tid bigint;
	uid integer;

	gid bigint;
	uid2 bigint;

BEGIN
	select s.task_id, coalesce(t.shadow_initiator, t.initiator) into tid, uid from subtask s
		inner join task t on t.task_id=s.task_id
	where s.subtask_id=sid;

	-- Выясняем все ли согласовали
	if ((select count(*)-sum(_int) from task_param
	where task_diag_param in ('APPROVE_ZAM_HEAD_OF_STAFF_TRANSFER_TO_ANOTHER_POSITION', 'IN_CONCERT_WITH_UNIT_MANAGER_TRANSLATION_ANOTHER_POST')
		  and task_id=tid)=0) then

		select _int into gid from task_param
		where task_id=tid
			  and task_diag_param='UNIT_STAFF';

		select cast(_int as integer) into uid2 from task_param
		where task_id=tid
			  and task_diag_param='INVITATION_EMPLOYEE';

		insert into crond_task ("script", process_date)
		values ('Yii::app()->db->createCommand("delete from user_groupe where user_id=' || uid2 || ' and groupe_id in (select groupe_id from groupe where groupe_type in (select _fn_get_org_groupe_type()));
					insert into user_groupe (user_id, groupe_id, user__id) values (' || uid2 ||', ' || gid || ', ' || uid || ')")->query();',
				(select _datetime from task_param
				where task_id=tid
					  and task_diag_param='DATE_TRANSFER_TO_ANOTHER_POSITION'));
	end if;

	return query (select cast(null as varchar));

END;
$$;
ALTER FUNCTION fn_td_event_sf_change_position(bigint)
  OWNER TO postgres;
GRANT EXECUTE ON FUNCTION fn_td_event_sf_change_position(bigint) TO postgres;
GRANT EXECUTE ON FUNCTION fn_td_event_sf_change_position(bigint) TO public;
SQL;
	}

}