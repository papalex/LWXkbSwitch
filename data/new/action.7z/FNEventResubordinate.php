<?php
class FNEventResubordinate
{
	public function run($args)
	{
		$params = Yii::app()->db->createCommand(<<<SQL
		select (select _int from task_param
		where task_id ={$args}
			  and task_diag_param='UNIT_STAFF') as gid,

		(select cast(_int as integer) from task_param
		where task_id ={$args}
			  and task_diag_param='STAFF_LIST_POSITION_NEW') as ngid,
			  
		(select coalesce(t.shadow_initiator, t.initiator) from task
				where task_id ={$args}) as uid

SQL
		)->queryRow();
		$ogid = Yii::app()->db->createCommand(<<<SQL
		select fn_get_department_for_role({$params['gid']}) as t;
SQL
		)->queryScalar();

		Yii::app()->db->createCommand(<<<SQL
		update groupe_tree set parent_id=(select fn_get_assistant({$params['ngid']})), user__id={$params['uid']}
				where parent_id={$ogid}
					and child_id={$params['gid']}
SQL
		)->query();
	}
	public function getOld()
	{
		return
			<<<SQL
create function fn_td_event_sf_resubordinate(sid bigint)
	returns SETOF character varying
language plpgsql
as $$
declare
	tid bigint;
	uid integer;

	ogid integer;
	ngid integer;
	gid integer;

	script varchar;

BEGIN
	select s.task_id, coalesce(t.shadow_initiator, t.initiator) into tid, uid from subtask s
		inner join task t on t.task_id=s.task_id
	where s.subtask_id=sid;

	-- Выясняем все ли согласовали
	if ((select count(*)-sum(_int) from task_param
	where task_diag_param in ('IS_IN_CONCERT_WITH_THE_DEPUTY_DIRECTOR_ON_WORK_WITH_PERSONNEL', 'IS_IN_CONCERT_WITH_UNIT_MANAGER')
		  and task_id=tid)=0) then

		select _int into ngid from task_param
		where task_id=tid
			  and task_diag_param='STAFF_LIST_POSITION_NEW';
		select _int into gid from task_param
		where task_id=tid
			  and task_diag_param='UNIT_STAFF';

		select t into ogid from fn_get_department_for_role(gid) as t;

		insert into crond_task ("script", process_date)
		values ('Yii::app()->db->createCommand("update groupe_tree set parent_id=(select fn_get_assistant(' || ngid || ')), user__id=' || uid
				|| ' where parent_id=' || ogid
				|| ' and child_id=' || gid || '")->query();', (select _datetime from task_param
		where task_id=tid
			  and task_diag_param='APPLY_DATE_SUBORDINATION_POSITIONS'));
	end if;

	return query (select cast(null as varchar));

END;
$$;
SQL;
	}
}