<?php
class FNEventCreatePosition
{
	/**
	 * @param $args
	 */
	public function run($args)
	{
		z("Начато создание должности");

		$subtask = Yii::app()->db->createCommand(<<<SQL
select s.task_id, coalesce(t.shadow_initiator, t.initiator) into tid, uid from subtask s
		inner join task t on t.task_id=s.task_id
	where s.subtask_id={$args};
SQL
	)->queryScalar();

		$taskId= $subtask['tid'];

		$pname = Yii::app()->db->createCommand(<<<SQL
select _varchar from task_param
		where task_id={$taskId}
	and task_diag_param='STAFF_LIST_POSITION_NEW';
SQL
		)->queryScalar();

		$uid=$subtask['uid'];


		// Проверяем есть ли такая должность в справочнике
		$puid = Yii::app()->db->createCommand(<<<SQL
select post from post
		where name='{$pname}';
SQL
		)->queryScalar();
		if (is_null($puid))
		{
			$puid=Yii::app()->db->createCommand("insert into post (name, is_visible) values ('{$pname}', 1) returning post")->queryScalar();
		}

		//Создаем должность

		$parentGroupe=Yii::app()->db->createCommand(<<<SQL
select groupe_type, tp._int as pgid from groupe
		where groupe_id=(select _int from task_param tp
		where task_id={$taskId}
	and task_diag_param='STAFF_LIST_POSITION');
SQL
		)->queryRow();
		$gid=Yii::app()->db->createCommand(<<<SQL
insert into groupe (name, post, is_disabled, groupe_type, user__id)
			values ('{$pname}', '{$puid}', 0, '{$parentGroupe['groupe_type']}', {$uid}) returning groupe_id
SQL
			 )->queryScalar();

		//Настраиваем доппараметры должности
		$staffParams =Yii::app()->db->createCommand(<<<SQL
			select (select _int from task_param
		where task_id={$taskId}
	and task_diag_param='STAFF_CHANGE_SALARY_MIN') as smin, 
		(select _int from task_param
		where task_id={$taskId}
	and task_diag_param='STAFF_CHANGE_SALARY_MAX') as smax,
		(select _int from task_param
		where task_id={$taskId}
	and task_diag_param='STAFF_LIST_STAFFING') as v;
SQL
		)->queryRow();
		if (Yii::app()->db->createCommand("select count(*) from groupe_param where groupe_id={$gid}")->queryScalar())
			Yii::app()->db->createCommand(<<<SQL
update groupe_param set min_salary={$staffParams['smin']}, 
		max_salary={$staffParams['smax']}, 
		vacancy={$staffParams['v']}, 
		user__id={$uid} 
	where groupe_id={$gid}
SQL
				)->query();
		else
			Yii::app()->db->createCommand(<<<SQL
insert into groupe_param set (min_salary, max_salary, vacancy, user__id, groupe_id) values 
	({$staffParams['smin']}, {$staffParams['smax']}, {$staffParams['v']}, {$uid}, {$gid})
SQL
				)->query();

		// Подчиняем должность
		Yii::app()->db->createCommand(<<<SQL
insert into groupe_tree (parent_id, child_id, user__id) values ((select fn_get_assistant( {$parentGroupe['pgid']} )) , {$gid}, {$uid});
SQL
		)->query();

	}
	public function getOld()
	{
		return
		<<<'SQL'
		create function fn_td_event_sf_create_position(sid bigint)
	returns SETOF character varying
language plpgsql
as $$
declare
	tid bigint;
	uid integer;

	pname varchar(127);
	puid varchar(24);
	pgt varchar(64);
	pgid integer;
	smin integer;
	smax integer;
	v integer;

	script varchar;

BEGIN
	select s.task_id, coalesce(t.shadow_initiator, t.initiator) into tid, uid from subtask s
		inner join task t on t.task_id=s.task_id
		where s.subtask_id=sid;

	-- Выясняем все ли согласовали
	if ((select count(*)-sum(_int) from task_param
		where task_diag_param in ('IS_STAFF_CHANGE_SALARY_APROVE_ZAM', 'IS_STAFF_CHANGE_SALARY_APROVE_HEAD', 'IS_STAFF_CHANGE_SALARY_APROVE_HEAD_SBE')
			and task_id=tid)=0) then

		select _varchar into pname from task_param
			where task_id=tid
				and task_diag_param='STAFF_LIST_POSITION_NEW';

		script='$uid=' || uid || '; $pname="' || pname ||'";';
		
		-- Проверяем есть ли такая должность в справочнике
		select post into puid from post 
			where name=pname;
		if (puid is null) then
			script=script || '$puid=Yii::app()->db->createCommand("insert into post (name, is_visible) values (''{$pname}'', 1) returning post")->queryScalar();';
		else
			script=script || '$puid="' || puid || '";';
		end if;

		-- Создаем должность
		select _int into pgid from task_param
			where task_id=tid
				and task_diag_param='STAFF_LIST_POSITION';
		script=script || '$pgid=' || pgid || ';';
		select groupe_type into pgt from groupe
			where groupe_id=pgid;

		script=script || '$gid=Yii::app()->db->createCommand("insert into groupe (name, post, is_disabled, groupe_type, user__id)'
									|| ' values (''{$pname}'', ''{$puid}'', 0, ''' || pgt || ''', {$uid}) returning groupe_id")->queryScalar();';

		-- Настраиваем доппараметры должности
		select _int into smin from task_param
			where task_id=tid
				and task_diag_param='STAFF_CHANGE_SALARY_MIN';
		select _int into smax from task_param
			where task_id=tid
				and task_diag_param='STAFF_CHANGE_SALARY_MAX';
		select _int into v from task_param
			where task_id=tid
				and task_diag_param='STAFF_LIST_STAFFING';

		script=script 
			|| ' if (Yii::app()->db->createCommand("select count(*) from groupe_param where groupe_id={$gid}")->queryScalar())'
				|| ' Yii::app()->db->createCommand("update groupe_param set min_salary=' || smin ||', max_salary=' || smax ||', vacancy=' || v || ', user__id={$uid} where groupe_id={$gid}")->query();'
				|| ' else Yii::app()->db->createCommand("insert into groupe_param set (min_salary, max_salary, vacancy, user__id, groupe_id) values (' || smin ||', ' || smax ||', ' || v || ', {$uid}, {$gid})")->query();';
		
		-- Подчиняем должность
		script=script || 'Yii::app()->db->createCommand("insert into groupe_tree (parent_id, child_id, user__id) values ((select fn_get_assistant({$pgid})), {$gid}, {$uid});")->query();';

		insert into crond_task ("script", process_date) 
			values (script, (select _datetime from task_param
						where task_id=tid
							and task_diag_param='APPLY_DATE'));
	end if;

	return query (select cast(null as varchar));

END;
$$;
SQL;
	}

}