<?php
class FNEventDisabledPosition
{


	public function run($args)
	{
		z("Отключение позиции");

		if (Yii::app()->db->createCommand(<<<SQL
			(select (count(*)-sum(_int))=0 from task_param
	where task_diag_param in ('IS_STAFF_CHANGE_SALARY_APROVE_HEAD_SBE', 'IS_STAFF_CHANGE_SALARY_APROVE_ZAM', 'IS_APPROVAL_OF_THE_HEAD')
	and task_id=$args)
SQL
		)->queryScalar())
		{

			$params = Yii::app()->db->createCommand(<<<SQL
select tp._int as gid,coalesce(t.shadow_initiator, t.initiator) as uid from task_param tp
	join task t on tp.task_id = t.task_id
		where tp.task_id=$args
	and task_diag_param='UNIT_STAFF';
SQL
			)->queryRow();
			Yii::app()->db->createCommand(<<<SQL
update groupe set is_disabled=1, user__id={$params['uid']} 
	where gt.parent_id={$params['gid']};
SQL
			)->query();
		}
	}
	public function runITR($args)
	{
		z("Отключение позиции ITR");

		if (Yii::app()->db->createCommand(<<<SQL
			(select (count(*)-sum(_int))=0 from task_param
	where task_diag_param in ('COORDINATED_DEPUTY_ZAM_DIR_HR_REDUCTION_POSTS_ITR')
	and task_id=$args)
SQL
		)->queryScalar())
		{

			$params = Yii::app()->db->createCommand(<<<SQL
select tp._int as gid,coalesce(t.shadow_initiator, t.initiator) as uid from task_param tp
	join task t on tp.task_id = t.task_id
		where tp.task_id=$args
	and task_diag_param='UNIT_STAFF_ITR_NEW';
SQL
			)->queryRow();
			Yii::app()->db->createCommand(<<<SQL
update groupe set is_disabled=1, user__id={$params['uid']} where gt.parent_id={$params['gid']};
SQL
			)->query();
		}
	}
	public function getOld()
	{
		return
		<<<SQL
create function fn_td_event_sf_disabled_position(sid bigint)
	returns SETOF character varying
language plpgsql
as $$
declare
	tid bigint;
	uid integer;

	gid integer;

BEGIN
	select s.task_id, coalesce(t.shadow_initiator, t.initiator) into tid, uid from subtask s
		inner join task t on t.task_id=s.task_id
		where s.subtask_id=sid;

	-- Выясняем все ли согласовали
	if ((select count(*)-sum(_int) from task_param
		where task_diag_param in ('IS_STAFF_CHANGE_SALARY_APROVE_HEAD_SBE', 'IS_STAFF_CHANGE_SALARY_APROVE_ZAM', 'IS_APPROVAL_OF_THE_HEAD')
			and task_id=tid)=0) then

		select _int into gid from task_param
			where task_id=tid
				and task_diag_param='UNIT_STAFF';

		insert into crond_task ("script", process_date) 
			values ('Yii::app()->db->createCommand("update groupe set is_disabled=1, user__id=' || uid || ' where groupe_id=' || gid || '")->query();', (select _datetime from task_param
						where task_id=tid
							and task_diag_param='APPLY_DATE'));
	end if;

	return query (select cast(null as varchar));

END;
$$;

------------fn_td_event_sf_disabled_position_itr-------------
create function fn_td_event_sf_disabled_position_itr(sid bigint)
	returns SETOF character varying
language plpgsql
as $$
declare
	tid bigint;
	uid integer;

	gid integer;

BEGIN
	select s.task_id, coalesce(t.shadow_initiator, t.initiator) into tid, uid from subtask s
		inner join task t on t.task_id=s.task_id
		where s.subtask_id=sid;

	-- Выясняем все ли согласовали
	if ((select count(*)-sum(_int) from task_param
		where task_diag_param in ('COORDINATED_DEPUTY_ZAM_DIR_HR_REDUCTION_POSTS_ITR')
			and task_id=tid)=0) then

		select _int into gid from task_param
			where task_id=tid
				and task_diag_param='UNIT_STAFF_ITR_NEW';

		insert into crond_task ("script", process_date) 
			values ('Yii::app()->db->createCommand("update groupe set is_disabled=1, user__id=' || uid || ' where groupe_id=' || gid || '")->query();', (select _datetime from task_param
						where task_id=tid
							and task_diag_param='APPLY_DATE_ITR'));
	end if;

	return query (select cast(null as varchar));

END;
$$;
SQL;

	}
}