<?php

namespace app\controllers;

use app\core\actions\AdminAction;
use app\core\actions\CreateAction;
use app\core\actions\DeleteAction;
use app\core\actions\UpdateStdAction;
use app\core\actions\UpdateAction;
use app\core\HttpException2;
use app\core\View2;
use Yii;
use app\core\Controller2;
use app\models\Help;
use yii\base\View;

class HelpController extends Controller2
// Базовый контроллер для модуля Переговорная
{
	public $activeActions = ['admin',]; // Активные стандартные действия
	public $modelClass = 'Help';

	public static function createHelpURL()
		// Форимирует URL для вызова помощи для текущего контроллера и действия
	{
		return '/help/view/help/' . Help::createCurrentPKey();
	}

	public function actions()
	{
		$actions = parent::actions();
		$defaultReturnURL = '/help/admin';
		$userReturnURL = '/help/update/id';
		$ro = !Yii::$app->user->can('admin');
		$actions['admin'] = ['class' => 'app\core\actions\AdminAction',
			'params' => ['ro' => $ro]];
		$actions['create'] = ['class' => CreateAction::class,
			'modelClass' => 'Help',
			'params' => ['ro' => $ro]];
		/*$actions['update'] = ['class' => UpdateAction::class,
			'modelClass' => 'Help',
			'params' => ['ro' => $ro]];*/
		$actions['delete'] = ['class' => DeleteAction::class,
			'modelClass' => 'Help',
			'params' => ['ro' => $ro]];
		return $actions;
	}

	public function actionUpdate($controller = '')
	{
		$url = Yii::$app->urlManager->createUrl(['help/update', 'id' => 'Quick_accessController | actionProcess/id/CRMT_ACCESS_ADD']);
		/*?><a href="<?=$url?>">cc</a><?php
				xdd([htmlentities($url),$_GET]);*/
		$r = $_GET['r'];
		$id = substr($r, strpos($r, 'help/update') + 12);

		$model = Help::findOne($id);
		if (empty($model))
			throw new HttpException2(404, 'Не найдено', __LINE__);
		$name = $this->modelClass;

		if (isset($_POST[$name]))
		{
			AdminController::checkBoxRestore($this->checkBoxField, $this->model_name);
			$model->attributes = $_POST[$name];

			if ($model->save())
			{
				if (!empty($controller)) $this->SaveLog(__CLASS__, 'actionUpdate', $model->attributes);

				$t = Yii::app()->getRequest()->getParam(_Input::$SaveOK);
				if (empty($t)) $this->redirect(_URL::DefaultReditect());
			}
		}

		//$this->tool_bar['create'] = array('label' => 'Создать', 'image' => _Icon32::Create, 'url' => '/help/create',);

		/*if ($model->is_public == 0)
			$this->tool_bar['user_access'] = array('label' => 'Доступ к статье', 'url' => array('add', 'id' => $model->help), 'image' => _Icon32::Users);

		Yii::app()->clientScript->registerScript('help_preview', "
            $('#help_preview').click(function(){
            window.open('" . _URL::URLCreate(array('view', 'help' => $model->help), 'help') . "','helpwin','top=50, left=100, menubar=0, toolbar=0, location=0, directories=0, status=0, scrollbars=1, resizable=1, width=800, height=600') 
	    });");

		$this->tool_bar[] = array('label' => 'Предпросмотр (сохраните)', 'image' => _Icon32::Preview, 'imageOptions' => array('id' => 'help_preview'),);

		$this->tbUIBtn(__CLASS__, 'actionUpdate');
*/
		// Если ничего не пришло показать форму из шаблона
		return $this->render('form', ['model' => $model]);
	}
	public function actionView($help)
	{
		//ExaminationController|admin
		//http://10.101.3.97/myosotis/help/view/help/Asterisk_groupe_turnController|admin
		//xdd($help);
		$model = Help::findOne($help) ;

		$this->layout = '../help/help';

		if (empty($model) or ($model->is_public==0 // Статья не публичная, проверяем права
			&& Yii::$app->db->CreateCommand(<<<SQL

select count(*) from help_groupe hg
		inner join user_groupe_cache ug on ug.groupe_id=hg.groupe_id
					and ug.user_id={$this->uid}
	where help='{$model->help}'
SQL
		)->queryScalar()==0))
			throw new HttpException2(404,'По запросу ничего не найдено.',__LINE__);

		return $this->render('view', ['model' => $model]);
	}
	public function actionAc_video($term)
	{

		$que = <<< SQL
select d.document_id as "value", d.name as "text" from document d
	
	where d.name ilike '%{$term}%'
order by d.name
SQL;
		$result = Yii::$app->db->CreateCommand($que)->queryAll();

		$res = [];
		foreach ($result as $v) $res[] = ['label' => $v['text'], 'value' => $v['value']];
		echo json_encode($res);
		die();
	}

	public function actionAc_xml($id)
	{
		$tracks = [];
		if ($file = Yii::$app->db->createCommand(<<<SQL
select link from file2 where document_id = {$id} and link ilike '%.xml'
SQL
		)->queryScalar())
		{

			$file = '/srv/www/uploads/document/' . $file;
			if (is_file($file))
			{
				/**
				 * @var $readerin \XMLReader
				 */
				$reader = new \XMLReader();
				$reader->open($file);
				while ($reader->read())
				{
					if ($reader->nodeType === \XMLReader::ELEMENT && $reader->hasAttributes
						&& $reader->getAttribute('xmpDM:trackType') == 'TableOfContents')
					{
						$readerin = new \XMLReader();
						$readerin->XML($reader->readInnerXML());
						while ($readerin->read())
						{
							if ($readerin->nodeType === \XMLReader::ELEMENT && $readerin->localName === 'Description' && $readerin->hasAttributes)
							{
								$time = $readerin->getAttribute('xmpDM:startTime');
								$tracks[] = ['label' => "{$readerin->getAttribute('xmpDM:name') } : $time", 'value' => $time];
							}
						}
					}
				}
			}
		}
		echo json_encode($tracks);
		die();
	}
}