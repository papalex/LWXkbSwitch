<?php
namespace app\core\gui;

use \app\core\gui\Page;
use \app\core\gui\_Icon32;
use \app\models\Help;
$admin = true;
/**
 * @var $model \app\models\Help
 * @var $btn \app\core\gui\IEButton
 * @var $iForm \app\core\gui\ITable
 * @var $tmp \app\core\gui\ITable
 */
$view = new Page();
$view->addItem(new Title())->label='Компания - ' . $model->name;

$tb=$view->addItem(new IconToolBar(), [], $view->iconToolBar);
$tb->addItem(new IconToolBarItem(), ['label' => 'Новая', 'image' => _Icon32::Create, 'url' => $this->createURL('/krp_company/create'),]);
$view->addBackBtn(['url' => $this->createURL('krp_company/admin'),]);
$tab = $view->addItem(new Tab(), ['id' => 'tab',], 'tab');
$base =  $tab->addItem(new TabItem(), ['label' => 'Настройки', 'id' => 'krp_company',], 'krp_company');

$table = new ITable();
$table->model = $model;
//$table->isReadonly =!$admin;
$iForm=$base->addItem($table);

/*$this->render('/core/_list_groupe', ['view' => $tab->addItem(new TabItem(), ['label' => 'Должности к договорам', 'id' => 'groupe',],'groupe'),
	'model' => $model, 'mode' => '_', 'title' => 'Должности имеющие доступ к договорам', 'ro' => false,]);
$this->render('/core/_list_effective', ['view' => $tab->items['user_effective'], 'model' => $model]);*/

$iForm->addItem(new IEEdit(), ['name' => 'help'/*,'isReadonly' => $ro*/,'isRequired' => true]);
$iForm->addItem(new IEEdit(), ['name' => 'name'/*,'isReadonly' => $ro*/,'isRequired' => true]);
$iForm->addItem(new IEHTMLText(), ['name' => 'cnt', 'value' => $model->cnt/*,'isReadonly' => $ro*/]);

$iForm->addItem(new IESpinner(), ['name' => 'sort', 'min' => 0, 'max' => 100000, 'isOverflow' => true/*, 'isReadonly' => $ro*/]);
$iForm->addItem(new IESpinner(), ['name' => 'is_visible', 'min' => 0, 'max' => 100000, 'isOverflow' => true/*, 'isReadonly' => $ro*/]);
$iForm->addItem(new IESpinner(), ['name' => 'is_public', 'min' => 0, 'max' => 100000, 'isOverflow' => true/*, 'isReadonly' => $ro*/]);
$iForm->addItem(new IEAjax(),['name'=>'videolesson','autocompleteURL' => $this->createURL('/help/ac_video'), 'isOverflow' => true ,
	'templateJS'=><<<JS
jQuery('#%%idInput%%_autocomplete').autocomplete(
    {'showAnim':'slideDown',
        'minLength':%%ajaxMinLength%%,
        'select': function(event, ui)
                    {
                        this.value=ui.item.label;
                        $("#%%idInput%%").val(ui.item.value);
                        return false;
                    },
        'focus': function() { return false; },
        'keyup': function(event, ui)
                {
                    this.value=ui.item.label;
                    $("#%%idInput%%").val(ui.item.value);
                    return false;
                },
        'source':function(request, response)
                {
                    $.getJSON("%%autocompleteURL%%", {term: request.term.split(/,s*/).pop()}, response);
                }
    });

JS

	]);
$iForm->addItem(new IEAjax(),['name'=>'videolessontime','autocompleteURL' => $this->createURL('help/ac_xml/id/74593'), 'isOverflow' => true ]);

/*$iForm->addItem(new IESelect(), ['name' => 'register_contract_office_id',
	'sql' => <<< SQL
	select  o.office_id as pkey, g.name from office o join groupe g on o.groupe_id = g.groupe_id where office_type = 'OFFICE_TYPE|REGISTER'
	order by o.groupe_id
SQL
	,'varType'=>'char',
	'isRequired' => true,]);
*/
$iForm->addItem('IEMessage', [], 'bl');
$iForm->items['bl']->breakLine();

$iForm->addItem('IEButton', [], 'btn');
$btn=$iForm->items['btn'];
if ($model->isNewRecord)
	$u=['url' => $this->createURL('help/create')];
else
	$u=['url' => $this->createURL('help/update/id/'.$model->getPkey())];
if ($admin)
{
	$btn->addSaveBtn($u);
	$btn->addOKBtn($u);
}
$btn->addListBtn(['url' => '/help/admin']);//$this->createURL('krp_company/admin')]);

$view->out();