<?php $this->beginPage() ?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="en" lang="<?= Yii::$app->language ?>">
<head>
	<meta charset="<?= Yii::$app->charset ?>">
	<title>Русский проект - Незабудка</title>
	<?php //<meta http-equiv="Content-Type" content="text/html; charset=utf-8" /> ?>
	<meta name="language" content="ru" />

	<link rel="stylesheet" type="text/css" href="/dsn/css/screen.css" />
	<link rel="stylesheet" type="text/css" href="/dsn/css/main.css" />
	<link rel="stylesheet" type="text/css" href="/dsn/css/general.css" />
	<link rel="stylesheet" type="text/css" href="/dsn/css/datetime/anytime.css" />
	<link rel="shortcut icon" href="/dsn/ico/32/myosotis.png"/>
</head>
<body>
<?php $this->beginBody();?>
<table class="gen_content">

	<tr>
<td width="100%"><?=$content?></td>

	</tr>
	<tr><td class="gen_footer" colspan="<?=2+2?>">Copyright &copy; 2011-<?=date('Y', time())?> «Русский проект».</td></tr>
</table>
<img src="/dsn/img/e.png" height="40px">
<?php // Нижний информационный ToolBar ?>
<div style="position: fixed; left: 0; bottom: 0; width: 100%; height: 40px; background: #4a9eda; color: #fff; z-index:1000000">
	<table style="width:100%"><tr><td style="text-align: left; height:32px; vertical-align: middle;"></td>
			<td style="text-align: right; vertical-align: middle;"><?= Yii::$app->user->getIdentity()->f_ms?></td>
		</tr></table></div>
<?php $this->endBody(); ?>
</body>
</html>