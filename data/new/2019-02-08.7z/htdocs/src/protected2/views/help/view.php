<h1><?=$model->name?></h1>
<?=$model->cnt;?>