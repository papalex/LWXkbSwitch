<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="en" lang="en">
<head>
	<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
	<meta name="language" content="ru" />
        <link rel="stylesheet" type="text/css" href="/dsn/css/screen.css" media="screen, projection" />
	<link rel="stylesheet" type="text/css" href="/dsn/css/print.css" media="print" />
	<!--[if lt IE 8]>
	<link rel="stylesheet" type="text/css" href="/dsn/css/ie.css" media="screen, projection" />
	<![endif]-->
	<link rel="stylesheet" type="text/css" href="/dsn/css/main.css" />
	<link rel="stylesheet" type="text/css" href="/dsn/css/form.css" />
	<link rel="stylesheet" type="text/css" href="/dsn/css/general.css" />
	
	<title><?=CHtml::encode($this->pageTitle); ?></title>
</head>
<body>
<table class="gen_tbl">
    <tr><td rowspan="3" class="gen_lrc"></td>
        <td colspan="2"><table><tr><td><img src="/dsn/img/logo.png" alt="Русский проект" title="Русский проект"></td>
        <td class="gen_user">Пользователь: <span><?
	if (Yii::app()->user->isGuest) z('ГОСТЬ!!!');
    else
    {
        $login=Yii::app()->user->name;
        $userLogin=Yii::app()->db->CreateCommand("select f_ms from \"user\" where login='{$login}'")->queryScalar();
        z($userLogin);
    }?><span></td></tr></table></td>
	<td rowspan="3" class="gen_lrc"></td></tr>
    <tr><td class="gen_content"><h1><?=CHtml::encode($this->page_name); ?></h1>
				<?=$content?></td></tr>
    <tr><td colspan="2" class="gen_footer">Copyright &copy; 2011-2012 «Русский проект».<br/>
    Все права защищены.</td></tr>
</table>
</body>
</html>