<?
	$tbl = new _OutTable();
	
	$tbl->query = 'select help, name, sort, is_visible from help';
	$tbl->queryCount = "select count(*) as cnt from help";
	
	$tbl->isClickable = '/help/update';
	$tbl->pkey = array('id' => 'help');
	$tbl->model = 'Help';
	$tbl->curSort='name';
    $tbl->curDirect='up';
	
/*	$t=$tbl->acts['Delete'];
	$tbl->acts=array();
	$tbl->acts['View']=array(array('evalVisibleBtn' => '$visibleBtn=true;', 'image' => _Icon16::View, // Поменять иконку на +
										'hint' => 'Посмотреть', 'url' => '/internet_traffic/plus100', 'confirm' => false,),);
	$tbl->acts['Delete']=$t;*/
	$tbl->acts['Delete']['url'] = '/help/delete';
	
	
//	window.open('"._URL::URLCreate(array('view', 'help' => $model->help), 'help')."','helpwin','top=50, left=100, menubar=0, toolbar=0, location=0, directories=0, status=0, scrollbars=1, resizable=1, width=800, height=600')
	
	$tbl->cols['help']=array('headFromModel' => true, 'name' => 'help', 'filter' => array('type' => 'edit', 'isLike' => 'in', 'isCaseSence' => false, 'name' => 'help'),
								'htmlOptions' => array('width' => '10%',),);
	$tbl->cols['name'] = array('headFromModel' => true, 'autoAlign' => false, 'filter' => array('type' => 'edit', 'isLike' => 'in', 'isCaseSence' => false, 'name' => 'name',),);
	$tbl->cols['sort'] = array('headFromModel' => true, 'filter' => array('type' => 'edit', 'isLike' => 'in', 'isCaseSence' => false, 'name' => 'sort',),
								'htmlOptions' => array('width' => '5%',),);
	$tbl->cols['is_visible'] = array('headFromModel' => true, 'dataType' => 'bool',
										'filter' => array('type' => 'bool', 'autoSubmit' => true, 'name' => 'is_visible',),);

	$tbl->out();
?>