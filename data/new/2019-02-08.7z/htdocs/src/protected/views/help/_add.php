<div class="form">
<?  
    _InputTable::Start();
	_InputTable::Error($model);

    _InputTable::AJAXText('groupe_id', $model, array('required' =>true, 
                                                        'ajax' => array('minLength' => 3, 'dictonary' => true, 
                                                                        'value' => array('model' => 'Groupe', 'human_name' => 'name'),
                                                                        'url' => '/help/ac_groupe',),));
    _InputTable::Hidden('help', $model);
    _InputTable::OtherError($model);
    _InputTable::Separator();
    _InputTable::Line1(_InputTable::SaveOKBtn($model, array('disabledSave' => true, 'iu_url' => "help/add/id", 
                                                            'back_url' => "/help/update/id/{$model->help}")), array('style' => 'text-align:center;'));

    _InputTable::End();
?>
</div>