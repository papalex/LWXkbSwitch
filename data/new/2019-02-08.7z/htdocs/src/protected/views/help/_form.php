<div class="form">
<?  
    AdminController::$checkChangeData=true;

	_jQuery_UI::$setTabsNumber=true;
	
    ob_start();
    _InputTable::Start();
	_InputTable::Error($model);
    
    _InputTable::Text('help', $model, array('required' => true,));
    _InputTable::Text('name', $model, array('required' => true,));
	_InputTable::HtmlEditor('cnt', $model, array('hideHidden' =>true, ));
	_InputTable::Text('sort', $model);
	_InputTable::checkBox('is_visible', $model);
	_InputTable::checkBox('is_public', $model);
	
	if ($model->help)
	{
		_InputTable::Separator();
		_InputTable::Message(null, array('Прямая ссылка' => "/help/view/help/{$model->help}"), null, true);
	}
    
    _InputTable::Separator();
    _InputTable::OtherError($model);
	
    _InputTable::Line1(_InputTable::SaveOKBtn($model), array('style' => 'text-align:center;'));
    
    _InputTable::End();
	
	$tabs['Статья']=ob_get_contents();
    ob_end_clean();
	
	if ($model->help)
	{
		ob_start();
        $this->renderPartial('_list', array('model' => $model,));
        $tabs['Права']=ob_get_contents();
        ob_end_clean();
	}
	
	_jQuery_UI::$tabs=$tabs;
    
    _jQuery_UI::Tabs();
?>
</div>