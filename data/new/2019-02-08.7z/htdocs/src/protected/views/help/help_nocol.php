<?php 
    $this->pageTitle=(!empty($this->page_name) ? $this->page_name.' - ' : '').Yii::app()->name;
    $this->beginContent('//help/help'); ?>
	<div id="content">
		<?= $content; ?>
	</div>
<?php $this->endContent(); ?>