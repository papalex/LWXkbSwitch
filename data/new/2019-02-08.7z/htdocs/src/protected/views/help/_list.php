</br><b>Группы которым надо показать:</b>
<?
    $tbl=new _OutTable();
    
    $tbl->db=Yii::app()->db;
    $tbl->isClickable=false;
    $tbl->isSelectable=false;
    $tbl->model="Help_groupe";
    $tbl->pkey=array('id' => "help_groupe_id");
    $tbl->curSort='g.name';
    $tbl->curDirect='up';

    $tbl->action['Insert']=array('url' => "/help/add/id/{$model->help}", 'icon' => _Icon32::Create, 'hint' => 'Добавить группу');

    $tbl->query="select hg.help_groupe_id, g.name, (select name from groupe where groupe_id=fn_get_department_for_role(cast(hg.groupe_id as integer))) as dept,"
						." gt.name as groupe_type from help_groupe hg"
					." inner join groupe g on g.groupe_id=hg.groupe_id"
					." inner join groupe_type gt on gt.groupe_type=g.groupe_type"
                    ." where hg.help='{$model->help}'";

    $tbl->queryCount="select count(*) as cnt from help_groupe hg"
                        ." where hg.help='{$model->help}'";

// $tbl->debugQuery=true;
//$tbl->debugQueryCount=true;

	$tbl->cols['name']=array('head' => 'Группа', 'autoAlign' => true,
							'filter' => array('type' => 'edit', 'isLike' => 'in', 'isCaseSence' => false, 'name' => 'g.name',),
                            'htmlOptions' => array('width' => '45%'));
	$tbl->cols['dept']=array('head' => 'Подразделение', 'autoAlign' => true,
							'filter' => array('type' => 'edit', 'isLike' => 'in', 'isCaseSence' => false, 'name' => 'dept',),
                            'htmlOptions' => array('width' => '50%'));
	$tbl->cols['groupe_type']=array('head' => 'СБЕ', 'autoAlign' => true,
							'filter' => array('type' => 'edit', 'isLike' => 'in', 'isCaseSence' => false, 'name' => 'gt.name',),
                            'htmlOptions' => array('width' => '5%'));
    $tbl->acts['Delete']['url']="/help/remove";

    $tbl->Out();
	
    _InputTable::Start();
    _InputTable::Line1(_InputTable::SaveOKBtn($model, array('disabledSave' => true, 'disabledOK' => true, 'list_name' => 'Список',
                                                            'backname' => "backHistory",)), array('style' => 'text-align:center;'));

    _InputTable::End(false);    
?>