<?php

/*
 * Контроллер для работы с таблицей Content
 */

class HelpController extends AdminController
{

	public $model_name = 'Help';
	public $admin_name = 'Список страниц помощи';
	public $create_name = 'Создание страницы помощи';
	public $update_name = 'Редактирование страницы помощи';

	public $checkBoxField=array('is_public', 'is_visible');
	
	public function __construct($id, $module = null)
	{
		parent::__construct($id, $module);
		$this->icon_top_menu['Help']['active'] = true;
	}

	public function accessRules() // Настройка прав доступа к методам контроллера
	{
		
		return array(array('allow', 'actions' => array('admin', 'create', 'update', 'delete', 'add', 'remove', 'ac_groupe',),
							'roles' => array('help_editor',),),
						array('allow', 'actions' => array('view',), 'users' => array('@',)),
						array('deny', 'users' => array('*',),),
			);
	}

	public function actionAdmin($controller = '')
	{
		$this->tool_bar = array(ToolBar::tbCreateBtn($this->model_name),
			ToolBar::tbMassDeleteBtn($this->model_name),);
		parent::actionAdmin(__CLASS__);
	}

	public function actionView($help)
	// Выводит пункт меню помощи
	{
		$model = $this->loadModel($help, false);

		$this->layout = '//help/help_nocol';
		$this->page_name = $model->name;

		if (($model->is_public==0) //  Статья не публичная, проверяем права
				&& (Yii::app()->db->CreateCommand("select count(*) from help_groupe hg"
														." inner join user_groupe_cache ug on ug.groupe_id=hg.groupe_id"
																							." and ug.user_id={$this->uid}"
														." where help='{$model->help}'")->queryScalar()==0))
			throw new CHttpException(404,'По запросу ничего не найдено.');

		$this->render('view', array('model' => $model,));
	}

	public function loadModel($id, $is_pk_int = true) // Загрузка модели и выборка набора данных
	{
        if (strpos($_SERVER['REQUEST_URI'], '/id/', 17))
            $id=str_replace('%20', ' ', substr($_SERVER['REQUEST_URI'], 16, 1000));

        return $this->loadModelDefault($id==='Quick_accessController | actionProcess' ? mbereg_replace('/activeTab/1', '', mbereg_replace('/help/add/id/', '', mbereg_replace('/help/view/help/', '', mbereg_replace('/help/update/id/', '', $_GET['r'])))) : $id, $this->model_name, false);
    }

	public function actionCreate($controller = '') {	parent::actionCreate(__CLASS__); }

	public function actionUpdate($id, $controller = '') 
	{	
		$this->page_name = $this->update_name;
		$model = $this->loadModel($id);
		
		$name=$this->model_name;

		if (isset($_POST[$name]))
		{
			AdminController::checkBoxRestore($this->checkBoxField, $this->model_name);
			$model->attributes = $_POST[$name];

			if ($model->save())
			{
				if (!empty($controller)) $this->SaveLog(__CLASS__, 'actionUpdate', $model->attributes);

				$t = Yii::app()->getRequest()->getParam(_Input::$SaveOK);
				if (empty($t)) $this->redirect(_URL::DefaultReditect());
			}
		}

		$this->tool_bar['create']=array('label'=> 'Создать', 'image' => _Icon32::Create, 'url' => '/help/create',);
		
		if ($model->is_public==0)
			$this->tool_bar['user_access']=array('label' => 'Доступ к статье', 'url' => array('add', 'id' => $model->help), 'image' => _Icon32::Users);
		
		Yii::app()->clientScript->registerScript('help_preview', "
            $('#help_preview').click(function(){
            window.open('"._URL::URLCreate(array('view', 'help' => $model->help), 'help')."','helpwin','top=50, left=100, menubar=0, toolbar=0, location=0, directories=0, status=0, scrollbars=1, resizable=1, width=800, height=600') 
	    });");

        $this->tool_bar[]=array('label'=> 'Предпросмотр (сохраните)', 'image' => _Icon32::Preview, 'imageOptions' => array('id' => 'help_preview'),);
		
		$this->tbUIBtn(__CLASS__, 'actionUpdate');
		
		// Если ничего не пришло показать форму из шаблона
		$this->render('record', array('model' => $model,));
	}

	public function actionDelete($id, $controller = '') {	parent::actionDelete($id, __CLASS__);	}
	
    public function actionAc_groupe() 
    {	
        $term =Yii::app()->getRequest()->getParam('term');

        if(Yii::app()->request->isAjaxRequest && $term) 
		{
			$term=escape($term);
            echo CJSON::encode($this->ac_groupe($term));
            Yii::app()->end();
        }
    }
	
	public function actionAdd($id)
    // Добавляет для отображения группу
    {
	    if ($_GET['r']!=='/help/add/id/create')
		    $id=$this->loadModel($id)->help;

        $name='Help_groupe';
        $this->page_name='Добавление группы которой показать статью помощи';

        $model=new $name();
        if ($id!=='create') $model->help=$id;
        
        if (array_key_exists($name, $_POST))
        {
            $model->attributes=$_POST[$name];

            if ($model->save())
            {
                $this->SaveLog (__CLASS__, __METHOD__, $model->attributes);
                $this->redirect("/help/update/id/{$model->help}/"._jQuery_UI::$nameTabNumber."/1"); 
            }
        }
        $this->render('_add', array('model' => $model,));
    }
	
	public function actionRemove($id)
    // Удаляет для отображения группу
    {
        $m=Help_groupe::model()->findByPk((int)$id);
        
        if ($m)
        {
            $id=$m->help;
            $m->delete();
            
            $this->redirect("/help/update/id/$id/"._jQuery_UI::$nameTabNumber."/1"); 
        }
        else $this->redirect("/help/admin"); 
    }
}