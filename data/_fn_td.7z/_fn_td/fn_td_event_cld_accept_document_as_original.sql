create function fn_td_event_cld_accept_document_as_original(sid bigint)
	returns SETOF character varying
language plpgsql
as $$
declare
	is_regscan smallint;
	tid bigint;
BEGIN

	select task_id into tid from subtask where subtask_id=sid;
	select _int into is_regscan from task_param where task_id=tid and task_diag_param='IS_PRESENT_ORIGINAL';

	if (is_regscan = 1) then

		update task set is_success=1 where task_id=tid;

		insert into crond_task (script) values ('Yii::import(''core_app.components.action.AcceptDocAsOriginal''); (new AcceptDocAsOriginal)->run(' || tid || ');');

	end if;
	return query (select cast(null as varchar));

END;
$$;

