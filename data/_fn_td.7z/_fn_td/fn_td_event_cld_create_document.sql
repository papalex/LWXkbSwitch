create function fn_td_event_cld_create_document(sid bigint)
	returns SETOF character varying
language plpgsql
as $$
declare
	is_regscan smallint;
	tid bigint;
BEGIN

	select task_id into tid from subtask where subtask_id=sid;
	select _int into is_regscan from task_param where task_id=tid and task_diag_param='IS_REGISTER_AND_SCAN_COMPLETED';

	if (is_regscan = 1) then

		update task set is_success=1 where task_id=tid;

		insert into crond_task (script) values ('Yii::import(''core_app.components.action.CreateDocumentAction''); (new CreateDocumentAction)->run(' || tid || ');');

	end if;
	return query (select cast(null as varchar));

END;
$$;

